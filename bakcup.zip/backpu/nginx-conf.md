---
title: Nginx配置文件nginx.conf详解
date: 2017-1-25 23:20
tags:
 - Other
---

>最近折腾Ubuntu比较多，也基本原理了Windows和IIS了，论一个软狗的堕落史。既然换到Ubuntu系统上来，勉强算个web开发人员的我当然用的最多的就是Web服务器喽，谈到Linux上的Web服务，Tomcat是啥？我不做j2ee，所以不懂；Apache？那不是直升机吗？嗯嗯，Nginx大法好，战斗名族无所畏惧！  

闲话少扯，Nginx的配置没有IIS那么简洁明了，图形化界面，插件直接安装，恩，稳还是微软老哥稳，我软大法好！Nginx的配置文件，nginx.conf里都有哪些内容，以及是和意思，简单记录一下。
以下的nginx.conf文件来自ubuntu通过apt安装的Nginx 1.10.0(Ubuntu)  

**注意**：部分#内容为在网上查找资料后添加或本身就是#注释的内容可以省略

```
#定义Nginx运行的用户和用户组
user www-data;
#进程文件
pid /run/nginx.pid;
```
上述默认一般不做更改

```
#nginx进程数，建议设置为等于CPU总核心数。
worker_processes auto;  #auto则自动检测

#worker进程的最大打开文件数限制
#worker_rlimit_nofile 100000;
```

如果没设置的话，这个值为操作系统的限制。设置后你的操作系统和Nginx可以处理比“ulimit -a”更多的文件，所以把这个值设高，这样nginx就不会有“too many open files”问题了。

```
#Events模块
events {
	#单个进程最大连接数（最大连接数=连接数*进程数）
	worker_connections 768;
	# multi_accept on;
}
```
`worker_connections`设置可由一个worker进程同时打开的最大连接数。如果设置了上面提到的worker_rlimit_nofile，可以将这个值设得很高。  

记住，最大客户数也由系统的可用socket连接数限制（~ 64K），所以设置不切实际的高没什么好处。`multi_accept `告诉nginx收到一个新连接通知后接受尽可能多的连接。

```
http {
	##
	# Basic Settings
	##
	
	#显示服务器版本
    #server_tokens off;
	##开启高效文件传输模式
    sendfile on;
	#防止网络阻塞
    tcp_nopush on; 
    tcp_nodelay on;

	#长连接超时时间，单位是秒
	keepalive_timeout 65;
	types_hash_max_size 2048;
	# server_tokens off;

	#服务器名字的hash表大小
	# server_names_hash_bucket_size 64;
#重定向服务器名称
	# server_name_in_redirect off;

	#文件扩展名与文件类型映射表
	include /etc/nginx/mime.types;
	#默认文件类型
	default_type application/octet-stream;
#默认编码
	#charset utf-8; 
	……
}
```
HTTP模块控制着nginx http处理的所有核心特性。因为这里只有很少的配置，所以我们只节选配置的一小部分。所有这些设置都应该在http模块中，甚至你不会特别的注意到这段设置。  

`server_tokens `并不会让nginx执行的速度更快，但它可以关闭在错误页面中的nginx版本数字，这样对于安全性是有好处的。  

`sendfile`可以让`sendfile()`发挥作用。`sendfile()`可以在磁盘和`TCP socket`之间互相拷贝数据(或任意两个文件描述符)。`Pre-sendfile`是传送数据之前在用户空间申请数据缓冲区。之后用`read()`将数据从文件拷贝到这个缓冲区，`write()`将缓冲区数据写入网络。`sendfile()`是立即将数据从磁盘读到OS缓存。因为这种拷贝是在内核完成的，`sendfile()`要比组合`read()`和`write()`以及打开关闭丢弃缓冲更加有效  

`tcp_nopush `告诉nginx在一个数据包里发送所有头文件，而不是一个接一个的发送  

`tcp_nodelay `告诉nginx不要缓存数据，而是一段一段的发送--当需要及时发送数据时，就应该给应用设置这个属性，这样发送一小块数据信息时就不能立即得到返回值。  

`include`只是一个在当前文件中包含另一个文件内容的指令。这里我们使用它来加载稍后会用到的一系列的MIME类型。  

`default_type`设置文件使用的默认的`MIME-type`。  

`charset`设置我们的头文件中的默认的字符集

下面列述一些我在网上查阅到，但是我的Ubuntu上的Nginx默认没有的部分：

```
#FastCGI相关参数是为了改善网站的性能：减少资源占用，提高访问速度。下面参数看字面意思都能理解。
fastcgi_connect_timeout 300;
fastcgi_send_timeout 300;
fastcgi_read_timeout 300;
fastcgi_buffer_size 64k;
fastcgi_buffers 4 64k;
fastcgi_busy_buffers_size 128k;
fastcgi_temp_file_write_size 128k;

#gzip模块设置
gzip on; #开启gzip压缩输出
gzip_min_length 1k; #最小压缩文件大小
gzip_buffers 4 16k; #压缩缓冲区
gzip_http_version 1.0; #压缩版本（默认1.1，前端如果是squid2.5请使用1.0）
gzip_comp_level 2; #压缩等级
gzip_types text/plain application/x-javascript text/css application/xml;
#压缩类型，默认就已经包含text/html，所以下面就不用再写了，写上去也不会有问题，但是会有一个warn。
gzip_vary on;
#limit_zone crawler $binary_remote_addr 10m; #开启限制IP连接数的时候需要使用
```

这里主要提及到的就是基础设置和http部分，mail转发在此不提及，日后用到另发一篇。
