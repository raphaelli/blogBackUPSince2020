---
title: SQLServer 服务器角色管理
date: 2018-06-01 18:07:49
tags:
 - dotNET
---

> SQL Server 提供服务器级角色以帮助你管理服务器上的权限。 这些角色是可组合其他主体的安全主体。 服务器级角色的权限作用域为服务器范围。 （“角色”类似于 Windows 操作系统中的“组”。）

# 角色 



![sqlrole](sql-admin-role/sqlrole.png)



如上图所示，共九种角色：

| 服务器级的固定角色 | Description                                                  |
| ------------------ | ------------------------------------------------------------ |
| **sysadmin**       | sysadmin 固定服务器角色的成员可以在服务器上执行任何活动。    |
| **serveradmin**    | **serveradmin** 固定服务器角色的成员可以更改服务器范围的配置选项和关闭服务器。 |
| **securityadmin**  | **securityadmin** 固定服务器角色的成员可以管理登录名及其属性。 他们可以 `GRANT`、`DENY` 和 `REVOKE` 服务器级权限。 他们还可以 `GRANT`、`DENY` 和 `REVOKE` 数据库级权限（如果他们具有数据库的访问权限）。 此外，他们还可以重置 SQL Server 登录名的密码。  **重要提示：** 授予 数据库引擎 的访问权限和配置用户权限的能力使得安全管理员可以分配大多数服务器权限。**securityadmin** 角色应视为与 **sysadmin** 角色等效。 |
| **processadmin**   | processadmin 固定服务器角色的成员可以终止在 SQL Server 实例中运行的进程。 |
| **setupadmin**     | setupadmin 固定服务器角色的成员可以使用 Transact-SQL 语句添加和删除链接服务器。 （使用 Management Studio时需要 sysadmin 成员资格。） |
| **bulkadmin**      | bulkadmin 固定服务器角色的成员可以运行 `BULK INSERT` 语句。  |
| **diskadmin**      | diskadmin 固定服务器角色用于管理磁盘文件。                   |
| **dbcreator**      | **dbcreator** 固定服务器角色的成员可以创建、更改、删除和还原任何数据库。 |
| **public**         | 每个 SQL Server 登录名都属于 public 服务器角色。 如果未向某个服务器主体授予或拒绝对某个安全对象的特定权限，该用户将继承授予该对象的 public 角色的权限。 只有在希望所有用户都能使用对象时，才在对象上分配 Public 权限。 你无法更改具有 Public 角色的成员身份。  **注意：** public 与其他角色的实现方式不同，可通过 public 固定服务器角色授予、拒绝或调用权限。 |

# 权限



![ys](sql-admin-role/ys.png)





数据库角色成员身份：

| 权限              | 解释                                                         |
| :---------------- | :----------------------------------------------------------- |
| db_accessadmin    | 在数据库中添加或删除windows nt4.0或windows2000用户和组以及sql server用户 |
| db_backupoperator | 有备份数据库的权限                                           |
| db_datareader     | (查) 查看来自数据库中所有用户表的全部数据                    |
| db_datawriter     | (增删改) 添加、更改或删除来自数据库中所有用户表的数据        |
| db_ddladmin       | 添加、修改或除去数据库中的对象                               |
| db_denydatareader | 拒绝选择数据库数据的权限                                     |
| db_denydatawriter | 拒绝更改数据库数据的权限                                     |
| db_owner          | (完全权限) 进行所有数据库角色活动，以及数据库中的其他维护和配置活动，该角色的权限跨越所有其他固定数据库角色。 |
| db_securityadmin  | 管理sql server2000数据库角色的角色和成员，并管理数据库中的语句和对象权限 |
| public            | 不可更改，为数据用户维护的默认许可权限，每个数据库用户都属于public角色的成员。 |

常用的为：db_datareader（查权限）db_datawriter（增删改权限）db_owner（完全权限）   



**对于研发项目和测试的项目，我们可以只给予 public 权限，然后在用户映射设置中给与对应数据库的 所有者(ower) 权限。**

