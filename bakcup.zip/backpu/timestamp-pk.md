---
title: 使用时间戳生成唯一主键
date: 2019-01-07 15:43:40
tags:
 - WorkNote
---

>之前在开发一个功能模块的时候遇到了JS的时间存为时间戳的情况，因为头一次遇到折腾了好久。而在开发另一个某款需要存储数据时，我想到时间戳精确到毫秒的特性，正好适合作为作为主键ID来使用，在绝大部分系统中，毫秒级的使用范围应该都是符合的。

# 先说下什么是时间戳
时间戳（timestamp），一个能表示一份数据在某个特定时间之前已经存在的、 完整的、 可验证的数据,通常是一个字符序列，唯一地标识某一刻的时间。使用数字签名技术产生的数据， 签名的对象包括了原始文件信息、 签名参数、 签名时间等信息。广泛的运用在知识产权保护、 合同签字、 金融帐务、 电子报价投标、 股票交易等方面。

在开发中，有两种时间戳，一种是JS时间戳，另一种则是Unix时间戳。

# JS时间戳与Unix时间戳
首先要清楚JavaScript与Unix的时间戳的区别：

JavaScript时间戳：是指格林威治时间1970年01月01日00时00分00秒(北京时间1970年01月01日08时00分00秒)起至现在的总毫秒数。

Unix时间戳：是指格林威治时间1970年01月01日00时00分00秒(北京时间1970年01月01日08时00分00秒)起至现在的总秒数。

可以看出JavaScript时间戳总毫秒数，Unix时间戳是总秒数。

比如同样是的 2016/11/03 12:30:00 ，转换为JavaScript时间戳为 1478147400000；转换为Unix时间戳为 1478147400。

因此使用Js的时间戳来拼接生成主键Id 无疑是一种很好的选择。

# C# DateTime转换为JavaScript时间戳
```cs
DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1)); // 当地时区
long timeStamp = (long)(DateTime.Now - startTime).TotalMilliseconds; // 相差毫秒数
Console.WriteLine(timeStamp);
```

# JavaScript时间戳转换为C# DateTime
```cs
long jsTimeStamp = 1478169023479;
DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1)); // 当地时区
DateTime dt = startTime.AddMilliseconds(jsTimeStamp);
Console.WriteLine(dt.ToString("yyyy/MM/dd HH:mm:ss:ffff"));
```

# 主键示例
下述示例，使用字符串开头 + 用户名称 + 时间戳来创建 主键 Id， 同一毫秒内几乎不可能有来自同一用户的创建请求。

```cs
//时间戳方式创建N_ID
DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1)); // 当地时区
long timeStamp = (long)(notice.PUB_TIME - startTime).TotalMilliseconds; // 相差毫秒数
//添加唯一ID
notice.N_ID = "No-" + notice.PUB_BY + timeStamp;
```