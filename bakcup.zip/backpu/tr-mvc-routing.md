---
title: 【译】ASP.NET MVC 6路由技术
date: 2018-01-03 22:09:28
tags:
 - Other
---
>原文作者：Pramod Gawande
原文地址：https://dzone.com/articles/aspnet-mvc-6-routing-techniques?fromrel=true

在我们跳转到自定义路由之前，我们将不得不从MVC5中看一下MVC6的基本变化。 ASP.NET MVC6将所有必要的启动服务，定义和配置的应用程序依赖关系放在一个文件Startup.cs中。 Startup.cs文件替换了放置中间件和配置逻辑的global.asax的所有功能。

正如我们所知，路由动作正在通过Routes.MapRoute方法进行管理。在ASP.NET MVC 6 Routes.MapRoute中，你不会找到这个方法作为Startup.cs文件的一部分，它现在只包含很少的代码行。您还会注意到没有专门的配置文件来处理RouteConfig.cs，WebApiConfig.cs或其他中间处理程序，这些中间处理程序是早期的ASP.NET版本和MVC模式项目模板附带的。 Startup.cs文件具有services.AddMvc()和services.UseMvc()方法来处理路由操作。

我们可以看看应用程序代码中`UseMvc()`方法的当前实现。

​

![UseMvc()](https://ask.qcloudimg.com/draft/973635/33c2g543tk.png)

​

我们可以使用基于属性和/或基于约定的方法添加我们自己的路由。我使用这两种方法，因为如果我们一起使用两种方法基于属性的路由覆盖基于约定的路由。两个路由都会覆盖由UseMvc()方法定义的现有默认路由。

基于属性的路由

我们必须在控制器中编写代码来实现基于属性的路由。

​

![控制器](https://ask.qcloudimg.com/draft/973635/hjm9rkj3nw.png)

​

基于约定的路由

我们必须在Startup.cs中编写代码来实现基于属性的路由。

​

![Startup.cs](https://ask.qcloudimg.com/draft/973635/y0afgep22g.png)