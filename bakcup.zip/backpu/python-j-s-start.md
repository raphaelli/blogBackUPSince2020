---
title: Python笔记-使用 JupiterNotebook 写一个爬虫实例
date: 2018-01-23 14:41:28
tags:
 - Other
---

>使用 `Docker` 搭建好 `Python` 和 `JupiterNotebook` 的环境后，一直没有试过具体的开发和项目，正好最近遇到了百度搜索引擎不能收录部署在 `Github page` 上的 `Hexo` 博客的问题，百度提供了手动提交链接的服务，正好写一个简单的爬虫，来爬取 `archives` 页面的内容，顺带对 `JupiterNotebook` 的开发方式做一个归纳。

## JupiterNotebook
将 `JupiterNotebook` 使用 `Docker ` 部署在服务器后，即能实现随时随地的 `Python` 开发，新建项目，使用 `Terminal` 进行操作，甚至都不需要 `putty` 和 `SSH` 来链接到服务器。

**`JupiterNotebook` 的功能非常简单而强大，先从界面说起：**

![JupiterNotebook](python-j-s-start/jn.png)

`Files` 提供了一个直观的文件管理页面
`Running` 则列出了正在运行的终端和笔记

点击 `New` 可以新建 `Python` 的 `Notebook` 和 `Terminal` 以及文件和文件夹。

**再看看 `Notebook` ：**

![Notebook](python-j-s-start/nb.png)

`JupiterNotebook` 使用 `Cell` 来区分代码块，每个代码块可以换号和单独执行。
- `Enter` 回车键直接 `Cell` 内换行
- `Ctrl`+`Enter` 运行本 `Cell` 代码并换号
- `Shift`+`Enter` 新建 `Cell`

**每一个 `Cell` 可以更变为 `Markdown` 语法文本，也可以使用 `Python` 代码**

## Spider
简单介绍了 `JupiterNotebook` ，然后就言归正传，来看看这个爬取博客的 `archives` 页面的内容的爬虫。

一切照旧，先引入：

```python
import os
import requests
from bs4 import BeautifulSoup
```

然后设置头文件并获取页面内容：

```python
headers = {'User-Agent':"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1(KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1"}
target_Url = "https://ns96.com/archives/"
ext_html = requests.get(target_Url,headers=headers) 
```

使用 `BeautifulSoup` 整理并输出：
```python
soup = BeautifulSoup(ext_html.text,'lxml')
urls = soup.select('a.archive-title')

for link in urls:
    print("https://www.ns96.com"+link.get('href'))
```

最后，源文件地址如下：[github](https://github.com/raphaelli/Python-Spider-Study/blob/master/Simple/SpiderTest-Ns96-Archive.py)