---
title: Docker搭建.Net Core环境
date: 2018-01-06 14:26:34
tags:
 - Docker
---
>前面大致介绍了`Docker`,最近一直在折腾`dotNET Core`,不如正好部署个`Docker`环境，做个笔记。


- [Docker初次见面](https://ns96.com/2018/01/01/docker-start/) - `Docker`基础概念
- [Docker循序渐进](https://ns96.com/2018/01/05/docker-keepgoing/) - `Docker`容器的基本操作
- [Docker渐入佳境](https://ns96.com/2018/01/06/docker-justtry/) - `Docker`容器示例（Nigix）

# 安装 dotNET Core 环境
安装`dotNET Core`有两种方式，下面分别例举。

## 在Docker容器中获取 dotNET Core 镜像
```
$ docker pull microsoft/dotnet 
```

**注意** docker的镜像池在获取镜像时容易出现获取缓慢等情况，可以酌情考虑使用阿里云或`DaoCloud`等国内云服务供应商提供的镜像池，这里给出`DaoCloud`的镜像加速方法。

```
$ curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://14ff9bc6.m.daocloud.io
$ sudo systemctl restart docker.service
```
执行`DaoCloud`提供的脚本，并重启docker

![加速](docker-dotnetcore-start/js.png)


pull完成后，使用`images`指令查看镜像

![image](docker-dotnetcore-start/img.png)

## 使用镜像创建容器并测试
- 运行容器
```
$ docker run --name dotnet -p 5000:8088 -it microsoft/dotnet
```
这里预先说明一下，`dotnet core`的web项目默认端口是5000，提前标注映射到外网的8088端口

- 在容器中新建一个web应用
```
$ mkdir -p /home/dotnet
$ cd home/dotnet
$ dotnet new mvc -n DockerWeb
```

- 进入目录，`run`项目
```
$ cd DockerWeb
$ dotnet run
```

![dotnet](docker-dotnetcore-start/dotnet.png)

项目成功运行，并监听`5000`端口，此时项目已经成功运行了，但是并不方便，每次我们部署一个web项目，都需要将文件添加到容器里，再进行操作。

## 挂载源代码
事实上，有一种快速部署到容器的方法，就是使用挂载源代码——即在宿主机中安装`dotNet Core`环境并部署代码，再将其部署到`Docker`容器中。

首先是安装`dotNet Core`环境，这里的内容，我在前面的博客的**文末**，提供了官方的安装教程-[.NET Core 实战笔记1-介绍和安装](https://ns96.com/2017/11/21/dotNet-core-1/)。

安装完成后，同样先创建一个`MVC`的项目，取名为`Web`，过程和上述一样，此处略过。

具体如何挂载源代码呢？有两种方法：

## Docker容器文件共享
一种是直接文件**共享**，这种模式下，文件是共享的形式，而不是容器拥有一份宿主机目录的拷贝，意味着，在宿主机上对目录的更改，会即时反应到容器中。但反过来，容器中对共享目录的更改，不会反应到宿主机上，这一特性是为了遵循容器的**隔离**特性。

**那么具体操作呢？**

在启动Docker镜像时，Docker允许我们通过使用`-v`参数挂载宿主机的文件到容器的指定目录下。换句话说，就相当于宿主机共享指定文件供容器去访问。

建立一个容器，并共享刚才创建好的`MVC`项目，注意目录地址。

```
$ docker run -it \
-v /HOME/dotNetCore/Web:/app \
microsoft/dotnet
```
![共享](docker-dotnetcore-start/v.png)

**注意**： 命令中的`\`结合`Enter`键构成换行符，允许我们换行输入一个长命令。

事实上，这就是**持续构建（CI）**。基本思路是，通过git clone源码到宿主机上，然后将源码目录挂载到容器中去进行构建。

## Dockerfile
Dockerfile用来定义你将要在容器中执行的系列操作。

我们来创建第一个Dockerfile：
//确保进入我们创建的MVC项目目录中去
```
$ cd $HOME/demo/HelloDocker.Web //使用touch命令创建Dockerfile
$ touch Dockerfile//使用vi命令编辑Dockerfilevi Dockerfile
```

进入VI编辑界面后，复制以下代码，使用shift + Ins命令即可粘贴。然后按ESE退出编辑模式，按shift + :，输入wq即可保存并退出编辑界面。

```
FROM microsoft/dotnet:latest
WORKDIR /app
COPY . /app
RUN dotnet restore
EXPOSE 5000ENV ASPNETCORE_URLS http://*:5000ENTRYPOINT ["dotnet","run"]
```

上面的命令我依次解释一下：
- 使用FROM指定容器使用的镜像
- 使用WORKDIR指定工作目录
- 使用COPY指令，复制当前目录（其中.即代表当前目录）到容器中的/app目录下
- 使用RUN命令指定容器中执行的命令
- 使用EXPOSE指定容器暴露的端口号
- 使用ENV指定环境参数，上面用来告诉.NETCore项目在所有网络接口上监听5000端口
- 使用ENTRYPOINT制定容器的入口点

Dockerfile就绪，我们就可以将我们当前项目打包成镜像以分发部署。

使用`docker build -t <name> <path>`指令打包镜像：

```
$ docker build -t hellodocker.web 
```
以上命令就是告诉docker将当前目录打包成镜像，并命名为`hellodocker.web`。命令执行完毕，输入`docker images`即可看到我们新打包的镜像。镜像创建完毕我们就可以直接运行了：

```
docker run -d -p 80:5000 hellodocker.web
```

上面的指令就是运行我们新打包的镜像，并通过`-p`参数映射容器的`5000`到宿主机的`80`端口，其中`-d`参数告诉`docker`以后台任务形式运行镜像。因为`80`是默认的`web`端口，所以我们通过浏览器直接访问ip即可访问到我们容器中运行的MVC网站。或者通过`curl -i http://localhost`来验证。


## 推送镜像到仓库
我们可以把自己配置好的镜像通过`Docker hub`或其他平台进行发布，然后再其他的机器或设备上就可以直接获取我们发布好的镜像，从而快速的进行部署。

具体内容此处暂略。后面专门开一篇，或者结合镜像的配置记录。