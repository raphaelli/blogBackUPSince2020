---
title: Ubuntu 系统自动 apt 换源脚本
date: 2018-9-12 1:12:34
tags:
 - Linux
---

\- shell 脚本写入文件操作
\- shell 脚本备份文件操作
\- shell 脚本更新操作
\- 完整脚本代码

## shell 文件写入操作

shell 脚本编写的时候，可以在文件的开头声明所使用的 bash 路径，代码如下：

```text
#! /bin/bash
```

Linux 下写入文件的操作可以配合 `echo` 命令完成，值得注意的是，写入文件的操作有两种方式，分别是 `>` 和 `>>`，它们的区别如下：
\- `>>` 将内容写入文件，覆盖原有内容
\- `>` 将内容写入文件，追加到文件尾部

那么，使用 shell 脚本向文件写入内容的方法如下：

```text
#! /bin/bash
# <CONTENT> 为需要写入内容
# <FILENAME> 为写入目标文件名
echo <CONTENT> >> <FILENAME>
echo <CONTENT> >> <FILENAME>
```

## shell 文件备份操作

要修改系统的配置文件，最好把原来的配置文件备份一下，这样万一有什么情况，也可以通过恢复备份文件来修复。使用 shell 脚本完成备份文件和直接备份差不多，以备份更新源为例子，代码如下：

```text
#! /bin/bash
# 这里的脚本需要配合 sudo 使用
cp /etc/apt/sources.list /etc/apt/sources.list.bak
```

## shell 脚本完成 apt 更新操作

我们的目标是想在新服务器或者工作站安装系统完成后，能自动完成替换更新源以及执行一次系统软件、包升级，那么就需要使用 shell 完成 apt 更新的操作，具体代码如下：

```text
#! /bin/bash
apt update # 更新源
apt upgrade -y # 更新软件
```
## 完成的 shell 脚本代码

```sh
#! /bin/bash
cp /etc/apt/sources.list /etc/apt/sources.list.bak
echo deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial main restricted universe multiverse > /etc/apt/sources.list
echo deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-updates main restricted universe multiverse >> /etc/apt/sources.list
echo deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-backports main restricted universe multiverse >> /etc/apt/sources.list
echo deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial-security main restricted universe multiverse >> /etc/apt/sources.list
apt update
apt upgrade -y
```

