---
title: JSP Cheat Sheet - JavaWeb基础学习速查表
date: 2017-09-21 16:44:19
tags:
 - Other
---
## JavaWeb学习速查表
整理JavaWeb学习中遇到的问题以及笔记，按分类编排

JSP基本语法  
[指令标识](#jsp-zlbs) - [脚本标识](#jsp-jbbs) - [JSP注释](#jsp-zs) - [动作标识](#jsp-dzbs)

JSP内置对象  
[JSP内置对象](#jsp-nzdx) - []

JSP中的TAG文件与标记
[Tag](#tag) - [Tag创建与调用](#use-tag) 

JSP与JavaBean

Java Servlet

MVC

JSP连接数据库

---

<h2 id ="jsp-zlbs">指令标识</h2>
指令标识用于设定整个JSP页面范围内都有效的相关信息，是被服务器解析执行的，不会产生任何内容输出到网页，对浏览器不可见。

```
<%@ 指令名 属性1="属性值1" 属性2="属性值2" …… %>
<%@ page pageEncoding="utf-8" import="java.util.Date,java.text.SimpleDateFormat" %>
```

指令名：
### page
page 是JSP页面最常用的指令，用于定义整个JSP页面的相关属性，这些属性在被解析成Servlet时会转化位想要的Java代码，page一共有15个属性。
- language 属性 设置JSP页面语言，目前只有Java
- extends 属性 设置页面继承的Java类，不常用
- import 属性 设置JSP导入的类包（Java代码在调用API时，需要导入相应的类包）
- pageEncoding 属性 定义JSP页面的编码格式，指定文件编码
- contentType 属性 设置JSP页面的MIME类型和字符编码
- session 属性 设置是否使用http的session绘画，bool类型
- buffer 属性 设置JSPout输出对象的缓冲区，默认8k，单位kb，建议8的倍数
- autoFlush 属性 时间页面缓冲自动刷新，bool类型
- isErrorPage 属性 设置当前JSP页面为错误页面，bool类型
- errorPage 属性 指定错误页面

### include
include指令可以在一个JSP页面中包含另一个JSP页面，不过该指令时静态包含，被包含文件中内容会原样包含到JSP页面，无法编译执行JSP代码。

**语法:**  

include指令语法为`<%@ include file="paht" %>`

### taglib
taglib指令表示声明该页面中所使用的标签库，同时引用标签库，并指定标签前缀。在页面中引用标签库后，就可以通过前缀来引用标签库中的标签。

**语法:**  

`<% taglib prefix="tagPrefox" uri="tagURI" %>`  
eg:JSTL核心标签库  
`<% taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>` 

---

<h2 id ="jsp-jbbs">脚本标识</h2>
在JSP页面中，脚本标识能够方便灵活的生产页面中的动态内容，特别是Scriptlet脚本程序。JSP脚本标识包括3部分，JSP表达式(Expression)，声明标识符(Declaration)，脚本程序(Scriptlet)。

### JSP表达式
`<%= 表达式 %>`  
参数说明：表达式可以是任何Java语言的完整表达式，该表达式的最终运算结果将被转换为字符串。  

**注意：**`<%`与`=`之间不可以有空格  

eg:
```
<%String manager="mr";%>
管理员：<%=manager%>             //输出 管理员：mr
```
JSP表达式不仅可以插入到网页文本中，用于输出内容，也可以插入到HTML标记中，设置动态属性。

### 声明标识
声明标识用于在JSP页面中定义全局的变量或方法。通过声明标识定义的变量和方法可以被整个JSP页面访问。
>说明：服务器执行JSP页面时，会将JSP页面转换为Servlet类，在该类中会把使用JSP声明标识定义的变量和方法转换为类的成员变量和方法。

**语法:**  

`<%! 声明变量或方法的代码 %>`

**注意：**`<%`与`!`之间不可以有空格,代码块可以换行

### 代码片段
在JSP页面中嵌入的Java代码或是脚本代码。通常用于页面输出内容，处理请求和响应，访问session会话

**语法:**  

`<% 声明变量或方法的代码 %>`

**注意：**区别于代码片段，没有`!`

<h2 id ="jsp-zs">注释</h2>
JSP页面由HTML,JSP,JAVA脚本等组成，所以在其中可以使用多种注释格式。

### HTML注释
HTML语言的注释不会被显示在网页中，但是会显示在网页源码中

**语法:**  

`//注释文本`

### JSP表达式注释
在JSP页面中可以嵌入代码片段，在代码片段中也可以加入注释。


**单行注释语法:**  

`//注释文本`

**多行注释语法:**  

```
/*
 *注释文本
 *注释文本
 *每行内容前的*为了美观对其，可以不用
 */
```

**提示文档注释**

```
/*
  提示信息
  会被Javadoc文档工具生成文档时读取
 */
```

### 隐藏注释
HTML类型注释会被解析到HTML源码中，为了安全，可以使用JSP的隐藏注释，只有在JSP源码中查看，不会解析到HTML。

**语法:**  

`<%-- 注释内容 --%>`

### 动态注释
由于HTML注释对于JSP嵌入代码不起作用，可以使用他们的组合构成动态HTML注释文本。

eg：`<!--<%=new Date()%> -->`

---

<h2 id ="jsp-dzbs">动作标识</h2>
动作标识一共有三种，分别是include包含文件标识，forward请求转发标识，param传递参数标识。

### 包含文件标识<jsp:include>
用于向当前页面中包含其他的文件，被包含的文件可以时动态或者静态文件。

**语法:**  

```
<jsp:include page="url" flush="false|true">
  // 子动作标识<jsp:param>
</jsp:include>
```

参数说明：  
- page：用于指定被包含文件的相对路径
- flush：可选属性，用于设置是否刷新缓存区
- `<jsp:param>`：子动作标识，用于向被包含的动态页面中传递参数

**注意:** 
- 区别于include指令通过file属性指定被包含的文件，并且file属性不支持任何表达式，`<jsp:include>`动作标识通过page属性指定被吧汗的文件，而且page属性支持jsp表达式。
- include指令被包含的文件内容会原封不动的插入到包含页中，然后再便宜成一个最终java文件，`<jsp:include>`动作标识包含文件时，当该标识被执行时，程序会将请求**转发**到被包含的页面，会分别编译。
- include中的变量名和方法名不允许冲突，`<jsp:include>`分别编译，不冲突

### 请求转发标识<jsp:forward>
通过`<jsp:forward>`动作标识,可以将请求转发到其他的web资源,例如一个jsp页面,html页面,servlet灯,执行请求转发后,当前页面将不再被执行,二是去执行该标识指定的目标页面.
```
<jsp:forward page="url">
  // 子动作标识<jsp:param>
</jsp:forward>
```
参数说明:
- page:用于指定请求转发的目标页面,可以是文件路径,也可以是是文件路径的jsp表达式,但限制当前应用中的资源
- `<jsp:param>`：子动作标识，用于向被包含的动态页面中传递参数

### 传递参数标识<jsp:param>
JSP的动作标识`<jsp:param>`可以作为其他标识的子标识，用于其他标识传递参数。
```
<jap:param name = "userId" value="7" />
```
**注意:** 通过`<jsp:param>`动作标识指定的参数，将以`“参数名=值”`的形式加入到请求中，与在文件名后面直接加`?参数名=值`是相同的。

