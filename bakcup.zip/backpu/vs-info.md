---
title: 修改Visual Studio类模板添加版权注释信息
date: 2017-10-11 12:49:34
tags:
 - dotNET
---
>在开发过程中，经常需要给类或接口与添加public修饰符和一些相关的注释信息，这个工作是机械而枯燥的，而这个简单的需求可以通过修改VS自带类模板来实现的。

打开Visual Studio的安装目录，找到`C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\Common7\IDE\ItemTemplates\CSharp\Code\2052\Class`三个目录下面的cs文件，并添加如下代码：
```
/*********************************************************************
 * Copyright(c) $year$$registeredorganization$ All Rights Reserved.
 * CLR 版本： $clrversion$
 * 机器名称：$machinename$
 * 公司名称：$registeredorganization$
 * 命名空间：$rootnamespace$
 * 文件名：$safeitemname$
 * 版本号：V1.0.0.0
 * 唯一标识：$guid10$
 * 当前的用户域：$userdomain$
 * 创建人：$username$
 * 电子邮箱：raphael_li@live.com
 * 创建时间：$time$
 ******************************************************/
```

 通常情况而言，首行版权信息，机器名称，公司名称可以不写。

 当然也可以像我这样加点奇奇怪怪的东西上去！

```
 /***************************** Raphael96  NS96.com ********************************
 * 创建人：$username$                   　　　
 * 电子邮箱：raphael_li@live.com            
 * 创建时间：$time$                         
 * CLR 版本： $clrversion$                  
 * 命名空间：$rootnamespace$                
 * 文件名：$safeitemname$
 * 版本号：V1.0.0.0
 * 唯一标识：$guid10$
 * Copyright(c) $year$$registeredorganization$ All Rights Reserved.
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　　　　　┃
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　　　　　┃
 * 　　┃　　　┻　　　┃
 * 　　┃　　　　　　　┃
 * 　　┗━┓　　　┏━┛ Codes are far away from bugs with the animal protecting
 * 　　　　┃　　　┃     神兽保佑,代码无bug
 * 　　　　┃　　　┃
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　    ┣┓
 * 　　　　┃　　　　      ┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┃┫┫　┃┫┫
 * 　　　　　┗┻┛　┗┻┛
 * *********************** Talk is cheap,Show me the code! ***********************/
```