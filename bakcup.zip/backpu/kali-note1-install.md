---
title: Kail 笔记1 - 安装和配置
date: 2018-06-01 20:40:45
tags:
 - Other
---

> 最近对网络安全比较感兴趣，去图书馆借了几本书，简单过一遍，顺带记点笔记备忘。

# Kail

[**Kali Linux**](https://www.wikiwand.com/zh-sg/Kali_Linux) 是基于[Debian](https://www.wikiwand.com/zh-sg/Debian)的[Linux发行版](https://www.wikiwand.com/zh-sg/Linux%E5%8F%91%E8%A1%8C%E7%89%88)，设计用于[数字鉴识](https://www.wikiwand.com/zh-sg/%E6%95%B8%E4%BD%8D%E9%91%91%E8%AD%98)和[渗透测试](https://www.wikiwand.com/zh-sg/%E6%B8%97%E9%80%8F%E6%B5%8B%E8%AF%95)。由 Offensive Security Ltd 维护和资助。

Kali Linux 拥有超过600个预装的渗透测试程序，包括 Armitage(一个图形化网络攻击管理工具， Nmap(一个端口和服务扫描工具), Wireshark, John the Ripper password cracker, Aircrack-ng, Burp Suite 和 OWASP ZAP 网络应用程序安全扫描器。



# 安装

使用 virtualBox 安装，整体安装比较简单，略过……



安装时注意，最后一步 安装 GRUB 引导是，注意选着**是**，并将其装入 **virtualBox的虚拟硬盘**中！



另外，拨号上网的模式下（校园网ppp拨号等），可以额外设置一个虚拟的网卡，采用 NAT模式，用于设备接入外网，而其他内外操作使用桥接的网卡。

![KNET](kali-note1-install/KNET.png)



# 简单配置和软件安装

Kali 本身基于 debian 因此配置和软件源等安装和基于 debian 的 Ubuntu 大致相同，且 Kali 本身就集成了大量可用的软件，十分方便。