---
title: Python开发环境—— jupyter Notebook 安装使用
date: 2018-01-14 14:59:26
tags:
 - Other
---

>前篇学习爬虫的基础介绍中，推荐了 Python 的科学计算发行版本 `Anaconda`，其中集成了一个非常好用的Python开发工具—— `jupyter Notebook`。

这篇说一下 Linux 下配置一个 Python 的 `jupyter Notebook`并可以外网访问进行开发的方法，这样就可以随时轻松的使用 `jupyter Notebook`进行pythob的开发学习，十分方便。

# 安装 Anaconda
这一部分上一篇已经说过了，这里再说一下。

[ anaconda 官网](https://www.anaconda.com/) - 是Python的一个科学计算的发行版。

 这里以官方最新版本（18/1/10）`3-5.0.1`为例，通过安装脚本安装(Ubuntu环境)。

 事实上，win下的安装更为简单，也可以配合PyCharm食用更佳。

 因为资源在国外，所以下载速度很慢，可以使用[清华大学镜像源](https://mirror.tuna.tsinghua.edu.cn/help/anaconda/)

```
$ wget 
https://mirrors.tuna.tsinghua.edu.cn/anaconda/archive/Anaconda3-5.0.1-Linux-x86_64.sh
$ bash Anaconda3-5.0.1-Linux-x86_64.sh
```
下载并执行脚本后，按照提示逐步安装。

**注意**： `Anaconda` 和 `jupyter Notebook` 在Linux环境下都不推荐使用root权限，因此最好使用其他用户进行安装。

# 配置 jupyter Notebook

## 生成一个 notebook 配置文件
默认情况下，配置文件 `~/.jupyter/jupyter_notebook_config.py` 并不存在，需要自行创建。使用下列命令生成配置文件：

```
$ jupyter notebook --generate-config
```

如果是 root 用户执行上面的命令，会发生一个问题：

```
 Running as root it not recommended. Use --allow-root to bypass.
```

提示信息很明显，root 用户执行时需要加上 `--allow-root` 选项。
```
$ jupyter notebook --generate-config --allow-config
```

执行成功后，会出现下面的信息：
```py
 Writing default config to: /root/.jupyter/jupyter_notebook_config.py
```

## 生成密码
如果要外网访问 `jupyter Notebook` 则需要一个密码，这里推荐直接生成的方法

从 `jupyter notebook 5.0` 版本开始，提供了一个命令来设置密码：`jupyter notebook password` ，生成的密码存储在 `jupyter_notebook_config.json` 。

```
$ jupyter notebook password
Enter password:  ****
Verify password: ****
[NotebookPasswordApp] Wrote hashed password to /Users/you/.jupyter/jupyter_notebook_config.json
```

使用 `vim` 或其他的编辑器打开文件，复制 `" "` 中的内容，将其放入后面需要修改的配置文件中

## 修改配置
在 jupyter_notebook_config.py 中找到下面的行，取消注释并修改。
```
c.NotebookApp.ip='*'
c.NotebookApp.password = u'sha:ce...刚才复制的那个密文'
c.NotebookApp.open_browser = False
c.NotebookApp.port =8888 #可自行指定一个端口, 访问时使用该端口
```

**提示**: 可以使用 `vi/vim` 的查找指令，参看——[Vim勉强入个门 ](https://ns96.com/2017/11/30/vim/) 。

以上设置完以后就可以在服务器上直接输入 `jupyter notebook` 启动， root 用户使用 `jupyter notebook --allow-root` 。


# 常见错误提示

## 正常进入 jupyter notebook 登陆后提示404

解决方法，更换启动指令时的目录，然后重新启动。

## 创建新项目出错 Unexpected error while saving file: Untitled.ipynb [Errno 13]

给予指定目录可写入权限(推荐变更所有者为当前用户，若未生效则给与755/777所有用户权限)
```
$ sudo chown raphael /home/raphael/ -R
$ sudo chmod 755 /home/raphael/.local
```

# 重新安装到Docker
安装完成之后，发现关闭当前 session 后， `jupyter notebook` 就会退出，于是我第一个想到的方法是传统的 `screen` ,但是转念一想，为什么不使用 `Docker` 呢？

整理一下思路，安装流程应该是，基于 ubuntu 镜像创建容器，安装  `Anaconda` （需要注意root权限），配置 `jupyter notebook` ,指定端口,外网访问并使用。然而实际上并不需要这么复杂！

为啥捏~(￣▽￣)~*？因为 anaconda 官方给用户提供了 `Docker` 镜像，地址 [continuumio/anaconda3](https://hub.docker.com/r/continuumio/anaconda3/)

**So，let's do this!**

```
$ docker pull continuumio/anaconda3
$ docker run -i -t continuumio/anaconda3 /bin/bash
$ docker run -i -t -p 8888:8888 continuumio/anaconda3 /bin/bash -c "/opt/conda/bin/conda install jupyter -y --quiet && mkdir /opt/notebooks && /opt/conda/bin/jupyter notebook --notebook-dir=/opt/notebooks --ip='*' --port=8888 --no-browser --allow-root"
```
两天推荐的启动指令，一个是直接启动 `anaconda3`,而最后一条指令是启动容器并启动 `jupyter notebook` 。

执行最后条指令，发现提示root权限问题，加上 `--allow-root` 试试，因为本身就是只运行 `anaconda3` 和 `jupyter notebook` 的容器，不存在其他用户使用的情况，所以也就无所谓。

![demo](python-notebook/demo.png)

如上图中，暴露了 `token` ,输入上述地址可以直接打开，或者直接访问，然后输入 `token` 当然，也可以使用密码，大家自行按照使用需求来解决。
