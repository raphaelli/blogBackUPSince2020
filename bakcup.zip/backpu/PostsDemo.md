---
title: "第一篇示例博客"
date: 2017-08-21 18:05
tags:
 - Other
---

# 0x000
 使用Hexo配合Github Pages搭建了新的博客，后续博客内容均使用Markdown记录以便于保存发布，原有内容根据实际情况调整逐步筛选补全。

# Mark部分内容
 ## Hexo常用操作
 hexo clean 清理缓存  
 hexo g 生成  
 hexo c 本地调试  
 hexo d 发布到github page   
 其他指令在使用后补全

 ## Markdown常用格式
 [外部链接-简书](https://coding.net/help/doc/project/markdown.html#section-3)  
 直接查看已经整理好的内容，不再复述

 ## Mark当前主题Vexo的发布格式

 需要在md头部加入
 ```
---
title: "Hello World"
date: 2016-06-10 23:00
banner: http://your-banner-image-link.jpg
tags:
 - Movies
 - Life
---
 ```

#At Last
PS:安装[hexo-asset-image](https://github.com/CodeFalling/hexo-asset-image)实现本地图片加载  
添加同名文件夹（与.md同名）将图片引入直接使用
![LALA](PostsDemo/la.jpg)
