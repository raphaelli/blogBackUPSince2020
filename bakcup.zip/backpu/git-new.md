---
title: 新装/重装git后的指令&链接到github
date: 2017-11-11 16:57:39
tags:
 - git

---

>有些事情总是在所难免的，嗯，比如重装系统，作为学计算机的当然不用困扰重装系统这种事情喽，然而重装系统之后的开发环境确实让人头疼。有些软件你使用起来熟练了，但未必一定记得是怎么安装和配置的，比如git，emmmmm……写一篇mark一下吧。

## 安装git
[下载地址](https://git-scm.com/download)  
启动安装

## 配置git
```Sh
  git config --global user.email "raphael_li@live.com"
  git config --global user.name "raphaelli"
```

## 配置ssh公钥链接ssh
git自身只需要简单的配置email和name，而链接到github则需要配置好ssh公钥

### 步骤一 首先需要检查你电脑是否已经有 SSH key 
运行 git Bash 客户端，输入如下代码：
```Sh
$ cd ~/.ssh
$ ls
```
这两个命令就是检查是否已经存在 id_rsa.pub 或 id_dsa.pub 文件，如果文件已经存在，那么你可以跳过步骤2，直接进入步骤3。

### 步骤二 创建一个 SSH key 
```sh
$ ssh-keygen -t rsa -C "raphael_li@live.com"
```
>代码参数含义：  
-t 指定密钥类型，默认是 rsa ，可以省略。  
-C 设置注释文字，比如邮箱。  
-f 指定密钥文件存储文件名。  

以上代码省略了 -f 参数，因此，运行上面那条命令后会让你输入一个文件名，用于保存刚才生成的 SSH key 代码，如：  
`Generating public/private rsa key pair.`  

```Sh
# Enter file in which to save the key (/c/Users/you/.ssh/id_rsa): [Press enter]
```

当然，你也可以不输入文件名，使用默认文件名（推荐），那么就会生成 id_rsa 和 id_rsa.pub 两个秘钥文件。

接着又会提示你输入两次密码（该密码是你push文件的时候要输入的密码，而不是github管理者的密码），

当然，你也可以不输入密码，直接按回车。那么push的时候就不需要输入密码，直接提交到github上了，如：
```Sh
Enter passphrase (empty for no passphrase): 
# Enter same passphrase again:
```

## 添加ssh公钥到github
[github-SSh设置](https://github.com/settings/keys)  

复制公钥

```Sh
$ clip < ~/.ssh/id_rsa.pub
```

添加好上面的公钥

测试
```Sh
$ ssh -T git@github.com
```