---
title: 【译】使用Docker Compose一条指令配置Mesos
date: 2017-12-28 22:40:41
tags:
 - Other
---

>原文作者：Sebastien Goasguen  
原文地址：https://dzone.com/articles/1-command-to-mesos-with-docker-compose

# 原文
Setup Mesos with One Command Using Docker Compose



If you have not tried Docker, you should. The sheer power it puts in your hands and the simplicity of the user experience will just wow you. In this post, I will show you how to start a one node Mesos setup with Docker compose.

Docker announced compose on February 26th. Compose allows you to describe a multi-container setup and manage it with one binary docker-compose. The containers and volumes combinations managed by Compose are defined in a YAML file, super easy to read and super easy to write. The UX is very similar to the Docker CLI.

When compose was released, I tried it and was a bit underwhelmed, as it is basically a relooking of Fig. This is not unexpected as Docker Inc, acquired Orchard the makers of Fig. But I was expecting more added functionality and even a tighter integration with the Docker client (something a devbranch actually prototyped), even a common release instead of a separate binary. I am sure this will come.

As I am writing the docker cookbook, I have deployed Wordpress 20 different ways, and it's getting a bit boring !  I was looking for more information on Mesos and its support for Docker, I re-read a terrific blog post that showed how to start a Mesos setup (zookeeper, master, slave, marathon framework) in 7 commands. Can't beat that.

When I re-read this post, I automatically thought this was an exciting use case for docker-compose. One YAML file to start Mesos/Zookeeper/Marathon and experiment with it. Of course I am not talking about a production multi-node setup. I am just looking at it for an easy Mesos experiment.

I will spare you the details of installing compose (just a curl away). The dockers docs are great.

So here is the YAML file describing our Mesos setup:

```
zookeeper:

  image: garland/zookeeper

  ports:

   - "2181:2181"

   - "2888:2888"

   - "3888:3888"

mesosmaster:

  image: garland/mesosphere-docker-mesos-master

  ports:

   - "5050:5050"

  links:

   - zookeeper:zk

  environment:

   - MESOS_ZK=zk://zk:2181/mesos

   - MESOS_LOG_DIR=/var/log/mesos

   - MESOS_QUORUM=1

   - MESOS_REGISTRY=in_memory

   - MESOS_WORK_DIR=/var/lib/mesos

marathon:

  image: garland/mesosphere-docker-marathon

  links:

   - zookeeper:zk

   - mesosmaster:master

  command: --master zk://zk:2181/mesos --zk zk://zk:2181/marathon

  ports:

   - "8080:8080"

mesosslave:

  image: garland/mesosphere-docker-mesos-master:latest

  ports:

   - "5051:5051"

  links:

   - zookeeper:zk

   - mesosmaster:master

  entrypoint: mesos-slave

  environment:

   - MESOS_HOSTNAME=192.168.33.10

   - MESOS_MASTER=zk://zk:2181/mesos

   - MESOS_LOG_DIR=/var/log/mesos

   - MESOS_LOGGING_LEVEL=INFO
```


Launch this with:

```

$ ./docker-compose up -d

Recreating vagrant_zookeeper_1...

Recreating vagrant_mesosmaster_1...

Recreating vagrant_marathon_1...

Recreating vagrant_mesosslave_1...

```

And open your browser at http://IP_HOST:5050 then follow the rest of the blog to start a task in marathon.



Bottom line, I went from '7 commands to Mesos' to '1 command to Mesos' thanks to Docker-compose and a fairly simple YAML file. Got to love it. When compose can do this across Docker hosts in a Docker Swarm started by Machine. Then the real fun will begin !

# 译文
使用`Docker Compose`一条指令配置`Mesos`


如果你还没有使用过的Docker，你一定要试一试。纯粹的功能和质朴的用户体验将让你感到惊奇。在这篇文章中，我将告诉你如何通过`Docker Compose`来设置一个单节点的Mesos。(译者注：[Mesos集群官网](https://mesosphere.com/))

Docker在2月26日发布了`Compose`(译者注：[Docker-Compose官方文档](https://docs.docker.com/compose/overview/))。`Compose`允许你使用一个`Docker-Compose`实现多容器安装和管理。使用`Compose`管理的容器会通过一个`YAML`文件来进行定义，十分容易阅读和编写,其用户体验和`Docker CLI`非常相似。

在`Compose`刚发布时，我试着使用了一下，有点让人失望，因为它基本上是一个翻版的`Fig`。对于Docker公司来说这并不意外，为了夺取Orchard旗下`Fig`的市场。但我期待更多的附加功能，乃至更紧密集成的`Docker`的客户端（一些[dev 分支](https://github.com/moby/moby/issues/9459)实际上提供了原型），即使只是一个普通的发行版而不是一个单独的程序。我相信这一切都会实现。  

当我写 [《docker cookbook》](http://shop.oreilly.com/product/0636920036791.do) 时，我已经试着使用20种不同的方式部署`WordPress`，不得不承认这确实有点无聊！ 我开始寻找更多的关于`Mesos`的信息，然后我发现`Docker`已经实现了对其的支持，我重读了一篇很棒的博客，展示关于如何通过七条指令来实现一个`Mesos`的安装（zookeeper, master, slave, marathon framework）【译者注:[原文链接](https://medium.com/@gargar454/deploy-a-mesos-cluster-with-7-commands-using-docker-57951e020586)，[翻译参考](http://dockone.io/article/136)】。我认输！

当我重新阅读这篇文章是，我下意识地认为这是`Docker-Compose`一个令人激动的用例。使用一个`YAML`文件来启动`Mesos/Zookeeper/Marathon `并进行实验。当然，我不是在介绍一个多节点的设置。仅仅只是简单的进行一个`Mesos`的实验。 

我会略过`compose`安装的细节，`Docker`的[文档](https://docs.docker.com/compose/)已经足够完美了。

下面就是`YAML`文件的所描述的`Mesos`设置：

```
zookeeper:

  image: garland/zookeeper

  ports:

   - "2181:2181"

   - "2888:2888"

   - "3888:3888"

mesosmaster:

  image: garland/mesosphere-docker-mesos-master

  ports:

   - "5050:5050"

  links:

   - zookeeper:zk

  environment:

   - MESOS_ZK=zk://zk:2181/mesos

   - MESOS_LOG_DIR=/var/log/mesos

   - MESOS_QUORUM=1

   - MESOS_REGISTRY=in_memory

   - MESOS_WORK_DIR=/var/lib/mesos

marathon:

  image: garland/mesosphere-docker-marathon

  links:

   - zookeeper:zk

   - mesosmaster:master

  command: --master zk://zk:2181/mesos --zk zk://zk:2181/marathon

  ports:

   - "8080:8080"

mesosslave:

  image: garland/mesosphere-docker-mesos-master:latest

  ports:

   - "5051:5051"

  links:

   - zookeeper:zk

   - mesosmaster:master

  entrypoint: mesos-slave

  environment:

   - MESOS_HOSTNAME=192.168.33.10

   - MESOS_MASTER=zk://zk:2181/mesos

   - MESOS_LOG_DIR=/var/log/mesos

   - MESOS_LOGGING_LEVEL=INFO
```


使用如下指令启动:
```

$ ./docker-compose up -d

Recreating vagrant_zookeeper_1...

Recreating vagrant_mesosmaster_1...

Recreating vagrant_marathon_1...

Recreating vagrant_mesosslave_1...

```

打开你的浏览器，输入 http://IP_HOST:5050 然后按照博客内容剩下的内容在`marathon`中添加一个任务。

![mesos](./tr-se-me/mesos.png)

最后，我将'7条指令设置`Mesos`'变成了'1条指令设置`Mesos`'，这都归功于`Docker-compose`和简便的`YAML`文档。试着喜欢上这种用法。当`Compose`能通过`Docker`实现`Docker Swarm`的机器启动，那么真正有趣的部分就开始了。