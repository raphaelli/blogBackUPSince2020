---
title: Docker 循序渐进
date: 2018-01-05 19:16:19
tags:
 - Docker
---
>[上一篇][1]大致介绍了什么是`Docker`和其安装（以Ubuntu为例）。这篇来说说，`Docker`的基本操作。

# 非Root用户授权
上一篇的演示中使用的都是默认登录了`Root`权限后的操作，而实际的开发运维情况下，我们一般极少使用`Root`权限，所以`Docker`提供了一个权限组，我们只需要把当前用户加入到`Docker`用户组中。

一共需要三条指令:
```
$ sudo groupadd docker
$ sudo gpasswd -a ${USER} docker
$ sudo service docker restart
```

三条指令的意思分别是：
- 添加`docker`用户组，一般会默认创建，提示已存在
- 将用户添加到`docker`用户组
- 重启`docker`服务

示例如下

![user][2]

**注意** 重启服务后，仍需推出当前用户，重新登陆使用户权限生效！

# 容器的基本操作
本内容仅提供常用操作命令及参数，并非完整内容，具体可以参考官方文档或三方手册补全。

推荐参考菜鸟教程(`RUNOOB.COM`)的-[Docker命令大全](http://www.runoob.com/docker/docker-command-manual.html)

## 启动容器
```
$ docker run IMAGE [COMMAND] [AGR…]
```

- `run` 在新容器中执行的命令
- `IMAGE` 启动容器所使用的操作系统的镜像
- `[COMMAND]` 容器启动后的运行命令
- `[AGR]` 命令参数

示例：

一个执行单一指令的基本容器

```
$ docker run ubuntu echo 'Hello world!'
```
![hello][3]

## 启动交互式容器
```
$ docker run -i -t IMAGE /bin/bash
```

- `-i ` 开启标准输入（交互） --interactive = true | false 默认是false 
- `-t` 分配伪tty终端  --tty = true | false 默认是false

示例:

```
$ docker run -i -t ubuntu /bin/bash
```

![itrun][4]

`docker`创建了一个允许使用bash交互的系统，当执行`exit`时推出，释放资源。

## 查看容器
### PS 列举
```
$ docker ps [OPTIONS]
```

- `-a` 查看所有容器
- `-l` 查看最近创建的容器
- `无参` 正在运行的容器

![ps][5]

### inspect 查看容器信息
```
docker inspect NAME|ID [NAME|ID...]
```

参数为 `ps`列举出的ID /NAME

执行后列举出容器的元信息，此处略过。

**顺带一提**:

前文中`run`指令中未提到，给容器指定名称的方法：

```
$ docker run --name=自定义名 -i -t IMAGE /bin/bash
```

## 重新启动停止的容器
很多时候并不需要不停的创建容器，而是可以将已经停止的容器重启来使用。

```
$ docker start [-i] 容器名
```

- `-i` 交互模式

示例如下：

![start][6]


## 删除停止的容器
```
$ docker rm 容器名
```

示例如下：

![rm][7]


# 守护式容器
区别于交互式容器,守护式容器有如下特点：
- 能长期运行
- 没有交互式会话
- 适合运行应用程序和服务

## 以守护形式运行容器
推出交互模式，后台运行：
>使用快捷键 `Ctrl+P` + `Ctrl+Q`

![退出交互][8]

退出交互后，容器仍在运行，使用`docker ps`查看

直到执行`exit`，容器被释放

## 附加到运行中的容器
```
$ docker attach 容器名
```

执行指令后重新进入容器交互界面，图略

## 创建守护式容器
直接使用`run`来创建交互式容器
```
$ docker run -d IMAGE [COMMAND] [AGR…]
```
区别于默认模式，`-d`参数表面启动后台驻留

示例：(这里通过编写一个循环shell来验证)
```
$ docker run --name dc_test -d ubuntu /bin/sh -c "while true; do echo 'hello world'; sleep 1; done"
```

执行后返回`ID`，截图略

## 查看容器运行情况
```
$ docker logs [-f] [-t] [--tail] 容器名
```
参数：
- `-f` 保持跟踪日志变化并返回结果 --follows = true | false 默认为false
- `-t` 返回结果加上时间戳 --timestamps = true | false 默认为false
- `--tail` = all 返回结尾处制定数量的日志  不指定则返回所有

示例：
```
$ docker logs dc_test --tail 3 -t -f
```
以前面创建的`dc_test`容器为例，先显示三行，并保持跟踪且显示时间戳：

![log][9]

**注意**：`Ctrl+C`退出（Linux下绝大部分操作通用嘛）

## 查看进程内容
查看运行中容器的进程：

```
$ docker top 容器名
```

![top][10]

## 在运行的容器中启动新的进程
`Docker`的理念是，在一个容器中使用一个服务，但仍然提供了在一个容器中运行多个进程的方法，从而实现对运行中容器进行维护，监控等操作。
```
$ docker exec [-d] [-i] [-t] 容器名 [COMMAND] [AGR…]
```

**参数**： `-d`/`-i`/`-t` 和前面`run`相同

```
$ docker exec -i -t dc_test /bin/bash
```
以前面创建的`dc_test`容器为例，为其添加一个`bash`终端进程，并使用`top`指令查看

![exec][11]

## 停止守护式容器

### stop
```
$ docker stop 容器名
```
发送停止信号给容器，等待容器的停止。

### kill
```
$ docker kill 容器名
```
直接停止容器。



[1]:https://ns96.com/2018/01/01/docker-start/
[2]:docker-keepgoing/user.png
[3]:docker-keepgoing/hello.png
[4]:docker-keepgoing/itrun.png
[5]:docker-keepgoing/ps.png
[6]:docker-keepgoing/start.png
[7]:docker-keepgoing/rm.png
[8]:docker-keepgoing/pq.png
[9]:docker-keepgoing/log.png
[10]:docker-keepgoing/top.png
[11]:docker-keepgoing/exec.png





