---
title: Docker 曲径通幽
date: 2018-01-20 14:26:34
tags:
 - Docker
---

>前几篇算是对`Docker`做了大致的介绍，和一部分示例测试，这篇来说下一些重要，但是很少去接触的东西，**镜像**。

- [Docker初次见面](https://ns96.com/2018/01/01/docker-start/) - `Docker` 基础概念
- [Docker循序渐进](https://ns96.com/2018/01/05/docker-keepgoing/) - `Docker` 容器的基本操作
- [Docker渐入佳境](https://ns96.com/2018/01/06/docker-justtry/) - `Docker` 容器示例（Nginx）
- [Docker搭建.Net Core环境](https://ns96.com/2018/01/06/docker-dotnetcore-start/) - 部署 `.net Core` 的 `Docker`环境

# Docker Image 镜像管理
早在第一篇介绍 [Docker初次见面](https://ns96.com/2018/01/01/docker-start/) 中就对 `Docker` 的镜像有了说明和介绍，今天再详细的说一下。

**镜像**可谓是容器的基石，而镜像的实质，是一种层叠的只读文件系统，通常存储在 `/var/lib/docker/` 这一目录下，可以使用 `docker info `查看对应的信息。

也可以使用
```
$ sudo ls -l /var/lib/docker
```
进入到目录中查看信息。

当然，通常我们不需要和这些文件夹和文件打交道，因为 `Docker` 已经集成了对应的功能。

## 查看列举镜像
```
$ docker images -a
```

例如上述指令即为查看所有镜像。

其他参数：
- -a :列出本地所有的镜像（含中间映像层，默认情况下，过滤掉中间映像层）
- -digests :显示镜像的摘要信息；
- -f :显示满足条件的镜像；
- --format :指定返回值的模板文件；
- --no-trunc :显示完整的镜像信息（长ID）；
- -q :只显示镜像ID。

![images-a](docker-img/img.png)

上图可以看出， `repository` 表示仓库（可以理解为类型仓库），但是这里的意义不同于 `Registy` 。 `TAG` 表示标签，仓库中不同的镜像是使用标签来进行区分的，通常使用 `仓库名` + `标签名` 来创建容器，但若不指定标签，则默认使用 `latest` 标签。

## 查看镜像详情
```
$ docker inspect ubuntu:latest
```
可以获得镜像的详细信息

## 删除镜像
```
$ docker rmi -f ubuntu
```
强制删除镜像

# 获取和推送镜像
镜像是容器的基础，要搭建容器，就要正确的选择镜像，那么就来说一下怎么来查找-拉取-推送镜像！

## 查找镜像
查找镜像有三种方法，一一简述

**Dockers Hub**

地址：https://registry.hub.docker.com

注意：需要科学上网配合使用人机验证进行注册！


**Docker 命令行工具**

```
$ docker search [OPTION] TERM
```
选项说明：
 - --automated=false 只显示自动匹配的内容
 - --no-trunc=false 同之前，不截断
 - s --stars=0  限定最低星级别

最多返回25个结果

![docker-search](docker-img/search.png)

## 获取镜像
获取命令: `docker pull 仓库名:标签名`
```
$ docker pull ubuntu:16.04
```

另外，这里在之前提到过给 `Docker Registry` 加速的方法，使用 `DaoCloud` 提供加速，推荐方法如下：
```
$ curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://14ff9bc6.m.daocloud.io
$ sudo systemctl restart docker.service
```

## 推送镜像
将已经配置或修改好的镜像推送到HUB

使用指令 `docker push` 来完成，在后面讲完构建镜像后细说。

# 构建自己的镜像
构建镜像的目的是：
 - 保存对容器的修改，并再次使用
 - 自定义镜像的能力
 - 以软件的形式打包并分发服务及其运行环境

## docker commit 通过容器构建
```
$ docker commit [OPTIONs] CONTAINER [REPOSITORY[:TAG]]
```
将指定容器构建为镜像，参数例举:
 - -a , --author Author , 例：“Raphaelli raphael_li@live.com”
 - -m , --message="" Commit message 类似 git 的 -m
 - -p , --pause 提交时暂停容器

依此，可以轻松的将之前配置好的容器发布，并在不同的设备上 `pull` 后使用。

**注意**： `Docker Hub` 只提供了1个免费的私有镜像，因此可以选择使用 aliCloud 和 DaoCloud 的镜像仓库服务。


**注意**： `docker commit` 命令下，所有的镜像造作都是黑箱操作，所以也被俗称为黑箱镜像，因此选择性使用，否则后续的维护和使用会非常困难。可以使用 `docker diff` 来查看历史。


## docker build 通过 Dockerfile 文件构建
镜像的定制实际上就是定制每一层所添加的配置、文件。

如果把每一层修改、安装、构建、操作 的命令都写入一个脚本，用这个脚本来构建、定制镜像，那么之前提及的无法重复的问题、镜像构建透明性的问题、体积的问题就都会解决。这个脚本就是  `Dockerfile`。

还是以 `nginx` 为例，来使用来创建一个 `Dockerfile` 。

`Dockerfile` 的内容如下：
```docker
#First Dockerfile
FROM ubuntu
MAINTAINER raphaelli "raphael_li@live.com" 
RUN apt-get update
RUN apt-get install -y nginx
EXPOSE 80
```

创建目录，创建 `Dockerfile` 文件，并build。

`docker build [OPTIONS] PATH | URL | -` 
- -f :指定要使用的Dockerfile路径；
- -q :安静模式，成功后只输出镜像ID；
- --rm :设置镜像成功后删除中间容器；
- -t :命名

[更多指令](http://www.runoob.com/docker/docker-build-command.html)

创建一个文件夹用于存放 `Dockerfile` 每一个文件夹就相当于一个 `Dockerfile` 。
```docker
$ mkdir -p dockerfile/df_test
$ cd dockerfile/df_test
$ vim Dockerfile
```

粘贴上面的创建信息,然后执行 `docker build` 指令：(进入 `Dockerfile` 所在目录)
```docker
$ docker build -t="nginx-ubuntu" .
```

等待操作完成，每一步操作后会返回一个id作为分层镜像。

然后运行镜像：
```docker
$ docker run -d --name nginx_demo -p 80 nginx-ubuntu nginx -g "daemon off;"
```

# Dockerfile 指令
`Dockerfile` 包含了，注释，指令（大写），参数三个内容，以前面的内容为例：

- `#First Dockerfile` 是注释
- `FROM ubuntu` 指令加参数

`Dockerfile` 有如下几条指令：
- `FROM` FROM <IMAGE> / FROM <IMAGE>:<TAG> 基于某镜像（不指定TAG则默认为lastest） 必须为第一条非注释指令
- `MAINTAINER` 指定镜像的作者信息，通常包含镜像所有者和联系信息
- `RUN`  指定当前镜像中运行的命令
- `EXPOSE` EXPOSE <PORT>[<PORT>…] 指定运行容器使用的端口
- `CMD` 类似 RUN ，区别在于 CMD 在容器运行时执行， RUN 在容器创建时执行
- `ENTERYPOINT` 和CMD一样，但不会被覆盖
- `ADD` 将文件和目录复制到使用 `Dockerfile` 构建的镜像中 
- `COPY` 将文件和目录复制到使用 `Dockerfile` 构建的镜像中 
- `VOLUME` 向容器添加卷 `VOLUME ["/data"]`
- `WORKDIR` 设置工作目录 `WORKDIR /path/to/workdir`（绝对路径） 后续指令的工作目录
- `ENV` 设置环境变量 `ENV<key><value>`
- `USER` 设置镜像用户 `USER daemon`/`USER daemon:group` 默认root
- `ONBUILD` 触发器，当作为其他镜像的基础镜像是，触发器激活，插入指令

**RUN指令 / CMD 容器启动命令/ ENTERYPOINT 指令**

三种指令均是控制容器执行指令，但稍有不同：

* `RUN` 有两种模式，一种为 `RUN <COMMAND>` 即 `shell` 模式:

>其等效于 `/bin/sh -c command `，例如 `RUN echo hello`

另一种为 `RUN ["EXECUTABLE","PARAM1","PARAM2"]` 即 `exec` 模式:
>其等效于使用其他shell，例如 `RUN ["/bin/bash","-c","echo hello"]`



* `CMD` 指令的格式和 `RUN` 相似，也是两种格式：	

>shell 格式：`CMD <命令>`

>exec 格式：`CMD ["可执行文件", "参数1", "参数2"...]`	

>参数列表格式： `CMD ["参数1", "参数2"...]`
在指定了 ENTRYPOINT	 指令后，用 CMD 指定具体的参数.

与 RUN 的区别在于 CMD 在容器运行时执行， RUN 在容器创建时执行。且 CMD 指令会被创建时的指令覆盖。

* ENTERPOINT 与 `RUN` 基本相同，区别在于，若不标识，则不会被创建指令覆盖。


**ADD 和 COPY**

二者的功能都是将文件和目录复制到使用 `Dockerfile` 构建的镜像中。

格式也相同 - 文件地址可以是`本地构架目录的相对地址`或`远程URL`
- 路径无空格 `ADD <src>…<dest>` / `COPY <src>…<dest>`
- 路径有空格 `ADD ["<src>"…"<dest>"]` / `COPY ["<src>"…"<dest>"]`

区别:
- ADD 包含类似 tar 的解压缩功能
- 如果单纯复制文件， Docker 推荐使用 COPY

# Dockerfile 构建过程
先简述过程：
1. 从基础镜像运行一个容器
2. 执行一条指令，并对容器做出修改
3. 对修改后的容器执行类似 docker commit 的操作，提交一个新的镜像层
4. 再基于新的镜像运行一个新容器
5. 执行下一条指令，从而循环 2-4 ，直到所有指令执行完毕

**注意**:分析完安装过程，能从中得，使用中间层镜像进行调试，每一步均为一层，能轻松的重现现场。通过每一步的过程 id ，能够直接运行当前镜像，并从而查找错误。

## 构建缓存
再说下构建缓存，每一个镜像层，都被 Docker 视作缓存。当一次镜像构建完成后，内容实际上都被缓存下来了，再重复构建时，速度很快，切会给出 `Using cache` 字样表示使用了缓存。

但同样的，有些指令，诸如 `RUN apt-get update` 等，不希望使用缓存， Docker 同样提供了方法，参数为 `docker build --no-cache` ，或则在镜像文件 Dockerfile 中添加上时间环境变量 `NEV REFRESH_DATE 20**-**-**` 。

## 查看构建过程
Docker 提供了查看构建过程的指令,即 `docker history [image]`。

指令会返回出镜像 ID ，创建时间，指令和大小信息，并按照顺序列举其过程。