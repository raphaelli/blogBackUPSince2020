---
title: node.js 学习笔记
date: 2016-11-13 21:39:30
tags: 
 - Font-end
---
# node.js学习笔记

> 最近一直在折腾前端，为了方便前端学习，所以打算顺带捡一下之前看过一点的node.js，也就顺手MarkDown一个学习笔记。

# node.js安装
主要开发环境还是windows啦，所以先上win下的安装，之前用过一段时间ubuntu，也是很不错，刚好Qcloud的服务器还没到期，就在Ubuntu下也安装一个。

### win下安装node.js
win下直接就在 [node.js中文网][1] 下载安装就行了。一路Next，版本的话选择LTS的长期支持版本好一点。

win下安装时直接配置好path的，当然，也可以通过安装完后再cmd中输入path查看环境变量是否配置好。

也可以直接输入node，若果能够进入，也表示安装成功。

### ubuntu下安装node.js
在ubuntu下安装，直接就通过更新apt源，然后使用apt安装。
```
//先更新apt源
# apt-get update  
//添加三方apt包
# add-apt-repository ppa:chris-lea/node.js  
//再次更新apt
# apt-get update  
//执行安装
# apt-get install nodejs  
```
在添加apt包和安装时会有提示，均允许就好。
![ubuntu安装成功后界面][2]

# 第一个Node.js程序
如果我们使用PHP来编写后端的代码时，需要Apache 或者 Nginx 的HTTP 服务器，并配上 mod_php5 模块和php-cgi。

从这个角度看，整个"接收 HTTP 请求并提供 Web 页面"的需求根本不需 要 PHP 来处理。

不过对 Node.js 来说，概念完全不一样了。使用 Node.js 时，我们不仅仅 在实现一个应用，同时还实现了整个 HTTP 服务器。事实上，我们的 Web 应用以及对应的 Web 服务器基本上是一样的。

在我们创建 Node.js 第一个 "Hello, World!" 应用前，让我们先了解下 Node.js应用是由哪几部分组成的：

 1. 引入 required 模块：我们可以使用 require 指令来载入 Node.js 模块。
 2. 创建服务器：服务器可以监听客户端的请求，类似于 Apache 、Nginx 等 HTTP 服务器。
 3. 接收请求与响应请求 服务器很容易创建，客户端可以使用浏览器或终端发送HTTP请求，服务器接收请求后返回响应数据。

### 创建 Node.js 应用
**Step1：引入 required 模块**
我们使用 require 指令来载入 http 模块，并将实例化的 HTTP 赋值给变量 http，实例如下:
```
var http = require("http");
```

**Step2：创建服务器**
接下来我们使用 http.createServer() 方法创建服务器，并使用 listen 方法绑定 8888 端口。 函数通过 request, response 参数来接收和响应数据。
实例如下，在你项目的根目录下创建一个叫 server.js 的文件，并写入以下代码：
```
var http = require('http');

http.createServer(function (request, response) {

	// 发送 HTTP 头部 
	// HTTP 状态值: 200 : OK
	// 内容类型: text/plain
	response.writeHead(200, {'Content-Type': 'text/plain'});

	// 发送响应数据 "Hello World"
	response.end('Hello World\n');
}).listen(8888);

// 终端打印如下信息
console.log('Server running at http://127.0.0.1:8888/');
```
以上代码我们完成了一个可以工作的 HTTP 服务器。
使用 node 命令执行以上的代码：
```
node server.js
Server running at http://127.0.0.1:8888/
```
接下来，打开浏览器访问 http://127.0.0.1:8888/，你会看到一个写着 "Hello World"的网页。

**分析Node.js 的 HTTP 服务器：**
第一行请求（require）Node.js 自带的 http 模块，并且把它赋值给 http 变量。
接下来我们调用 http 模块提供的函数： createServer 。这个函数会返回 一个对象，这个对象有一个叫做 listen 的方法，这个方法有一个数值参数， 指定这个 HTTP 服务器监听的端口号。

 

# 安装NPM
NPM是随同NodeJS一起安装的包管理工具，能解决NodeJS代码部署上的很多问题，常见的使用场景有以下几种：

 - 允许用户从NPM服务器下载别人编写的第三方包到本地使用。
 - 允许用户从NPM服务器下载并安装别人编写的命令行程序到本地使用。
 - 允许用户将自己编写的包或命令行程序上传到NPM服务器供别人使用。


### Win下安装npm
win 下安装npm非常方便，只需要输入指令 npm install npm -g
指令自动安装，安装完成后输入 npm -v检查是否安装成功
![windows安装npm][3]

### Ubuntun下安装npm
Ubuntu下安装npm折腾了好久，最后找到了一个合适的安装方法
```
//获取安装脚本
#wget https://npmjs.org/install.sh --no-check-certificate
//添加可执行权限
#chmod 777 install.sh
//执行安装脚本
#./install.sh
//安装成功后检查版本
#npm -v
```
![ubuntu安装npm][4]

**注意：**
这里显示的版本是1.4.28 明显不是最新的版本
可以执行下列命令，对npm进行更新
```
npm install npm -g
```

### 使用 npm 命令安装模块
npm 安装 Node.js 模块语法格式如下：
```
$ npm install <Module Name>
```
看完实例，用npm 命令安装常用的 Node.js web框架模块 express:
```
$ npm install express
```
![npm安装express][5]

安装好之后，express 包就放在了工程目录下的 node_modules 目录中，因此在代码中只需要通过 require('express') 的方式就好，无需指定第三方包路径。
```
var express = require('express');
```
关于Express的使用以及教程移步[Expressjs中文网][6]

### 全局安装与本地安装
npm的包安装分为本地安装（local）、全局安装（global）两种，从敲的命令行来看，差别只是有没有-g而已，比如:
代码如下:复制代码
```
npm install grunt  #本地安装
npm install -g grunt-cli  #全局安装
```
下面分别解释。
#### 全局安装
 npm install xxx -g 时， 模块将被下载安装到【全局目录】中。
【全局目录】通过 npm config set prefix"目录路径" 来设置。

#### 本地安装
通过 npm config get prefix 来获取当前设置的目录。
npm install xxx ，则是将模块下载到当前命令行所在目录。

### 卸载模块
我们可以使用以下命令来卸载 Node.js 模块。
```
$ npm uninstall express
```
卸载后，你可以到 /node_modules/ 目录下查看包是否还存在，或者使用以下命令查看：
```
$ npm ls
```

### 更新模块
我们可以使用以下命令更新模块：
```
$ npm update express
```

### 搜索模块
使用以下来搜索模块：
```
$ npm search express
```
**关于创建模块和package.json的相关内容，先在此略过**

### 更多NPM 常用命令
可以在[npm文档][7]查看官方文档

### 使用淘宝 NPM 镜像
大家都知道国内直接使用 npm 的官方镜像是非常慢的，这里推荐使用淘宝 NPM 镜像。
淘宝 NPM 镜像是一个完整 npmjs.org 镜像，你可以用此代替官方版本(只读)，同步频率目前为 10分钟 一次以保证尽量与官方服务同步。
你可以使用淘宝定制的 cnpm (gzip 压缩支持) 命令行工具代替默认的 npm:
```
$ npm install -g cnpm --registry=https://registry.npm.taobao.org
```
这样就可以使用 cnpm 命令来安装模块了：
```
$ cnpm install [name]
```
全局换源
```
$ npm config set registry https://registry.npm.taobao.org
```

在此感谢淘宝团队，更多信息可以访问[淘宝 NPM 镜像][8]

# Node.js REPL(交互式解释器)

> Node.js REPL(Read Eval Print Loop:交互式解释器) 表示一个电脑的环境，类似 Window 系统的终端或 Unix/Linux shell，我们可以在终端中输入命令，并接收系统的响应。

Node 自带了交互式解释器，可以执行以下任务：

 - 读取 - 读取用户输入，解析输入了Javascript 数据结构并存储在内存中。 
 - 执行 - 执行输入的数据结构 
 - 打印 - 输出结果 
 - 循环 - 循环操作以上步骤直到用户两次按下 ctrl-c 按钮退出。

Node 的交互式解释器可以很好的调试 Javascript 代码。
**输入node来启动node终端**
```
$ node
> 
```

### 简单的表达式运算
接下来让我们在 Node.js REPL 的命令行窗口中执行简单的数学运算：
```
$ node
> 1 +4
5
> 5 / 2
2.5
> 1 + ( 2 * 3 ) - 4
3
>
```

### 使用变量
你可以将数据存储在变量中，并在你需要的使用它。
变量声明需要使用 var 关键字，如果没有使用 var 关键字变量会直接打印出来。
使用 var 关键字的变量可以使用 console.log() 来输出变量。
```
$ node
> x = 10
10
> var y = 10
undefined
> x + y
20
> console.log("Hello World")
Hello World
undefined
> console.log("www.runoob.com")
www.runoob.com
undefined
```

### 多行表达式
Node REPL 支持输入多行表达式，这就有点类似 JavaScript。接下来让我们来执行一个 do-while 循环：
```
$ node
> var x = 0
undefined
> do {
... x++;
... console.log("x: " + x);
... } while ( x < 5 );
x: 1
x: 2
x: 3
x: 4
x: 5
undefined
>
```
**... 三个点的符号是系统自动生成的，你回车换行后即可。Node 会自动检测是否为连续的表达式。**

### 下划线(_)变量
你可以使用下划线(_)获取表达式的运算结果：
$ node
> var x = 10
undefined
> var y = 20
undefined
> x + y
30
> var sum = _
undefined
> console.log(sum)
30
undefined
>


[1]: http://nodejs.cn/
[2]: note-nodejs/1.png
[3]: note-nodejs/2.png
[4]: note-nodejs/3.png
[5]: note-nodejs/4.png
[6]: http://www.expressjs.com.cn/starter/hello-world.html
[7]: https://docs.npmjs.com/
[8]: http://npm.taobao.org/