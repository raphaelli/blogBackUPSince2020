---
title: THE FEYNMAN TECHNIQUE 费曼技巧
date: 2019-01-18 09:07:18
tags:
 - Thinking
---

>不可否认，学习是一门需要技巧的活儿，掌握好的技巧，往往能事半功倍。了解一下 费曼技巧。

# 什么是 Feynman Skill
Richard Phillips Feynman - 诺奖得主，，美国理论物理学家，量子电动力学创始人之一，纳米技术之父。

而费曼技巧，就是费曼的学习方法，英文原文如下：

The Feynman Algorithm:

1. Write down the problem.
2. Think real hard.
3. Write down the solution.

The Feynman algorithm was facetiously suggested by Murray Gell-Mann, a colleague of Feynman, in a New York Times interview.

在网上找到了费曼技巧的实战，内容参考如下：

[原文地址 THE FEYNMAN TECHNIQUE MODEL](https://mattyford.com/blog/2014/1/23/the-feynman-technique-model)

>So now for a recap of the steps:

## Step 1

Write the name of the concept at the top of a blank piece of paper.

## Step 2

Write down an explanation of the concept on the page. Use plain English. Pretend you are teaching it to someone else (e.g a new student). This should highlight what you understand, but more importantly pinpoint what you don't quite know.

## Step 3

Review what you have pinpointed you don't know. Go back to the source material, re-read, and re-learn it. Repeat Step 2.

## Step 4

If you are using overly wordy or confusing language (or simply paraphrasing the source material) try again so you filter the content. Simplify your language, and where possible use simple analogy.

## Conclusion

That's it. A simple and powerful technique to ensure you can rapidly learn and retain new concepts and information. 

# 说人话
前面引用的内容，对费曼技巧做了介绍和实际指导，事实上费曼技巧非常容易操作，且有极大的延展性。

一言以蔽之：
>拿出一张白纸和你所要理解的一本书，然后翻开书本，开始阅读你所要理解的内容，在把所要理解的内容阅读完之后，把你所要理解的知识点概括性的写在你所准备好的白纸上，最后是关键性的观点信息以及过程信息。

费曼技巧，也可以称为四部学习法：

第一步 - 选择一个你想要理解的概念选择一个你想要理解的概念, 然后拿出一张白纸, 把这个概念写在白纸的最上边.

第二步 - 设想一种场景，你正要向别人传授这个概念在白纸上写下你对这个概念的解释, 就好像你正在教导一位新接触这个概念的学生一样. 当你这样做的时候, 你会更清楚地意识到关于这个概念你理解了多少, 以及是否还存在理解不清的地方.

第三步 - 如果你感觉卡壳了, 就回顾一下学习资料无论何时你感觉卡壳了, 都要回到原始的学习资料并重新学习让你感到卡壳的那部分, 直到你领会得足够顺畅, 顺畅到可以在纸上解释这个部分为止.

第四步 - 为了让你的讲解通俗易懂，简化语言表达最终的目的, 是用你自己的语言, 而不是学习资料中的语言来解释概念. 如果你的解释很冗长或者令人迷惑, 那就说明你对概念的理解可能并没有你自己想象得那么顺畅 -- 你要努力简化语言表达, 或者与已有的知识建立一种类比关系, 以便更好地理解它。





