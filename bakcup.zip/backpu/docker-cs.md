---
title: Docker 俯瞰深溪
date: 2018-01-26 21:17:48
tags:
 - Docker
---

- [Docker 初次见面](https://ns96.com/2018/01/01/docker-start/) - `Docker` 基础概念
- [Docker 循序渐进](https://ns96.com/2018/01/05/docker-keepgoing/) - `Docker` 容器的基本操作
- [Docker 渐入佳境](https://ns96.com/2018/01/06/docker-justtry/) - `Docker` 容器示例（Nginx）
- [Docker 搭建 .Net Core环境](https://ns96.com/2018/01/06/docker-dotnetcore-start/) - 部署 `.net Core` 的 `Docker`环境
- [Docker 曲径通幽](https://ns96.com/2018/01/20/docker-img/) - `Docker` 镜像管理相关

>这篇来说下，`Docker` 基本架构和一些偏底层的东西。

# C/S模式
先从 Docker 的 C/S 模式说起。

Docker 采用了 C/S架构，包括客户端和服务端。 

Docker daemon 作为服务端接受来自客户的请求，并处理这些请求（创建、运行、分发容器）。

客户端和服务端既可以运行在一个机器上，也可通过	socket	或者 Remote API (RESTful API) 来进行通信。

关于什么是 RESTful 可以参考阮一峰老师的 [理解RESTful架构](http://www.ruanyifeng.com/blog/2011/09/restful.html)。

![cs](docker-cs/cs.png)

>简单来说，就是把 Docker 运行在宿主机上的守护进程当作 C/S 中的 Server ,而用户实际使用的是 Docker CLI客户端 也就是 Client ， Clinet 和 Server 中通过命令并返回执行结果来交互。

前面提到了 socket 和 RemoteAPI ,其中 RemoteAPI 提供交互，那么 Socket 呢，则是提供链接。

Docker 支持三种链接方式：
- unix:///var/run/docker.sock
- tcp://host:port
- fd://socketfd

通过这些链接方式，就可以实现对客户端/服务端的访问。

# Docker 容器网络
通过 ifconfig 指令，能够发现在网络设备中存在一个 docker0 ，它的本质是一个 Linux 的[虚拟网桥-这里了解更多](https://www.cnblogs.com/zmkeil/archive/2013/04/21/3034733.html)，为 Docker 的容器提供网络服务。

## 容器互联

## 容器与外部网络链接




