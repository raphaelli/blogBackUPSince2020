---
title: Windows下JavaWeb环境的安装笔记
date: 2017-09-03 20:29:29
tags:
 - Other
---

> 写在前面：专升本报道开课，这个学期的课程中开了JavaWeb和Oracle数据库，作为软狗虽然一百个不愿意，但是学习为重嘛。Oracle数据库之前在吉奥实习的时候多少有过接触，而且基于T-Sql语言和MySql和SQLServer的了解，掌握起来问题应该不大。而JavaWeb虽然之前有专门开课学习，但是当时正好外出实习，虽然着仅有的Java基础和Asp.Net的相似性，但是还是做一个系列笔记，以便日后查阅。

## 介绍JSP
>**JSP** : Java Server Page 即在传统的HTML文件(`*htm`,`*.html`)中加入Java程序片段(`Scriptlet`)和JSP标记(`tag`)，就构成了JSP网页。

JSP引擎（Tomcat、JRun、Resin等）依赖Java引擎（JavaSE），关于java引擎，这里也简要区分一下：
- JavaSE 可以开发和部署在桌面、服务器、嵌入式环境和实时环境中使用的 Java 应用程序。是EE，和ME的基础。一般就是指JDK。就是Java的基础语法（变量、方法、类之间的调用、关系，继承、接口、线程之类的），工具包（java.util.*  ）,或者其他的一些封装
- JavaEE，其实是一套规范，就是用java语言做企业开发中的一整套规范，比如类怎么封装，网页的请求要用什么方法处理，语言编码一类的处理，拦截器啊什么的定义，请求返回得有什么信息（具体参看servlet的接口）比如：tomcat就是按照这套规范开发的容器软件，还有weblogic，JBoss、Resin等等正因为我们开发网站（使用JSP，Servelet或者封装了这些的框架：SSH）可以放在tomcat，也可以放在JBoss，因为都是按照一个规范开发的东西，实际使用的还是JavaSE的那些东西，多出来的就是EE的一些规范类的封装代码。
- JavaME 是微型版本，顾名思义，使用在手机啊，小设备啊上面的Java版本，特点就是小，相比JavaSE精简了很大一部分东西

所以，三者之间的关系是 JSP引擎（Tomcat）》依赖》Java引擎（JavaSE）  
那么下面先下载JDK-Java SE Development Kit（JavaSE开发工具包，简称JDK）

## 安装JDK 
[JDK官方下载地址](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)  

### 下载对应版本JDK
挑选适合版本（不一定要求最新）以及对应操作系统版本的JDK，然后下载。
![下载对应版本JDK](win-jsp/djdk.jpg)

### 安装JDK
![安装JDK](win-jsp/injdk.jpg)

点击**下一步**，推荐使用**默认目录**安装jdk，然后继续**下一步**！

![设置路径](win-jsp/lujdk.jpg)

然后等待安装完成

![安装完成](win-jsp/dnjdk.jpg)

### 配置Java环境变量
参考下图打开环境变量配置（win10）

![打开环境变量配置](win-jsp/jpt.jpg)

#### 先设置JAVA_HOME
>JAVA_HOME指明JDK安装路径  

在**系统变量**中点击**新建**    
在弹出的界面中填入变量名`JAVA_HOME`  
在变量值中填入jdk的目录（图示为默认安装目录，参考目录内容）  
`C:\Program Files\Java\jdk1.8.0_144`
![`Path`添加JDK变量](win-jsp/cpjdk.jpg)

#### 为`Path`添加JDK变量
>Path使得系统可以在任何路径下识别java命令

编辑**系统变量**中的Path变量，选择编辑文本，在开头添加如下文本
`
%JAVA_HOME%/bin;%JAVA_HOME%/jre/bin; 
`

![`Path`添加JDK变量](win-jsp/pajdk.jpg)

#### 添加`CLASSPATH`
>CLASSPATH为java加载类(class or lib)路径，只有类在classpath中，java命令才能识别

在**系统变量**中点击**新建**    
在弹出的界面中填入变量名`classpath`  
在变量值中填入
`.;%JAVA_HOME%/lib/dt.jar;%JAVA_HOME%/lib/tools.jar`  
**注意：要加.表示当前路径**
![设置classpath](win-jsp/clajdk.jpg)

#### 验证
在**控制台**（Win+R）运行（CMD）
```
java -version
java
javac
```
三条指令，检查是否配置完成

## Tomcat
安装好JDK并配置好环境变量之后只是完成了一部，想要搭建好JavaWeb的环境还需要安装Tomcat服务

### 下载Tomcat
[Tomcat官方下载地址](https://tomcat.apache.org/download-90.cgi)

选择对应操作系统及tomcat版本下载
![Tomcat下载](win-jsp/tomd.jpg)  
选择
`32-bit/64-bit Windows Service Installer`

### 安装Tomcat
![Tomcat](win-jsp/tom.jpg)  

**默认安装一路Next **

如果电脑上存在其他的web服务（如IIS/Nginx等)可以修改默认端口

![web访问](win-jsp/web.jpg)  

安装完成后，通过浏览器输入本地地址加端口号验证

默认 `http://localhost:8080/`

### Tomcat基础配置
tomcat默认安装完成后就可以启动使用，但是为了使用方便，可以简要坐下基本配置。  
#### 设置登录账号
在tomcat7及后续版本中，增加了web控制台，可以通过修改设置（或在安装在设置）来启动并使用账号密码登录控制台进行管理。  
参考上图中的位置，点击**Manager App**就会弹出登录窗口

这里的账号，可以在Tomcat的安装目录中的`conf`文件夹中的`tomcat-users.xml`文件中修改  
在`tomcat-users.xml`中的`<tomcat-users> …… </tomcat-users>`中添加如下内容：
```
<role rolename="admin-gui"/>
<role rolename="admin-script"/>
<role rolename="manager-gui"/>
<role rolename="manager-script"/>
<role rolename="manager-jmx"/>
<role rolename="manager-status"/>
<user username="改为用户名" password="改为密码" roles="manager-gui,manager-script,manager-jmx,manager-status,admin-script,admin-gui"/>
```

修改后保存，然后重启**tomcat服务器**,访问页面  

登陆后即可看到Application的查看和部署页面
![web管理](win-jsp/tomweb.jpg)  

## 测试JSP页面
使用IDE（MyEclipse或者IDEA等编辑并发布一个站点）


页面内容为：
```
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
  <head>
    <title>hello</title>
  </head>
  <body>
  <%
    out.print("hello world!");
  %>
  </body>
</html>
```

![web管理](win-jsp/hw.jpg)  