---
title: SSH 常用指令
date: 2018-04-15 22:13:47
tags:
 - Linux
---

> 最近要频繁使用服务器，但是 SSH 的指令总是抬手就忘，整理下便于查看！



# 连接

## 无参连接

```Sh
$ ssh 192.168.2.2
```

第一次连接目标主机时，ssh 会让你确认目标主机的真实性。如果你回答的是 NO，SSH 将不会继续连接，只有回答 Yes才会继续。下一次再登陆此主机时，SSH 就不会提示确认消息了。对此主机的真实验证信息已经默认保存在每个用户的 /home/user/.ssh 文件里。



## 指定登陆用户

```Sh
$ ssh -l raphael 192.168.2.2
# 或则
$ ssh raphael@192.168.2.2
```



# 文件传输 SCP	

## 本地到服务器

scp  文件路径 用户名@Server地址:/path/of/the/file

```Sh
$ scp test.html root@192.168.2.2:/home/www/test.html
```

## 服务器到本地

scp 用户名@Server地址:/path/of/the/file 文件路径

```Sh
$ scp root@192.168.2.2:/home/www/test.html ~/Downloads/test.html
```

### 传送文件夹

scp -r 文件路径 用户名@Server地址:/path/of/the/folder

```Sh
$ scp -r folderToCopy root@192.168.2.2:/home/www/test
$ scp root@192.168.2.2:/home/www/ ~/Downloads/
```



# tar 压缩 相关

**将文件全部打包成tar包**：

```sh
tar -cvf log.tar log2012.log    仅打包，不压缩！ 
tar -zcvf log.tar.gz log2012.log   打包后，以 gzip 压缩 
tar -jcvf log.tar.bz2 log2012.log  打包后，以 bzip2 压缩 
```

**查阅上述tar包内有哪些文件**：

```sh
tar -ztvf log.tar.gz
```

由于我们使用 gzip 压缩的log.tar.gz，所以要查阅log.tar.gz包内的文件时，就得要加上`z`这个选项了。

**将tar包解压缩**：

```sh
tar -zxvf /download/log.tar.gz
```



# 其他

连入服务器后的其他指令即为 Linux 下常用的命令操作，不再赘述，后续有新的笔记内容再行添加。