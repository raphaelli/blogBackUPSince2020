---
title: Ubuntu下配置JavaWeb开发环境
date: 2017-09-07 19:19:25
tags:
 - Linux
---

>还是JSP环境，最近上了两节JSP的课了，基本上对于JavWeb的基础介绍也说的差不多了，按照课程安排应该是要进入到页面基础内容的阶段了，所以差不多也要把JSP的开发环境弄好了。物理机开发.net，所以不想把Java环境安装在物理机上，就用了虚拟机和ubunut，反正之前用过很长一段时间的Ubuntu，不是用日常软件只是开发环境的话，安装和配置应该很轻松，所以采用Jdk+Tomcat+MySQL+IDEA的开发环境。

## JDK 安装
其实Ubuntu下的JDK安装比Win下更为简便
```
# sudo su  
# apt-get update
# apt-get -y install default-jdk
```
上面三条指令依次是，提升权限（Root），更新软件源，安装Jdk  

![JDK安装][1]

## 安装Tomcat8
### 配置用户和组
在安装Tomcat8之前，处于安全性的考虑，应该为Tomcat创建一个新用户和组。
```
# sudo groupadd tomcat
# sudo useradd -s /bin/false -g tomcat -d /opt/tomcat tomcat
```
tomcat用户属于tomcat组，home目录是/opt/tomcat，我要把tomcat安装在这个目录。/bin/false代表这个用户是不能登录的。

安装Tomcat，这里使用wget/curl获取并安装
```
cd /tmp
curl -O http://mirrors.tuna.tsinghua.edu.cn/apache/tomcat/tomcat-8/v8.5.20/bin/apache-tomcat-8.5.20.tar.gz
```

![配置并获取][2]

### 安装 tomcat8

创建/opt/tomcat目录：
```
$ sudo mkdir /opt/tomcat
```

把下载的tar包解压到上面创建的目录：

```
$ sudo tar xzvf apache-tomcat-8*tar.gz -C /opt/tomcat --strip-components=1
```

![tomcat安装][3]

### 变更权限

赋给tomcat用户各种权限：


```
$ cd /opt/tomcat
```

tomcat用户可以访问conf目录：

```
$ sudo chgrp -R tomcat conf
$ sudo chmod g+rwx conf
$ sudo chmod g+r conf/*
```

修改各种目录的所有者：
```
$ sudo chown -R tomcat webapps/ work/ temp/ logs/
```
![权限][4]

### 配置开机启动
我们需要把tomcat配置为服务，为了做到这一点，需要创建systemd服务配置文件。

Tomcat需要知道java的安装路径；使用下面命令查看Java安装路径：
```
$ sudo update-java-alternatives -l
```

然后在/etc/systemd/system目录创建服务文件tomcat.service：

```
$ sudo gedit /etc/systemd/system/tomcat.service
```

然后编辑如下内容

```
[Unit]
Description=Apache Tomcat Web Application Container
After=network.target

[Service]
Type=forking

Environment=JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64/jre
Environment=CATALINA_PID=/opt/tomcat/temp/tomcat.pid
Environment=CATALINA_HOME=/opt/tomcat
Environment=CATALINA_BASE=/opt/tomcat
Environment='CATALINA_OPTS=-Xms512M -Xmx1024M -server -XX:+UseParallelGC'
Environment='JAVA_OPTS=-Djava.awt.headless=true -Djava.security.egd=file:/dev/./urandom'

ExecStart=/opt/tomcat/bin/startup.sh
ExecStop=/opt/tomcat/bin/shutdown.sh

User=tomcat
Group=tomcat

[Install]
WantedBy=multi-user.target
```

替换JAVA_HOME的值，注意在路径后加jre；上面配置内存要根据需要修改。

![开机启动][5]

修改完成之后，重新加载systemd：

```
$ sudo systemctl daemon-reload
```

启动tomcat：
```
$ sudo systemctl enable tomcat
$ sudo systemctl start tomcat
```

确认tomcat已启动：
```
# sudo systemctl status tomcat
```








[1]: ubuntu-jsp/injdk.png
[2]: ubuntu-jsp/2.png
[3]: ubuntu-jsp/3.png
[4]: ubuntu-jsp/quanxian.png
[5]: ubuntu-jsp/kjqd.png