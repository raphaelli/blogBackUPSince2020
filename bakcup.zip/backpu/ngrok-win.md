---
title: Ngrok编译Windows下客户端和相关配置
date: 2017-1-24 18:55
tags:
 - Linux
---

> 上一篇文章实现了Ngrok在Ubuntu服务端和Ubuntu的内网穿透代理到外网，那么基于现有的ubuntu服务端，如何让运行在win下的web服务或其他服务公布到外网呢。

---

## 配置客户端
首先肯定是配置win下的Ngrok的客户端。  
其实和编译ubuntu客户端一样，只需要一条指令就可以了  
在ngrok目录下  
```
# GOOS=windows GOARCH=amd64 make release-client
```
编译完成后，会自动生成一个名为windows_amd64的文件夹，里面有一个ngrok的文件。同样配置好ngrok.cfg之后，执行命令，这里换成了win下的命令行执行。  
```
server_addr: “ngrok.mdzz2333.cn:4443"
trust_host_root_certs: false
```
--------------------------ngrok.cfg内容

执行指令：
```
#./ngrok -subdomain pub -proto=http -config=ngrok.cfg 80
```

这里就成功的将80端口转发出去了。

下面再说一下，如何外网访问22端口的ssh
```
# ./ngrok -proto=tcp -config ngrok.cfg 22
```
![启动转发](ngrok-win/1.png)

---

## 使用putty链接
![putty](ngrok-win/2.png)  

成功登陆

![putty](ngrok-win/3.png)

---

## 附：启动指令解析即常用属性
![指令&属性](ngrok-win/4.png)