---
title: 静态博客hexo添加访问计数功能
date: 2017-09-18 09:13:36
tags:
 - Other
---
> 博客迁移到Github并使用Hexo也有快一个月时间了，把很多之前的技术文章和笔记整理过来之后，打算把博客在完善一下，试着自己给博客增加一个页面访问计数的功能。在搜索后决定使用[不蒜子](http://busuanzi.ibruce.info/)的计数脚本。

不蒜子的添加非常简单，打开themes/你的主题`/layout/_partial/footer.ejs`添加如下脚本即可

```
<div>
    <script async src="https://dn-lbstatics.qbox.me/busuanzi/2.3/busuanzi.pure.mini.js"></script>

    本站总访问量 <span id="busuanzi_value_site_pv"></span> 次&nbsp&nbsp&nbsp 本站访客数
    <span id="busuanzi_value_site_uv"></span>人次&nbsp&nbsp&nbsp 本页阅读量<span id="busuanzi_value_page_pv"></span>次
    </div>
```