---
title: EntityFramework 介绍
date: 2017-12-07 10:31:12
tags:
 - dotNET
---

# 什么是Entity Framework

微软官方提供的ORM工具，ORM让开发人员节省数据库访问的代码时间，将更多的时间放到业务逻辑层代码上。EF提供变更跟踪、唯一性约束、惰性加载、查询事物等。开发人员使用Linq语言，对数据库操作如同操作Object对象一样省事。

EF有三种使用场景:
 1. 从数据库生成Class,  
 2. 由实体类生成数据库表结构，
 3.  通过数据库可视化设计器设计数据库，同时生成实体类。 


>O/RM是什么？
ORM 是将数据存储从域对象自动映射到关系型数据库的工具。ORM主要包括3个部分：域对象、关系数据库对象、映射关系。ORM使类提供自动化CRUD，使开发人员从数据库API和SQL中解放出来。 

![EntityFramework][1]


# Entity Framework 架构

![EF架构][2]

- EDM （实体数据模型）：EDM包括三个模型，概念模型、 映射和存储模型。

- 概念模型 ︰ 概念模型包含模型类和它们之间的关系。独立于数据库表的设计。

- 存储模型 ︰ 存储模型是数据库设计模型，包括表、 视图、 存储的过程和他们的关系和键。

- 映射 ︰ 映射包含有关如何将概念模型映射到存储模型的信息。

- LINQ to Entities ︰ LINQ to Entities 是一种用于编写针对对象模型的查询的查询语言。它返回在概念模型中定义的实体。

- Entity SQL: Entity SQL 是另一种炉类似于L2E的言语，但相给L2E要复杂的多，所以开发人员不得不单独学习它。

- Object Services(对象服务)：是数据库的访问入口，负责数据具体化，从客户端实体数据到数据库记录以及从数据库记录和实体数据的转换。

- Entity Client Data Provider：主要职责是将L2E或Entity Sql转换成数据库可以识别的Sql查询语句，它使用Ado .net通信向数据库发送数据可获取数据。

- ADO .Net Data Provider：使用标准的Ado.net与数据库通信 

# Entity Framework运行环境

EF5由两部分组成，EF api和 .net framework 4.0/4.5，而EF6是独立的EntityFramework.dll，不依赖 .net Framework。使用NuGet即可安装EF。 

![EF5.0运行环境][4]
![EF6.0运行环境][3]

[1]: ef-note/ef1.png
[2]: ef-note/ef2.png
[3]: ef-note/ef3.png
[4]: ef-note/ef4.png

