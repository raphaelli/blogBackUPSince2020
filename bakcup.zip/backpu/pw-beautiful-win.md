---
title: Powershell 美化和 Win 包管理工具
date: 2019-01-02 11:05:07
tags:
 - Other
---

>Powershell 用起来的实际体验其实还是非常优秀的，特别是在 Linux 使用多了之后，再回到win 上来，总是习惯性的开启 PowerShell 来执行一些指令进行操作。 然而 Powershell 的蓝底白字未免有些不太养眼，于是在王少找到了 'oh-my-posh' 的美化插件。 该插件可以使用 Chocolatey 来安装，于是顺带说说 Chocolatey 这个win 下的包管理工具。

### 安装 Chocolatey
>Chocolatey is a package manager for Windows (like apt-get or yum but for Windows). It was designed to be a decentralized framework for quickly installing applications and tools that you need. It is built on the NuGet infrastructure currently using PowerShell as its focus for delivering packages from the distros to your door, err computer.
Chocolatey是Windows的软件包管理器（如apt-get或yum，但适用于Windows）。
它被设计为一个分散的框架，用于快速安装所需的应用程序和工具。
它建立在NuGet基础设施上，主要使用在PowerShell中。

PowerShell 安装 Chocolatey 非常简单，管理员运行，然后输入如下指令
```sh
Set-ExecutionPolicy Bypass -Scope Process -Force; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))

```

### 安装 ConEmu 优化使用体验
>ConEmu-Maximus5 aims to be handy, comprehensive, fast and reliable terminal window where you may host any console application developed either for WinAPI (cmd, powershell, far) or Unix PTY (cygwin, msys, wsl bash).
ConEmu-Maximus5旨在提供方便，全面，快速和可靠的终端窗口，您可以在其中托管为WinAPI（cmd，powershell，far）或Unix PTY（cygwin，msys，wsl bash）开发的任何控制台应用程序。

借助刚才安装的 Chocolatey 来安装 Conemu

```sh
choco install ConEmu
```

### 安装美化插件

安装 posh-git 和 oh-my-posh：

```sh
Install-Module posh-git -Scope CurrentUser
Install-Module oh-my-posh -Scope CurrentUser
```

如果在PS Core上运行此功能，请确保已经安装PSReadLine的2.0.0-beta1版本
```sh
Install-Module -Name PSReadLine -AllowPrerelease -Scope CurrentUser -Force -SkipPublisherCheck
```

请编辑PowerShell配置文件,启用：
```sh
if (!(Test-Path -Path $PROFILE )) { New-Item -Type File -Path $PROFILE -Force }
notepad $PROFILE
```

将以下行附加到PowerShell配置文件：
```sh
Import-Module posh-git
Import-Module oh-my-posh
Set-Theme Paradox
```

#### 错误提示
系统提示无法运行脚本：

参考 MSDN 解决办法 - https://docs.microsoft.com/zh-cn/previous-versions/windows/powershell-scripting/hh847748(v=wps.640)

因此，需要把 about_Execution_Policies 的策略调整为  UNRESTRICTED 或更低

在管理员模式下运行 Powershell ，使用如下指令：
```sh
 Set-ExecutionPolicy -ExecutionPolicy UNRESTRICTED
```

#### 样式优化
更多样式优化和其他内容，可以参阅作者 [Github 页面](https://github.com/JanDeDobbeleer/oh-my-posh)
