---
title: Ubuntu 下安装 MSSQL 2017 部分问题
date: 2018-11-16 12:10:04
tags:
 - Other
---


在安装MSSQL 2017 遇到一个问题：
```sh
sqlservr: This program requires a machine with at least 2000 megabytes of memory.
```

这是 MSSQL 2017 安装的内存要求，这里是2G，而实际上，没有2G的内存运行MSSQL也是没有任何问题的，那么怎么来修改呢？

进入目录，修改代码：

```sh
cd /opt/mssql/bin/ # 进入目录 
mv sqlservr sqlservr.old # 保存备份文件 
python # 使用python修改内存限制代码
```

```py
  >>>oldfile = open("sqlservr.old", "rb").read()
  >>>newfile = oldfile.replace("\x00\x94\x35\x77", "\x00\x80\x84\x1e")
  >>>open("sqlservr", "wb").write(newfile)
  >>>exit()
```

修改后，内存限制被缩小为 512 兆字节，下面正常安装即可。
```sh
sudo /opt/mssql/bin/mssql-conf setup
```


> **注意修改权限**
之前新建的`sqlservr`可能会权限不足，进入目录后，给该文件一个 775 权限即可正常安装。


# 为Docker 中的容器解决该问题
暂缺，待解决

# SQL Server 2017 中文乱码
如果数据库的Collocation是英文的，字段是varchar类型，向表中插入中文数据，会出现乱码。

## 创建时指定
```sql
USE master;  
GO  
IF DB_ID (N'MyOptionsTest') IS NOT NULL  
DROP DATABASE MyOptionsTest;  
GO  
CREATE DATABASE MyOptionsTest  
COLLATE Chinese_PRC_CS_AS_WS 
GO  
```


解决方法：

## 方法1. 
修改varchar 为 nvarchar类型， 并在插入数据前加N，例如： insert into table_name(a) values (N'中文')

## 方法2. 
如果不修改字段类型，还是varchar， 则需要修改数据库的Collocation为 中文，


## 还有一种
在建表时，指定某个字段的语言，

方法 COLLATE Chinese_PRC_CS_AS_WS

示例：
```sql
create table test
(
a varchar(255) COLLATE Chinese_PRC_CS_AS_WS NULL, 
b varchar(255) COLLATE sql_latin1_general_cp1_ci_as NULL 
)
```
若是使用存储过程插入数据的话，需要将对应的参数类型改为nvarchar。

示例：
```sql
create PROCEDURE [dbo].[export_Create] 

@C_HM nvarchar(128) 
AS 
INSERT INTO export 
([C_CCH]) 
values 
(@C_HM) 
```
在表格中,C_CCH为varchar类型。