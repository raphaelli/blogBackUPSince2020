---
title: HTTP/HTTPS 与无状态协议
date: 2019-04-01 09:14:10
tags:
 - Other
---



> 改完bug，休息水群，群里有个朋友问，HTTPS是否也是无状态的协议，如果是，那每次握手都需要进行加解密校验，岂不是非常费时，在网上查了之后在群里讨论了一会儿，整理记录一下。



# HTTP 

先从HTTP说起。



超文本传输协议（英语：HyperText Transfer Protocol，缩写：HTTP）是一种用于分布式、协作式和超媒体信息系统的应用层协议。HTTP是万维网的数据通信的基础。设计HTTP最初的目的是为了提供一种发布和接收HTML页面的方法。



而对于开发者来说比较重要的是，HTTP的三次握手，和HTTP的报文信息。



三次握手的意义在于：

**为了保证服务端能收接受到客户端的信息并能做出正确的应答而进行前两次(第一次和第二次)握手，为了保证客户端能够接收到服务端的信息并能做出正确的应答而进行后两次(第二次和第三次)握手。**



例如A和B通讯：

A->B: Hello, can you hear me?

B->A: Yeah,can you hear me?

A->B: Ok, than we beginning talking!



<https://github.com/jawil/blog/issues/14>