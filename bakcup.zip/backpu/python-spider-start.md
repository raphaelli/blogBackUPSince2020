---
title: Python爬虫学习之旅-从基础开始
date: 2018-01-09 15:15:49
tags:
 - Other
---

>很早就想学习爬虫了，但是一直没有开始。18年给自己定了很多学习计划，大体还是循序渐进的，整理下思路，`Docker`容器化和`Python`爬虫应该是摆在前置位的，算是基础。`Web`方面，`dotNet Core`感觉有点陷入僵局了，只好暂且放一放，转而学习下`Python`的爬虫和Web框架-`Django`等，算是换换思路。Talk is cheap，show me the code！

# 爬虫原理
知其然，知其所以然。使用爬虫，必须要先理解爬虫的原理，先说下爬虫的基本流程和基本策略。

## 爬虫的基本流程
网络爬虫的基本工作流程如下：
- 提供种子URL
- 任务队列开始处理种子URL
- 根据URL，解析DNS，下载URL相对应的网页，存储已下载网页，将URL归入已抓取URL队列。
- 分析已抓取URL队列，将URL中的内链放入待抓取URL队列，进行循环
- 解析下载网页，获取所需数据
- 存入数据库，数据持久化处理

![Spider原理](python-spider-start/spiderre.png)

## 爬虫的基本策略
在爬虫系统中，待处理URL队列是很重要的一部分。待处理URL队列的处理顺序也很重要，因为这涉及到抓取页面的顺序，而决定这些URL队列排序的方法，叫做抓取策略。

这里例举两种常用的策略方法：
- DFS(深度优先策略) 深度优先策略是指爬虫从某个URL开始，一个链接一个链接的爬取下去，直到处理完了某个链接所在的所有线路，才切换到其它的线路。 此时抓取顺序为：A -> B -> C -> D -> E -> F -> G -> H -> I -> J

- BFS(广度优先策略) 宽度优先遍历策略的基本思路是，将新下载网页中发现的链接直接插入待抓取URL队列的末尾。也就是指网络爬虫会先抓取起始网页中链接的所有网页，然后再选择其中的一个链接网页，继续抓取在此网页中链接的所有网页。 此时抓取顺序为：A -> B -> E -> G -> H -> I -> C -> F -> J -> D

![策略模型](python-spider-start/cl.png)

# 爬虫工具
工欲善其事，必先利其器。

实现Python爬虫，一些得力助手是必不可少的，下面一一介绍一下。

## anaconda 
 [anaconda官网](https://www.anaconda.com/) - 是Python的一个科学计算的发行版。

 这里以官方最新版本（18/1/10）`3-5.0.1`为例，通过安装脚本安装(Ubuntu环境)。

 事实上，win下的安装更为简单，也可以配合PyCharm食用更佳。

 因为资源在国外，所以下载速度很慢，可以使用[清华大学镜像源](https://mirror.tuna.tsinghua.edu.cn/help/anaconda/)

```
$ wget 
https://mirrors.tuna.tsinghua.edu.cn/anaconda/archive/Anaconda3-5.0.1-Linux-x86_64.sh
$ bash Anaconda3-5.0.1-Linux-x86_64.sh
```
下载并执行脚本后，按照提示逐步安装。

## Requests
[Requests官方文档](http://docs.python-requests.org/zh_CN/latest/user/quickstart.html) - 是一个urllib的升级版本打包了全部功能并简化了使用方法。

python 安装模块十分方便，直接使用`pip`指令安装
```
$ pip install requests
```

当然，因为安装的是 `python` 的 `anaconda` 发行版，所以也可以使用 `conda` 指令进行安装。

```
$ conda install requests
```

## LXML
一个HTML解析包 用于辅助beautifulsoup解析网页。
```
$ pip install lxml
```

## BeautifulSoup
[BeautifulSoup官方文档](http://beautifulsoup.readthedocs.io/zh_CN/v4.4.0/#) - 是一个可以从HTML或XML文件中提取数据的Python库.它能够通过你喜欢的转换器实现惯用的文档导航,查找,修改文档的方式。对于初学者而言，体验大大由于使用正则表达式自行匹配。

```
$ pip install beautifulsoup4
```

![安装](python-spider-start/inst.png)

# 简单爬虫测试
先来创建第一个脚本，这里默认已有`Python`基础。


```python
#!/usr/bin/env python
# coding=utf-8

import requests ## 导入requests
from bs4 import BeautifulSoup ## 导入bs4中的BeautifulSoup
import os

## 浏览器请求头信息，模拟浏览器
headers = {'User-Agent':"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1(KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1"}

## 开始的URL地址
all_url = 'http://www.mzitu.com/all'  

## 使用requests中的get方法来获取all_url
start_html = requests.get(all_url,headers=headers)  

## 打印出start_html 
print(start_html.text) 

```

执行后获取并列出妹子图所有的标题和链接。

这就是一个最简单的爬虫示例。