---
title: .NET Core 实战笔记1-介绍和安装
date: 2017-11-21 19:35:49
tags:
 - dotNET
---

## .NET Core介绍
按照国际惯例，先介绍一下什么是 .NET core(也写成dotNet core啦)。  

> .NET Core是 .NET Framework的新一代版本，是微软开发的第一个具有跨平台能力的应用程序开发框架，也被称为是开源.NET平台Mono的官方替代品。

说到 .NET Framework，这里就不在赘述，查看链接[ .NET Framework概述](https://ns96.com/2017/11/20/whats-dotNet/)  

## 与 .NET Framework的关系
.NET Core是跨平台的 .net平台，因此 .NET Core包含了 .NET Framework的类库，而不同的是，.NET Core采用包（packages）的管理方式，通过nuget按需添加，不再硬性要求应用程序跟随主线版本。

.NET Core通常情况下被理解为 .NET Framework的超集，一方面，.NET Core实现了 .NET Framework的跨平台，另一方面，.NET Core包含了 .NET Framework的类库。


## .NET Core 都有啥
.NET Core由许多项目组成，包含基本类库（Corefx），采用RyuJIT编译的运行平台Core CLR，编译平台 .NET Compiler Platform，采用AOT编译技术运行最优化的包Core RT（.NET Core Runtime）,以及跨平台的MSIL编译器LLILC（LLVM-based MSIL Compiler）等项目。

- `RyuJIT`是微软发展的新式即时编译器（Just-in-time Compiler），用以代替现有的 .NET Framework的JIT以及JIT64即时编译器。
- `Core CLR`移植了 .NET Framework的CLR的功能，包含核心程序库mscorlib，JIT编译器，GC（垃圾回收）以及其他运行MSIL（通用中间语言）所需的运行时环境。
- `Core RT`是以AOT(Ahead-of-time)便宜方式为主的核心功能，其会在构建时期编译时将MSIL转换成平台本地的机器码，在Windows中使用 .NET Native ,在 Mac OSX与Linux上使用的是LLILC(支持JIT和AOT)。
- `LLILC`（LLVM-based MSIL Compiler）即 .NET Core非Windows平台的MSIL编译器。
- `Roslyn`是.NET Compiler Platform的项目代码，即 .NET平台的编译架构标准化平台。提供程序管理工具等，诸如类型信息，语法结构，参考链接，语义编译器自动化等信息。

## 下载安装
官方下载安装链接：
- [windows下安装](https://www.microsoft.com/net/download/windows)  
- [Mac OS安装](https://www.microsoft.com/net/download/macos)  
- [Linux下安装](https://www.microsoft.com/net/download/linux)  
>Linux以Ubuntu为例，推荐使用apt方式安装——[ubuntu下apt安装](https://www.microsoft.com/net/learn/get-started/linuxubuntu)

## 确认 dotnet -info
使用终端/CMD/PowerShell输入dotnet -info确认安装完成