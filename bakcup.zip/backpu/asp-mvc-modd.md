---
title: ASP.NET MVC学习笔记05模型与访问数据模型
date: 2017-05-20 8:26:18
tags:
 - dotNET
---
> 上一篇使用的M模型，并不是真正意义上的Model，现在来添加一些类，并将这些类用来管理数据库中数据（电影）。而这些类，就是ASP.NET MVC中的Model（模型）。

---

而这里也将使用.NET Framework数据访问技术Entity Framework 来定义和使用这些模型类。Entity Framework（简称为EF）是支持代码优先（Code First）的开发模式。代码优先允许通过编写简单的类来创建对象模型，然后从类创建数据库。
​	
## 添加模型类
在解决方案资源管理器中，右键单击Models（模型）文件夹，然后**添加类**。
![添加模型类](asp-mvc-modd/5-1.png)

如上图中的`Movie.cs`类，Movie对象的每个实例将对应数据库表的 一行， Movie类的每个属性将对应表的一列。 

而`MovieDBContext`类代表**Entity Framework**的电影数据库类，这个类负责在数据库中获 取，存储，更新，处理 Movie 类的实例。

`MovieDBContext`继承自**Entity Framework** 的 `DbContext`基类。

在添加`MovieDBContext`类的时候，注意确认当前项目是否安装**EntityFramework**，如果没安装，先在NuGet中搜索添加。否者`DbContext`类会报错，而且也无法`Using Entity`。

![确认是否安装EntityFramework](asp-mvc-modd/5-2.png)

## 创建使用数据库
创建连接字符串(`Connection String`)并使用**SQL Server LocalDB**

前面创建好的`MovieDBContext`类负责处理链接到数据库，并将Movie对象映射到数据库记录的任务。**EntityFramework**将预设值使用的LocalDB，后续操作中，先显式地在`Web.config`文件中，添加应用程序的连接字符串（`Connection String`）。

## SQL Server Express LocalDB
刚才提到了**LocalDB**，先简要介绍一下。

**LocalDB**是一个**SQL Server Express轻量级版本的数据库引擎**。它在用户模式下启动、执行。 

LocalDB的运行在一个特殊的SQL Server Express的执行模式下，即允许使用MDF文件数据库。通常情况下，LocalDB的数据库文件都保存在web项目的 `App_Data`文件夹下。

**注意**：在生产环境的Web应用程序中，不推荐使用SQL Server Express。因为LoaclDB没有被设计要求使用IIS。而LocalDB的数据库很容易迁移到SQL Server或SQL Azure中。
​	
默认的，Entity Framework的看起来命名为为对象上下文类（如本项目`MovieDBContext`）的相同的一个连接字符串。

**注意**：如果当前开发环境没有安装LocalDB，自行前往官网下载安装，[地址](https://www.microsoft.com/zh-CN/download/details.aspx?id=29062)。
​	
打开应用程序根目录的`Web.config `文件，注意是根目录。
![添加ConnectionStrings](asp-mvc-modd/5-3.png)

如上图，在Web.config 文件中的`<connectionStrings>`内添加下面的连接字符串。
```
<add name="MovieDBContext"   connectionString="Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\Movies.mdf;Integrated Security=True"   providerName="System.Data.SqlClient"/>
```

连接字符串（connection string）的名称必须匹配DbContext类的名称。

实际上, 并不需要新增 MovieDBContext连接字符串。 如果没有指定一个连接字符串， Entity Framework将会在用户目录中创建一个LocalDB数据库的DbContext类的 （如，本例中 `MvcMovie.Models.MovieDBContext`）。也可以将数据库命名为任何你喜欢的东西，只要它具有 .MDF 的后缀。例如，可以命名数据库 MyFilms.mdf 。 

接下来，将创建一个新的 `MoviesController`类，您可以用它来展示电影数据，并允许用户创建新的影片列表。


## 从控制器访问数据模型
创建一个新的`MoviesController`类，并在这个Controller类里编写代码来取得电影数据，并使用视图模板将数据展示在浏览器里。

在开始前，**先Build应用程序**(生成应用程序)(确保应用程序编译没有问题) 

在解决方案上，用鼠标右键单击Controllers文件夹，点击**新增**，再选择**控制器**。

![添加控制器](asp-mvc-modd/5-4.png)

按照上图，选择**包含视图的MVC5控制器（使用Entity Framework）**，然后手动选择相关的配置。模型类选择之前创建好的`Movie.cs`，点击下拉框选择位于`MvcStudy.Models`下的`Movie`。数据上下文类也是一样，选中了`MovieDBContext`类。

![控制器配置](asp-mvc-modd/5-5.png)

Visual Studio Express 会创建以下文件和文件夹： 
- 项目控制器文件夹中的
- MoviesController.cs 文件。 • 
- 项目视图文件夹下的 Movie文件夹。 • 

在新的`Views\Movies`文件夹中 创建 `Create.cshtml `、 `Delete.cshtml` 、 `Details.cshtml` 、 `Edit.cshtml `和 `Index.cshtml `文件。 

Visual Studio自动创建 **CRUD（创建、 读取、 更新和删除）** 操作方法，和相关的视图 文件(CRUD 自动创建的操作方法和视图文件被称为 `scaffolding`)。 现在有了可以创 建、列表、 编辑和删除电影Entity 所有的Web功能了。

启动调试，一个基础的功能就这样实现了。

![启动调试](asp-mvc-modd/5-6.png)

运行成功后，点击**Creat New**来添加一个Movie数据。

默认首页是一个列表，可以快速的创建，编辑，查看详情，和删除列表的信息。这一切ASP.NET MVC都帮我们完成了，而我们只需要按照需求将他展示出来实现想要的效果。

![默认首页展示和添加](asp-mvc-modd/5-7.png)

## Check the code
功能是交由ASP.NET MVC来实现生成了，但是代码到底是怎么样来实现这一切的呢？先来看看`Controllers`中的`Index`方法和`details`方法。

![Index方法和Details方法](asp-mvc-modd/5-8.png)
首先定义`MoviesController`类中实例化电影数据库上下文实例，如前面所述。电影数据库上下文实例可用于查询、 编辑和删除的电影。 
```
private MovieDBContext db = new MovieDBContext();
```
然后Index方法，返回给视图一个Movies的List，加载了数据库模型中的所有内容。同样的，Details方法通过传入的id，首先判断id是否为空，补位空就通过查找然后返回给视图。

## 强类型模型和 @model 关键字
在前几篇文章中，使用 ViewBag对象，从控制器传递数据或对象给视图模板。ViewBag是一个动态的对象，提供了方便的后期绑定（late-bound）方法将信息传递给视图。

在上图的Details方法中，使用了MVC 提供的传递强类型对象（strongly typed objects）到视图模板的能力。这种强 类型使得更好的在编译时检查您的代码, 并在Visual Studio 编辑器中提供更加丰富的智 能感知(IntelliSense)。当创建操作方法和视图时， Visual Studio 中的 scaffolding机制 （也就是通过一个强类型的模型）使用了 MoviesController类和视图模板。

如上图的代码，id参数一般是通过路由数据传递. 例如    
`http://localhost:1234/movies/details/1` 会设置MoviesController的Control，该方法操作 details并设置 id为1。也可以通过一个查询字符串 (query string) 的 id如下：`http://localhost:1234/movies/details?id=1 `
如果查找到了一个 Movie，Movie 模型的实例会传递给Detail视图。
```
return View(movie);
```
那么视图是如何处理的呢？看一下`Views\Movies\Details.cshtml`文件里的内容。会在首行看到如下代码：
```
@model MvcMovie.Models.Movie
```
通过引入视图模板文件顶部的@model语句，您可以指定该视图期望的对象类型。当创建`MoviesController`时，Visual Studio 会将@model声明自动包含到 `Details.cshtml `文件的顶 部。

此@model声明使得控制器可以将强类型的 Model对象传递给View视图，从而可以 在视图里访问传递过来的强类型电影Model。 例如，在 `Details.cshtml `模板中，每部电影的字段，通过代码传递了 DisplayNameFor 和 DisplayFor HTML Helper通过强类型的 Model对象。Create和 Edit方法还有视图模板都在传递电影的强类型模型对象。

`Index.cshtml` 视图模版和`MoviesController.cs` 中的Index 方法也是如此。


## 使用SQL Server LocalDB
在前面的演示中，都是使用的LocalDB，Entity Framework Code First（代码优先），如果检测到不存在一个数据库连接字符串 指向了 Movies数据库，会自动的创建数据库。在 App_Data 文件夹中找一下，您可以验证 它已经被创建了。
![LocalDB中的数据表信息](asp-mvc-modd/5-9.png)


依次在解决方案管理器中选中App_Data中的Movies.mdf，然后右键打开，在左侧弹出的服务器资源管理器中选择指定的表展开就可以显示数据表等一些列操作了。

**注意**：ID旁边的钥匙图标。默认情况下，EF将创建一个名为ID的主键。欲了解更多EF 和MVC信息，可以参考Tom Dykstra's的优秀教程 MVC and EF。 

Movies表映射到 Movie类的架构（schema）如何你前面创建的。Entity Framework Code First首先自动为您创造了这个架构（schema）基于 Movie  class。当完成后，通过右击` MovieDBContext`，并选择关闭连接。 （如果你不关闭连接，下一次运行项目， 你可能会得到一个错误）。

到目前为止，MoviesMVC项目可以在这个简单列表页面里：显示、编辑、更新、删除数据库里的数据了。在下篇中，会继续使用scaffolded自动生成的其它代码。并添加一个 SearchIndex方法和 SearchIndex视图，使用户可以在数据库中搜索电影。
