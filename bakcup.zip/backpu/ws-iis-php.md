---
title: Windows Server下IIS安装PHP+MySql环境
date: 2016-12-29 23:52
tags:
 - Other
---

>前几天看了几个动漫和电影，稍微有点感触，就想着写点影评，很多东西就开始从脑海里往外冒。之前说过要做个微信订阅号的，也就有了Gamean这个公众微信，当初是打算做游戏评测的，然而没静下心来写。于是今天就重新申请了一个公众微信号，名字用了以前的博客域名Derwer，然后把原来的Derwer.com解析到腾讯云的学生服务器上，打算做一个博客系统来做支撑，和原文阅读的引流，思路大致就是做一个自媒体平台吧。

---

因为腾讯云的服务器使用的是WindowsServer2012的服务器也懒得折腾回Linux，再加上本来就算是个.net程序员，所以一开始就想着用一个.net的博客程序做一个简单的CMS系统提供发布和历史消息回溯就行。于是在全球最大的同性交友网站github上找到了两个开源的博客系统：  

- [sblog.net](https://github.com/karthik25/sblog.net) 
- [BlogEngine.NET](https://blogengine.codeplex.com)

最后对比之后还是选择了BlogEngine.Net，然后也搭建了测试站点，但是整体的感觉不尽人意，而且各方面的拓展也不行，最后还是打算换回WordPress。  

在打算换回WordPress之后，本来是打算采用原来的WAMP软件直接安装的，但是腾讯云的学生服务器性能实在是不堪重负，最终打算采用IIS的CGI安装PHP然后连接MySql最终实现安装WordPress。

闲话少叙，步入正题！  

---

## 首先是要开启IIS的CGI功能
**程序和功能-IIS-万维网-勾选CGI开启**  
![开启CGI](ws-iis-php/CGI.png)

## 第二步就是下载安装PHP  
访问php官网下载最新的PHP环境- [PHP下载地址](http://windows.php.net/download/)  
这里需要注意的是！  
**安装NTS版本**，就是非线性安全版！否者会出现无法启动等情况！  
![NTS版PHP](ws-iis-php/NTSPHP.png)  
如果电脑上没有安装相应版本的支持库（vcredist）的话，还需要再微软官网下载对应版本的支持库。  
![支持库](ws-iis-php/zck.png)

出现下图所示的错误，先检查下载的是否是NTS版本的PHP，再检查对应版本的支持库，如上图中，对应的就是VC++2016 (11.0)  
![PHP出错](ws-iis-php/phperr.png)  

解压这些步骤就省略掉

---

## 配置PHP环境也（修改php.ini）
1. 将php文件夹中的php.ini-development文件另存一份，并打开编辑

2. 修改当前的时区`date.timezone ="Asia/Shanghai"`，注意去掉前面的分号“;”

3. 激活你需要的扩展选项，即将相应dll语句前的分号“;”删除
```
extension=php_gd2.dll  e
xtension=php_mbstring.dll  
extension=php_mysql.dll  
extension=php_mysqli.dll  
extension=php_pdo_mysql.dll
```
4. 设置扩展DLL的路径`extension_dir = “c:\php\ ext\”`，注意去掉前面的分号“;”

5. 保存修改并将php.ini复制到C:\windows目录下  

到这里php的配置就完成了

---

## 配置IIS
1. 启动IIS-进入处理程序映射
![IIS映射](ws-iis-php/iisys.png)
2. 右侧边栏选择-**添加模块映射**
![模块映射](ws-iis-php/mkys.png)
3. 在弹出的提示框中**按照如下信息进行选择填写**
![编辑映射](ws-iis-php/bjys.png)
其中可执行文件，选择解压后目录中的`php-cgi.exe`文件
这样就完成配置了，下面在默认文档中添加`index.php`，  
4. 校验
然后在站点中新建一个内容为：`<?php phpinfo();?>`
的`index.php`文件，浏览站点，出现PHP探针内容，就表示PHP环境已经安装成功了。

---

## 安装和配置MySql
MySql的安装下载非常简单，这里也不再赘述。  
主要说一下**PHP的MySQL的扩展**：

>为了让PHP能加载到MySQL的扩展，需要将`C:\Program Files\MySQL\MySQL Server 5.5\lib\libmysql.dll`复制到`C:\WINDOWS\SYSTEM32`目录下

**注意**：这步很重要，由于上面配置`php.ini`时已经激活了`extension=php_mysqli.dll`，该功能需要`libmysql.dll`的支持。否则mysqli会激活失败，这也将影响到phpMyAdmin的使用。

这个时候我们进去MySql的安装目录，查看MySql是否成功安装.  
![检查PHP](ws-iis-php/ckmysql.png)
在该目录启动命令提示符输入` mysql –uroot –p  `输入你刚才设置的密码出现如上提示就**表示MySql安装配置成功**。

---

## 安装phpMyAdmin对环境进行校验
OK，到目前为止IIS+PHP+MySql就搭建完了，因为我安装的是单服务器实例版本，我选择再安装一个phpMyAdmin来进行MySql的管理。  
在网上下载phpMyAdmin然后配置站点，访问，出现该界面。然后通过root和密码进行访问，顺带也测试了php和MySql的环境是否安装完成。
![phpMyAdmin](ws-iis-php/phpmyadmin.png)