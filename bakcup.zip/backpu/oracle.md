---
title: Oracle 11g 安装教程
date: 2017-09-14 22:27:41
tags:
 - Other
---

>最近学习Oracle，所以在Vm中配置一个win10的虚拟机来安装Oracle 11g，平时实验报告使用在虚拟机中使用SqlPlus，日常开发使用NaviCat进行连接，同时后期尝试安装多数据库和web服务搭建综合开发环境。

## 下载
[Oracle官网下载地址][1]  
注册登陆Oracle账号，同意协议，选择`Oracle Database 11g Release 2`并选中下载`Microsoft Windows (x64)`的`File1`和`File2`.

下载完成后将两个压缩包合并解压到同一文件夹下，然后选中文件夹中的`setup`启动。

![解压][2]


## 安装
**注意**：win10下安装可以会出现错误提示`INS-13001环境不满足最低要求`

![错误][3]

如果出现这个错误:

在安装文件的`/stage/cvu`文件夹下面找到文件 `cvu_prereq.xml`文件，修改为如下（添加windows 10相关字段，若你的系统为32位只需要添加win10 32的子段即可，若你的系统为64位只需要添加win10 64的子段即可）：

![64位系统][4]

代码如下，64位为例：
```
<OPERATING_SYSTEM RELEASE="6.2">
<VERSION VALUE="3"/>
<ARCHITECTURE VALUE="64-bit"/>
<NAME VALUE="Windows 10"/>
<ENV_VAR_LIST>
    <ENV_VAR NAME="PATH" MAX_LENGTH="1023" />
</ENV_VAR_LIST>
</OPERATING_SYSTEM>
```

然后正常启动安装程序，安装流程参照下文：

1. **配置安全更新**- 不要填写邮箱，不然容易出现`08109`错误
2. **安装选项** - 创建和配置数据库 - 下一步
3. **系统类** - 桌面类 （按实际情况决定）
4. **典型安装** - 建议变更全局数据库名为`orcl`，并设置管理口令(不满足标准亦可)
5. **概要** - 完成
6. **安装产品** - 等待安装，可选配置口令
7. **完成**

等待安装完成后，启动SqlPlus检查是否安装成功！

[1]: http://www.oracle.com/technetwork/database/enterprise-edition/downloads/index.html
[2]: oracle/setup.PNG
[3]: oracle/ins13001.PNG
[4]: oracle/64.PNG