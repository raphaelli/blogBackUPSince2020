---

title: Visual Studio Code 常用插件列表
date: 2018-10-06 21:03:26
tags:
 - Other
---



> 在使用VSC 开发中，经常需要依赖一些插件来提升我们的开发效率和 VSC 的使用体验，记录一下 .net core web 开发的一些相关插件和 VSC 常用的一些插件。

![pluslist](vsc-plus\pluslist.png)



依次说一下上面的几个插件的用处：

- **advanced-new-file**  新建文件(文件夹)助手
- **Beautify**  代码美化插件
- **C#** C#代码支持工具
- **GitLens** git工具
- **Markdown All in One**  Markdown 支持工具
- **Python** Python支持工具
- **REST Client** REST 客户端（更推荐使用Postman）
- **SQL Server** SQL Server 支持工具
- **TSLint** TS代码支持工具
- **vscode-icons** VSC图标工具


>其他补充：
- **VSCode Browser Sync**  VSC 中同步显示网页