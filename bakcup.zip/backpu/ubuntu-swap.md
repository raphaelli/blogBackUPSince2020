---
title: "ubuntu配置虚拟内存"
date: 2017-1-3 12:56
tags:
 - Linux
---
## Step1:增加 swap

增加 2G swap 分区，只需要 修改 `count=2k`  
```
sudo dd if=/dev/zero of=/swap.disk bs=1M count=2k
sudo mkswap -f /swap.disk
sudo swapon /swap.disk
```
or
```
sudo dd if=/dev/zero of=/swap.disk bs=1M count=2k && sudo mkswap -f /swap.disk && sudo swapon /swap.disk
```

---

##  Step2:加入启动
exit 0 之前加入：开机自动创建swap
```
#sudo dd if=/dev/zero of=/swap.disk bs=1M count=2k && sudo mkswap -f /swap.disk && sudo swapon /swap.disk
sudo mkswap -f /swap.disk && sudo swapon /swap.disk

exit 0
```

创建好了的话
```
sudo swapon /swap
```
就可以自动启动了

设置使用率  数字越大，越优先使用swap
```
sudo sysctl vm.swappiness=80
```