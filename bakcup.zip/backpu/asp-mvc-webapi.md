---
title: ASP.NET MVC Web API
date: 2018-04-18 10:43:06
tags:
 - dotNET
---

> ASP.NET Web API 是一种框架，用于轻松构建可以访问多种客户端（包括浏览器和移动设备）的 HTTP 服务。 ASP.NET Web API 是一种用于在 .NET Framework 上构建 RESTful 应用程序的理想平台。

这是 MSDN 给出的官方定义！

实际开发中，我们可以轻松的使用 WebAPI 配合 Routing 路由和 EF 框架来轻松的实现一个 RESTful 的 API 并将其作为软件的后端。



# RESTful API

REST不是一个标准,而是一种应用架构风格,与之对应的是传统 Web service采用的 RPC架构风格。如果说 RPC是一种面向操作的架构风格的话, REST就是一种面向资源的架构风格。由于REST仅仅是一种架构风格, 所以它是与具体的技术平台无关的, 所以采用 REST架构的应用未必一定建立在Web之上。

关于 RESTful Api 的更多信息， 可以参考 阮一峰老师的文章

- [理解RESTful架构](http://www.ruanyifeng.com/blog/2011/09/restful.html)
- [RESTful API 设计指南](http://www.ruanyifeng.com/blog/2014/05/restful_api.html)

# 创建WEB API

![addwebapi](asp-mvc-webapi/addwebapi.png)



在 VS 中创建一个 空项目，并为其添加 Web API。



## 添加模型

模型是表示应用程序中的数据的对象。 ASP.NET Web API 可以自动序列化到 JSON、 XML 或某种其他格式，然后写入 HTTP 响应消息的正文序列化的数据。 只要客户端可以读取的序列化格式，它可以反序列化对象。 大多数客户端可以分析 XML 或 JSON。 此外，客户端可以指示它想通过 HTTP 请求消息中设置 Accept 标头的格式。



让我们首先创建一个表示书📚的简单模型。



如果解决方案资源管理器不可见，请单击**视图**菜单，然后选择**解决方案资源管理器**。 在解决方案资源管理器，右键单击模型文件夹。 从上下文菜单中，选择**添加**然后选择**类**。



![models](asp-mvc-webapi/models.png)





# 添加控制器

![controller](asp-mvc-webapi/controller.png)



添加 model 的应用，添加部分测试数据。

![bcontroller](asp-mvc-webapi/bcontroller.png)



使用 POSTMAN 测试

![re](asp-mvc-webapi/re.png)