---
title: 【译】助你成功搭建云应用的12条方法
date: 2017-12-25 22:23:20
tags:
 - Other
---
>原文作者：Rafael Benevides
原文地址：https://dzone.com/articles/12-factors-to-cloud-success-rhd-blog

# 原文

Hey, developers! Do you care about using the best practices to apply your application to the cloud? If so then you should be using The 12-factor App, which is a methodology for building Software-as-a-Service. Today, I'd like to talk about the 12-factor App, which I had presented to a group at the Red Hat Summit last month.


Every developer that is moving their application to the cloud will face a different environment than what they are used to, their datacenter or own premise and that’s why they should care about the 12-factor methodology. This 12 step methodology was created by Heroku, which is a cloud provider who found a common solution to most of what their customers were experiencing and decided to release these solutions as a methodology. These 12 factors are intended to solve problems related to applications running in the cloud. If there was one key takeaway from my session it was not the idea to have the audience memorize these 12 factors but to have an understanding of why each one is important.


​     
​     
    Codebase – Use version control, one codebase tracked in revision control for many deployments.


​     
    Dependencies – Use a package manager and don’t commit dependencies in the codebase repository.


​     
    Config – Store the config in Environment Variable, if you have to repackage your application, you’re doing it wrong.


​     
    Backing Services – A deploy of the twelve-factor app should be able to swap out a local MySQL database with one managed by a third party (such as Amazon RDS) without any changes to the app’s code.


​     
    Build, Release, Run – The twelve-factor app uses strict separation between the build, release, and run stages. Every release should always have a unique release ID and releases should allow rollback.


​     
    Processes – Execute the app as one or more stateless processes. The Twelve-factor processes are stateless and share-nothing.


​     
    Port Binding – Export services via port binding, The twelve-factor app is completely self-contained.


​     
    Concurrency – Scale out via the process model. Each process should be individually scaled, with Factor 6 (Stateless), it is easy to scale the services.


​     
    Disposability – Maximize robustness with fast startup and graceful shutdown, we can achieve this with containers.


​     
    Dev/Prod Parity – Keep development, staging, and production as similar as possible, the twelve-factor app is designed for continuous deployment by keeping the gap between development and production small.


​     
    Logs – Treat logs as event streams, a twelve-factor app never concerns itself with routing or storage of its output stream.


​     
    Admin Processes – run admin/management tasks as one-off processes.




The 12-factor App methodology is technology and language agnostic but satisfied by Containers, Microservices, and CI/CD Pipelines with a focus on DevOps. You can access more information on The 12-factor App here.


# 译文：

你好，开发者们！你是否想了解应用程序在云端的最佳应用体验？那么，你最好使用[12-Factor App](https://12factor.net/)，将你的程序部署为Saas(Software-as-a-Service译：软件即服务)的云应用。今天，我想谈谈我上个月在Red Hat Summit上的关于`12-Factor App`的分享。


每一个正在将应用程序迁移到云端的开发人员都将面临一个与过去完全不同的环境，他们使用数据中心或自己的机房，这就是为什么他们应该关注`12-Factor App`的原因。这十二条是由Heroku这一个云提供商发布的一个通用的解决方案，大多数他们的客户决定放出这些解决方案作为一种方法论。这十二条特性旨在解决与云中运行的应用程序相关的问题。如果用一句话概括我的这个分享，并不是想法让大家记住这十二条特性，而是想让了解为什么每一个都是非常重要的。


1. 基准代码 - 使用版本控制，一份基准代码，多份部署的版本控制。

2. 依赖 – 使用包管理器且不要提交依赖关系到在代码库。

3. 配置 – 将配置存储在环境变量中，如果你将其打包进你的应用中，你就大错特错了。

4.  后端服务 — 一个`12-Factor App`的[部署](https://12factor.net/zh_cn/codebase)应该支持切换到一个本地MySQL数据库，或由第三方管理（如Amazon RDS）的数据库，而无需对程序的代码进行任何更改。

5. 构建、发布、运行 — `12-Factor App`在构建、发布和运行阶段之间使用严格隔离。每个发行版都应该有唯一的发行ID，发行版应该支持回滚。

6. 进程 — 将应用程序作为一个或多个无状态进程执行。`12-Factor App`的进程应该是无状态和[无共享](https://en.wikipedia.org/wiki/Shared-nothing_architecture)的。

7. 端口绑定 — 通过端口绑定提供服务，一个符合这十二条特性的是完全自包含的。

8. 并发性 — 通过过程模型扩展。每一个进程都应该按`Factor 6`（无状态）单独缩放，很容易扩展服务。 

9. 易处理 – 最大化快速启动和优雅终止可最大化健壮性，我们可以实现这个容器。

10. 开发环境与线上环境等价 - 保持开发，分期，生产尽可能相似，`12-Factor App`是为了保持持续的开发和生产之间的差距小规模部署。

11. 日志 — 将日志视为事件流，一个`12-Factor App`从不担心其输出流的路由或存储。

12. 管理进程 - 后台管理任务当作一次性进程运行。

`12-Factor App`和技术或语言无关，但你可以在[DevOps](https://developers.redhat.com/topics/devops/)关注容器，微服务，CI / CD的管道相关的技术。更多关于`12-Factor App`的信息请点击[这里](https://12factor.net/zh_cn/).