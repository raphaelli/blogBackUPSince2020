---
title: .NET Core 实战笔记2-从命令开始
date: 2017-11-27 12:35:13
tags:
 - dotNET
---

[上一篇简要介绍了 .NET Core平台](https://ns96.com/2017/11/21/dotNet-core-1/)，本篇对dotnet命令进行讲解。

 >.NET Core作为跨平台产品，不再只依赖于Windows的图形化界面系统，因而推出的`dotnet命令` 成为了开发 .NET Core应用程序的一个新的跨平台工具链的基础。因此，掌握dotnet命令之后，就可以在任何支持平台上使用同样的命令进行开发管理。

# dotnet命令——从实际项目入手
dotnet的命令有很多，没有必要一一列举出来，对于开发人员来说，最好的记忆方式就是实践。

## 创建（dotnet new）
`dotnet new` 顾名思义，就是新建一个dotNet Core项目，dotnet core有很多类型的项目，因此，需要同时给new指令添加属性来新建制定模板的项目。如下图，使用`dotnet new -h`列出了dot net core中的项目模板及其简写。

![dotnet new -h][1]

我们先来创建一个简单的控制台应用程序，也就是`console`。

![dotnet new console][2]

## 还原（dotnet restore和dotnet pack）

再来创建一个`class lib `也就是类库，让前面创建的控制台程序来调用这个类库。

`dotnet new classlib`

![dotnet new classlib][3]

现在为创建好的CLB的默认类`Class1.cs`添加两个方法，然后打包。
```
using System;
namespace app_clb
{
    public class Class1
    {
        public void Printout()
        {
            System.Console.WriteLine("Class Lib Print!");
        }
        public string GetStr()
        {
            return "return lib";
        }
    }  
}
```

打包需要两条指令:
- `dotnet restore`
- `dotnet pack`

![dotnet restore][4]

完成打包后，将`applib`添加到`console_app`的`app.csproj`中。

在`app.csproj`中添加如下内容：

添加后之前切换到`console_app`目录，执行指令，将CLB包含到项目中。

`dotnet restore -s C:\dotnet\app_clb\bin\Debug\`

即`dotnet restore -s + 包的路径`

![restore][5]

然后就能直接在项目中调用app_clb中的的方法。
```
using System;
using app_clb;
namespace console_app1
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj =new Class1();
            obj.Printout();
            System.Console.WriteLine(obj.GetStr());
            System.Console.WriteLine("Hello World!");
        }
    }
}
```

## 运行（dotnet build和dotnet run）
`dotnet build` 即编译当前目录下的代码文件为可执行程序

![dotnet build][6]

而`dotnet run`则是允许已经编译好的可执行程序

![dotnet run][7]

同时,`dotnet app.dll`也是执行程序。

## 测试（dotnet test）
新建一个文件夹及项目 

`dotnet new xunit`

新建好后直接添加测试方法，运行测试，这里直接运行测试

`dotnet restore`

`dotnet test`

![test][8]

## 发布（dotnet publish）
dotnet core是跨平台的开发平台，所以发布的软件当然是具有跨平台运行的能力的。

先添加节点，打开`console_app1.csproj`在`PropertyGroup`节点中加入：

`<RuntimeIdentifiers>win10-x64;ubuntu.14.04-x64</RuntimeIdentifiers>`

还原项目`dotnet restore`,然后发布

`dotnet publish`默认发布

`dotnet publish -r win10-x64` 发布配置信息中添加好的win10-x64

`dotnet publish -r ubuntu.14.01-x64` 发布配置信息中添加好的ubuntu


![publish][9]

[1]: dotNet-core-2/dotnet-new.png
[2]: dotNet-core-2/new-console.png
[3]: dotNet-core-2/new-clb.png
[4]: dotNet-core-2/restore.png
[5]: dotNet-core-2/restoreb.png
[6]: dotNet-core-2/build.png
[7]: dotNet-core-2/run.png
[8]: dotNet-core-2/test.png
[9]: dotNet-core-2/publish.png