---
title: 安卓开发（基于AS）知识汇总
date: 2020-01-22 10:54:09
tags:
 - Android
---

# 初始
## 安装AS
官网下载 - https://developer.android.com/studio

## 连接调试设备
Win10 开启开发者模式后，使用手机原装数据线接入电脑，一般来说都可以直接免驱适配设备，在AS种会直接现实设备名称。

![ADB连接](android-development-kn\adb.png)

>如无法驱动，可以安装刷机机灵来安装驱动(win7) - 地址： https://pan.baidu.com/s/1HtGg0ax_lQQScNjX9wJfIg


