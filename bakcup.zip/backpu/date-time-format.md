---
title:  /Date()/ 时间戳格式转换  js
date: 2018-12-19 15:45:55
tags:
 - WorkNote
---

>有时候从数据库取出来的数据是 时间戳格式的，可以在服务端通过语言来转换，当然也可以通过js 来进行转换。

```js
 //原理是取中间的毫秒数，再转换成js的Date类型
function ChangeDateFormat(val) {
    if (val != null) {
        var date = new Date(parseInt(val.replace("/Date(", "").replace(")/", ""), 10));
        //月份为0-11，所以+1，月份小于10时补个0
        var month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
        var currentDate = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        var hour = date.getHours();
        var minute = date.getMinutes();
        var second = date.getSeconds();
        var dd = date.getFullYear() + "-" + month + "-" + currentDate + " "+hour+":"+minute+":"+second;
        alert(dd);
        return dd;
    }

    return "";
}
```



