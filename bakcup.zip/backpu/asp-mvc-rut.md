---
title: ASP.NET MVC 路由详解
date: 2018-03-26 11:50:01
tags:
 - dotNET
---

事隔多年，其实也就一年啦，重新整理下ASP.NET MVC的相关知识。继续前面的内容，来说说路由。

# Route
![Route][1]


这是项目中`App_Star/RouteConfig.cs` 中的默认路由信息，上面有几个关键词：
 - 路由规则Route：需指定路由的格式，默认值，处理器 
 - 路由数据RouteData：当前请求上下文匹配路由规则而到的对象，可在Action中通过RouteData.GetRequestString("controller/action")获取本次请求中控制器的行为的真实名称
 - 路由集合RouteCollection: 存放路由规则的集合 Collection<RouteBase>，一个MVC项目中，可以配置多个路由规则，按照键值对的格式存储到路由集合中
 - 路由表RouteTable：类中包含静态的RouteCollection属性，完成所有路由规则的全局存储，在Global中完成注册 

 ## 路由的注册
 ![Global][2]
 可以看到，在`Global`中使用`RouteConfig.RegisterRoutes(RouteTable.Routes);`来注册路由。

 ## routes.MapRoute方法

 `routes.MapRoute()`方法接收三个参数：
 - `name` 路由规则的名称（不能重复，作为键存放在RouteCollection）
 - `url` 路由规则，即访问格式 其中`{controller}`和`{action}`不能修改
 - `defaults` 默认值


 ### 路由规则
 重点说下路由规则，路由规则中`{controller}`和`{action}`不能修改，因为这是MVC的默认字段。

 路由规则的`id`字段，或者其他自定义字段，可以用于接收参数，便于请求的处理和参数的传递。

 因为路由规则可以方便的传递和接受数据，因此在MVC中基本不适用GET方式来请求数据，一般使用路由匹配和POST提交两种方式。

 行为参数模式通过路由传递的数据，不能被Request接收到，只能通过路由规则给定的格式，直接用ViewBag来接收。

 **注意**：从SEO优化的角度来考虑，URL一般不要超过三层。

 通常来讲，一个URL按照如下规则: localhost/{栏目}/{页面}

 ### constraints - 约束
 constraints 约束参数默认是没有的，但是可以自行添加：
 - 设置路由规则的约束
 - 类型为object，可以传递一个匿名对象，属性取决于规则中定义的参数
 - 参数是正则表达式字符串，如 controller= "^[a-z]+$"


 ## 自定义路由示例
 ![routemap][3]

 url部分，不一定要使用`/`进行连接，使用`-`亦可（优化seo），如果使用`-`，则是强类型匹配。

 约束参数使用了数值长度的限制，避免出错。

## 拓展
使用 RouteDebug 进行路由调试

# 总结
- 路由规则可以注册多条
- 路由规则的名称不能重复
- 路由规则有顺序，并且按照顺序进行匹配
- 子频道的路由规则配置应放在靠前
- 路由规则可以设置约束
- 路由规则匹配的控制器可以设置命名空间约束


[1]: asp-mvc-rut/route.png
[2]: asp-mvc-rut/global.png
[3]: asp-mvc-rut/routemap.png
