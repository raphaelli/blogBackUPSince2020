---
title: Python Spider Cheat Sheet
date: 2018-01-25 21:53:17
tags:
 - Other
---

- [Python爬虫学习之旅-从基础开始 ]https://ns96.com/2018/01/09/python-spider-start/
- [Python笔记-使用 JupiterNotebook 写一个爬虫实例 ]https://ns96.com/2018/01/23/python-j-s-start/


前面两篇文章大致说了 `Python` 爬虫的原理和工具以及开发环境的搭建，将原本逐一内容记录的方式修改为 `Cheat Sheet` 模式。


# 获取页面
获取页面的几个步骤：
- 使用 BeautifulSoup 解析网页
- 表述需要爬取的信息
- 从标签中获取需要的信息

## 解析网页
`BeautifulSoup` 让我们将网页视作一份汤，那么 `Soup` 就是这份汤， `html` 就是汤料，而 `lxml` 则是食谱。而食谱呢，一共有如下五种：
- html.parser
- lxml HTML
- lxml XML
- html5lib

```py
Soup = BeautifulSoup(html,'lxml')
```

## 获取网页
对于网页中的元素,通常使用两种方法来进行定位：

- CSS Selector
- XPath


Xpath 路径为: `/html/body/main/article[1]/h2/a`

CSS Selector 为: `body > main > article:nth-child(1) > h2 > a`

 `BeautifulSoup` 只能识别 CSS Selector 来获取网页指定内容。



## 存储

文件流操作

```
url = 'http://mm.chinasareview.com/wp-content/uploads/2017a/05/03/07.jpg'
r = requests.get(url,headers=headers).content
f = open('./save/test1.jpg','wb')
f.write(r)
f.close
```

# 反爬应对

## UA

```py
headers = {'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64)  AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299"}
r = requests.get(url,headers=headers).content

## 使用requests中的get方法来获取all_url
start_html = requests.get(all_url,headers=headers)  

```

## 防盗链
```py
headers = {'Referer':'http://www.domain.com'}
r = requests.get(url,headers=headers).content
```