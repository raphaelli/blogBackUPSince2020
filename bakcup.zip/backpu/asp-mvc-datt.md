---
title: ASP.NET MVC学习笔记07数据表和模型添加新字段
date: 2017-05-20 23:21:44
tags:
 - dotNET
---

## 给电影表和模型添加新字段
在本节中，您将使用Entity Framework Code First来实现模型类上的操作。从而使得这 些操作和变更，可以应用到数据库中。

默认情况下，就像您在之前的教程中所作的那样，使用 Entity Framework Code First自 动创建一个数据库，Code First为数据库所添加的表，将帮助您跟踪数据库是否和从它生 成的模型类是同步的。如果他们不是同步的，Entity Framework将抛出一个错误。这非 常方便的在开发时就可以发现错误，否则您可能会在运行时才发现这个问题。 (由一个晦涩的错误信息，才发现这个问题。）

为对象模型的变更设置 `Code First Migrations`
从解决方案资源管理器中双击`Movies.mdf `，打开数据库工具, 在数据库工具 （数据库资源管理器、 服务器资源管理器或 SQL Server对象资源管理器），右键单击 `Movies.mdf`， 并选择删除。

Build应用程序，以确保没有任何编译错误。 
从工具菜单上，单击库包管理器，然后点击程序包管理器控制台。

![启动程序包管理控制台](asp-mvc-datt/7-1.png)

在程序包管理器控制台窗口，在提示符 PM> 后输入： 
Enable-Migrations -ContextTypeName StudyMVC.Models.MovieDBContext

**注意**：如果你设置了其他项目名称，请自行修改。
如上所示的`Enable-Migrations`命令，会在Migrations 文件夹下创建一个`Configuration.cs`文件。
![Migrations/Configuration.cs 文件](asp-mvc-datt/7-2.png)

`Code First Migrations`调用Seed的方法，每个迁移（程序包管理器控制台 更新数据库 ），此方法用于updates数据（如果数据存在），或inserted数据。 
在AddOrUpdate方法在下面的代码执行一个的“upsert”操作：
```
	context.Movies.AddOrUpdate(i => i.Title,
new Movie 
    { 
        Title = "When Harry Met Sally", 
        ReleaseDate = DateTime.Parse("1989-1-11"), 
        Genre = "Romantic Comedy", 
        Rating = "PG", 
        Price = 7.99M 
} 
```
因为 Seed方法与每个迁移同时运行时，故，你不能仅仅插入数据，因为当你正试图添 加，可能已经完成了创建数据库后的第一次迁移。“upsert”操作阻止错误的发生，如果你尝试插入一个已经存在的行，它覆盖任何数据更改，当你在测试应用程序的同时。你可能不希望这样的事情发生：在某些情况下，当您更改数据测试时，你希望你的变化后数据 库同步更新。在这种情况下，你想要做一个有条件的插入操作：只有当它不存在的时候，插入一行。 

传递给 AddOrUpdate的方法的第一个参数， 指定的属性来使用以检查是否已存在某行。 对于您所提供的测试影片的数据，Title属性可以被用于此目的，因为每个标题在列表中 是唯一： 

`context.Movies.AddOrUpdate(i => i.Title, `  

这个代码假设titiles属性是唯一的。如果手动添加一个重复的标题，你会得到下面的异 常。 

`Sequence contains more than one element`  

按**CTRL-SHIFT-B**来Build工程。（如果此次Build不成功，以下的步骤将会失败。）

下一步是创建一个`DbMigration`类，用于初始化数据库迁移。此迁移类将创建新的数据 库，这也就是为什么在之前的步骤中你要删除`movie.mdf`文件。 

在软件包管理器控制台窗口中，输入"`add-migration Initial`"命令来创建初始迁移。"`Initial`" 的名称是任意，是用于创建迁移文件的名称。 


