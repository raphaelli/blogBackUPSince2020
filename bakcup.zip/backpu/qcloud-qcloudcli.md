---
title: 腾讯云 Qcloudcli 配置使用教程
date: 2018-04-06 07:48:20
tags:
 - Other
---

> 本篇教程，介绍如何使用腾讯云的免费云 API 接入腾讯云服务，并对 Qcloudcli 和云 API 做一定介绍。



# 安装和使用 QcloudCli

## 安装 Python 和 Pip

安装命令行工具前请确保您的系统已经安装了 Python 环境和 Pip 工具。

## 安装命令行工具

1) 通过 pip 安装命令行工具：

```sh
$ sudo pip install qcloudcli
```

2) 检验 qcloudcli 是否安装成功：

```sh
$  qcloudcli --help
NAME:
    qcloudcli
DESCRIPTION:
    The Qcloud Command Line Interface is a unified tool to manage your qcloud services.
```

## 安装命令行自动补齐

1) 找到自动补全脚本 qcloud_completer 位置，运行以下命令：

```sh
$ which qcloud_completer
/usr/bin/qcloud_completer
```

2) 将 qcloud_completer 所在路径加入系统的自动补全命令，运行以下命令：

```sh
$ complete -C '/usr/bin/qcloud_completer' qcloudcli
```

3) 观察是否包含 qcloudcli 自动补全脚本，获得类似如下结果证明已包含了qcloudcli的自动补全脚本：

```sh
$ complete | grep qcloudcli
complete -C '/usr/bin/qcloud_completer' qcloudcli
```

4) 使用自动补全功能
在 qcloudcli 中使用 TAB 键完成自动补全功能。如果命令唯一，则直接补全，否则展示当前所有可用命令：

```sh
$ qcloudcli c

cam     cbs     cdb     cdn     cmem    cns     configure   cvm
```

5) 自动补全命令自动生效
为了保证每次启动自动补全命令均有效，您需要将自动补全的命令写入配置文件 `~/.bash_profile` 中:

```sh
$ vim ~/.bash_profile
```

添加如下内容，`:wq`保存退出

```sh
complete -C '/usr/bin/qcloud_completer' qcloudcli
```



## 配置 QcloudCli

 安装完 QcloudCli 之后，还需要对其进行一定的配置，以进行操作

### 获取SecretId&SecretKey

登陆后访问 - [API 秘钥管理](https://console.cloud.tencent.com/cam/capi)

### 配置给 QcloudCli

使用 `sudo qcloudcli configure`指令进行配置，输入对应的 SecretId&Key:

![configure](qcloud-qcloudcli/configure.png)

### 使用在线云 API

当然，也可以使用在线云 api 进行处理 - [云API v2.0 调试工具](http://139.199.218.191/yunapi/tools/index.php)



## 参考：

- [Qcloud 云API 文档地址]( https://cloud.tencent.com/document/product/440/6186)