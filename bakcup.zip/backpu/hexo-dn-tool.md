---
title: Hexo 发布清理和新建工具
date: 2018-11-05 08:36:03
tags:
 - Other 
---

>经常会在多台设备上使用Hexo 发布博客，所以就使用了OneDrive来备份 Hexo 到不同的设备上，都安装上 node 和 hexo 之后就可以使用指令来发布博客到 github pages 并且保存到 OneDrive 。 最近发下博客内容比较多之后， `.deploy_git`的发布文件夹会变得很大，有很多零散文件，每次在 Deploy 之后都需要同步很久，于是就有了写个 npm 插件来在 deploy 之后自动删除该文件夹，无奈前端技术太菜，最后退而求其次，用 shell 脚本来完成，顺手还写了个快速创建。

# 更新后自动清理
```sh
hexo g -d && echo "G-D Finished！" && hexo clean && rm ./.deploy_git -rf && echo "Clean Finished！" && echo "press any key to quit!" && read
```
更新后执行 `hexo clean ` 并清理 `.deploy_git`

# 快速创建新文章并打开编辑
```sh
#! /bin/bash

echo "Please input the article name:" && read name && echo "log:hexo new" $name && hexo new $name && echo $name" add completed！" && code "./source/_posts/"$name".md" && read
```

# 拓展

- [github - hexo tool](https://github.com/raphaelli/hexo_tool)
  
后续考虑使用 UWP 创建一个hexo GUI 工具