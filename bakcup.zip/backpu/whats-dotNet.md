---
title: .NET Framework概述
date: 2017-11-20 19:43:51
tags:
 - dotNET
---

## 什么是 .NET Framework？

.NET Framework 是为其运行的应用提供各种服务的托管执行环境。 它包括两个主要组件：公共语言运行时 (CLR)，它是处理运行应用的执行引擎；.NET Framework 类库，它提供开发人员可从其自己的应用中调用的已测试、可重用代码库。 .NET Framework 提供的用于运行应用的服务包括：

- 内存管理。 在许多编程语言中，程序员负责分配和释放内存并处理对象生存期。 在 .NET Framework 应用中，CLR 代表应用提供这些服务。

- 常规类型系统。 在传统编程语言中，基本类型由编译器定义，这将使跨语言互操作性复杂化。 在 .NET Framework 中，基本类型由 .NET Framework 类型系统定义，并且是面向 .NET Framework 的所有语言所共有的。

- 一个全面的类库。 处理常见的低级编程操作时，程序员可通过 .NET Framework 类库使用类型及其成员的易访问库，而不必编写大量代码。

- 开发框架和技术。 .NET Framework 包括用于特定区域应用开发的库，如用于 Web 应用的 ASP.NET，用于数据访问的 ADO.NET 以及用于面向服务的应用的 Windows Communication Foundation。

- 语言互操作性。 面向 .NET Framework 的语言编译器发出名为公共中间语言 (CIL) 的中间代码，反过来，通过公共语言运行时在运行时进行编译。 借助此功能，使用某种语言编写的例程可由另一种语言访问，程序员可以专注于使用其首选语言创建应用。

- 版本兼容性。 除少数例外，使用特定版本的 .NET Framework 开发的应用无需在更高版本中修改即可运行。

- 并行执行。 通过允许同一台计算机上存在公共语言运行时的多个版本，.NET Framework 可帮助解决版本冲突。 这意味着应用的多个版本可以共存，并且应用可在构建它的 .NET Framework 版本上运行。 并行执行适用于 .NET Framework 版本组 1.0/1.1、2.0/3.0/3.5 和 4/4.5.x/4.6.x/4.7。

- 多定向。 通过定向 .NET Standard，开发人员可创建在多个 .NET Framework 平台（例如，Windows 7、Windows 8、Windows 8.1、Windows 10、Windows Phone 和 Xbox 360）上工作的程序集。


上述描述应用自(MSDN)[https://docs.microsoft.com/zh-cn/dotnet/framework/get-started/index]

![.netFramework](whats-dotNet/dotNet.png)

2002年微软公司发布的第一个 .NET框架—— .NET Framework，不久后又发布了 .NET Compact Framework 用于在较小的移动设备（Windows mobile），而 .NET Compact Framework 也含有一套类似 .NET Framework 体系（Runtime, Framework,Application Model），它是一个复制精简版的 .NET Framework。在数年间微软乐此不疲的推出了数个类似 .NET Framework的框架，以用于在不同的设备和平台上运行。每个Framework都有类似的体系但又不完全相同的，这样Framework越来越多，对开发者来说不一样的设备即便功能相同也需要维护多套代码，增加了开发的复杂度。

## .NET Core
微软对这些问题的重新思考和改进让 .NET Core横空出世。  

.NET Core是一个开源的模块化的Framework，不管是开发web或移动设备都在同一个Framework（.NET Core）下运行，而且 .NET Core也可在不同的操作系统上运行，包括Windows、linux、MacOS，实现了跨平台跨设备。

更棒的是 .NET Core 在发布程序时不用事先安装Framework而是通过Nuget下载，这样在初次部署时就不用安装一个复杂而庞大Framework，而是按需下载。这种基于Nuget的按需加载铸就了 .NET Core 跨平台。

![.NET Core](whats-dotNet/dotNet2015.png)

.NET Core 构成体系如下：

- **Runtime** 在 .NET Core 中有实现两种RunTime，NativeRuntime 和 CoreCLR。NativeRuntime 将C# 或 VB.net 代码直接转换为原生机器码。而CoreCLR是一个开源的JIT运行时，会将代码编译成中间语言（IL）在最终运行时再转换机器码。

- **Unified BCL** Base Classlibrary即基础类，例如 FileSystem、Console、XML操作等。

- **Windows Store AppModel & ASP .NET Core 1.0** 提供开发Windows系统的各种触屏设备和ASP.NET程序的一组基础库。

## 说点人话
先说说什么是 .NET Framework，这个东西呢，简单来说，是→两个部分构成，一个叫做公共语言运行时，一个呢，是类库（不是内裤，南方同学注意发音）。

公共语言运行时（Common Language Runtime）有时候也被称为 .NET运行时(.NET Runtime)，有点类似于Java中的JVM，这里我们姑且就把他理解为，解释你所编写的C#代码（或则F#，不可否认.NET是多语言平台）给计算机，并让其执行的一个工具，细究起来，就涉及到了编译原理，计算机组成原理和很多很多计算机理论知识，嗯，推荐一本我自己可能都不会去看的书——《CLR via C#》。

.NET Framework 类库呢，就是是把我们常用的一些方法和类，封装起来，便于开发人员直接调用而不用重复编写。

那么`.NET Core`呢？  

同样的，.NET Core也提供了CLR和类库，用于开发。所以呢，.NET Core是处在一个与 .NET Framework的同级的地位，微软推出其是为了更好的部署跨平台的战略。同时推出的 `ASP.NET Core`和`ASP.NET Core MVC`等用于web开发，同时，也提供了UWP通用应用和Xamarin跨平台开发的应用。


