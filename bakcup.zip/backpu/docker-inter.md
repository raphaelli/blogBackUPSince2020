---
title: Docker 多域名部署应用
date: 2018-9-11 14:26:34
tags:
 - Docker
---

> 通常来说，每一个WEB应用和服务应该对应唯一的域名/二级域名，而 docker 通常将访问地址设为本地域名下的某些端口，于是，使用Nginx 来监听和转发请求，就成为了一个十分可行的选项。



# 安装Nginx

这里使用的是Ubuntu 服务器，安装非常简单，更新apt 源，使用:

```sh
$ apt-get install nginx
```

即可完成安装~！



## 查看Docker配置

使用：

```
$ docker ps
```

查看端口配置。



## 配置Nginx

nginx 的配置文件默认读取`/etc/nginx/nginx.conf`文件。

区块指令由｛｝包含，区块指令又可以包含多个简单指令和区块指令：

```sh
http {
    server {
    
     # ……
     # 引入docker vhost的转发                                        
     include /data/nginx/conf/vhost/*.conf;   
    }
}
```

> server 区块包含再 http区块中



# 多域名配置

这里使用外部 conf 调用来进行多域名配置。

### 创建一个 vhost 目录存放各域名配置

```sh
$ mkdir vhost
```

### 写入信息

> 创建一个 `jupyter.conf` 写入server 信息如下：

```sh
server
{
    listen 80;
    server_name jupyter.leepush.com;
    location / {
        #....
        proxy_pass http://127.0.0.1:8888;
    }
    ##### other directive
}
```

将 8888 端口映射到指定域名的80下。



## 重载命令生效:

重载配置并重启nginx：

```sh
$ /etc/init.d/nginx restart
$ sudo nginx -s reload
```

若无效，重新执行上述指令，并 ctrl + F5 刷下缓存后访问！