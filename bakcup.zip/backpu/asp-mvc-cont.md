---
title: ASP.NET MVC学习笔记02控制器和路由
date: 2017-04-25 11:19:02
tags:
 - dotNET
---

>上一篇大致说了下ASP.NET MVC到底是什么，以及MVC的思想，下面我们就继续依照官方文档，从MVC的C开始入手，也就是控制器。

---

## MVC的官方解释以及翻译
> MVC stands for model-view-controller. MVC is a pattern for developing applications that are well architected, testable and easy to maintain. MVC-based applications contain:
- M odels: Classes that represent the data of the application and that use validation logic to enforce business rules for that data.
- V iews: Template files that your application uses to dynamically generate HTML responses.
- C ontrollers: Classes that handle incoming browser requests, retrieve model data, and then specify view templates that return a response to the browser.

翻译：
> MVC代表: 模型-视图-控制器 。MVC是一个架构良好并且易于测试和易于维护的开发模 式。基于MVC模式的应用程序包含：  
- Models： 表示该应用程序的数据并使用验证逻辑来强制实施业务规则的数据类。
- Views：  应用程序动态生成 HTML所使用的模板文件。
- Controllers： 处理浏览器的请求，取得数据模型，然后指定要响应浏览器请求的视图模板。

## 控制器
这些概念说来说去似乎越绕越复杂，闲话少叙，从第一个控制器开始。

### Step1：添加控制器
右键点击解决方案管理器中的**Controllers**，单击**MVC 5控制器 - 空**，然后单击“**添加**”。名称填写为**HelloController**。
![添加控制器](asp-mvc-cont/2-1.png)

### Step2：修改HelloController
![编辑控制器](asp-mvc-cont/2-2.png)
上述例子中创建HelloController中修改了默认的Index方法，将返回值修改为了一行html代码，开启浏览器调试查看。

### Step3：直接访问控制器
![访问控制器](asp-mvc-cont/2-3.png)
输入/hello 返回指定的Html

### Step4：验证第二个方法
![访问方法](asp-mvc-cont/2-4.png)
/hello/welcome返回指定的Html

这一切是如何实现的呢？ASP.NET MVC会调用不同的控制器类（和其内部不同的操作方法）这取决于传入URL。 所使用的ASP.NET MVC的默认URL路由逻辑使用这样的格式来判定哪些代码以便调用。

---

## 路由
这里就提到了一个很重要的概念，路由(URL Routing)，什么是路由，在ASP.NET MVC中，一个URL请求是由对应的一个Controller中的Action来处理的，由URL Routing来告诉MVC如何定位到正确的Controller和Action。当我们在VS中创建一个新的 ASP.NET MVC程序，程序将会自动使用默认的路由表。  

### 默认路由表
默认路由表存放在`App_Start/RouteConfig.cs` 中。
![默认路由表](asp-mvc-cont/2-5.png)
在RouteConfig.cs中，定义路由规则的格式如下：
`/[Controller]/[ActionName]/[Parameters]`  

### 路由的组成
如果应用程序并没有提供任何URL段的，默认为“Home”的控制器和“Index” 的操作方法，在上面的代码中的defaults部分指定的： 

- 第一部分的URL确定哪个控制器类会被执行。因此 `/HelloWorld `映射到 `HelloWorldController `控制器类。
- 第二部分的URL确定要执行控制器类中的那个操作方法。因此 `/HelloWorld/Index `会使得 `HelloWorldController`控制器类的`Index`方法被执行。 **请注意，我们只需要浏览 `/HelloWorld `路径，默认情况下会调用Index方法**。如果没 有明确的指定操作方法，Index方法会默认的被控制器类调用。
- 第三部分的URL段（Parameters参数）是路由数据。

因此，以刚才的hello访问为例浏览:
`http://localhost:xxxx/hello/Welcome` Welcome方法会被运行并返回字符 串:`"This is the Welcome action method...”`。   
默认的MVC映射为 `/[Controller]/[ActionName]/[Parameters]` 对于这个URL，控制器类是`Hello`，操作方法是`Welcome`，目前还没有使用过URL的`[Parameters] `部分。

### 通过路由传参
URL的`Parameters`，也就是参数的传递部分。
修改`Welcome`方法，如下图，给`welcome`方法添加两个形参`name`和`num`，并通过`htmlencode`编码后输出。
![带参数的方法](asp-mvc-cont/2-6.png)

启动浏览器调试，输入带参数的URL：
`http://localhost:xxxx/hello/welcome/?name=raphael&num=3`
![输出结果](asp-mvc-cont/2-7.png)

### 参数的自动装配
再修改一下`welcome`方法，将`num`改为`id`，输入`url`时，把`id`写在开头，用“`？`”分割，传入`name`。
![自动装配](asp-mvc-cont/2-8.png)

ASP.NET MVC的路由自动匹配了ID这个参数，为什么呢？看看上图中的 ASP.NET默认路由表，`url: "{controller}/{action}/{id}"`,这一行已经添加了`id`这个参数，因此ASP.NET MVC会自动为我们匹配`ID`参数。  

在ASP.NET MVC应用程序，通过参数传递路由数据是为更典型的应用(如同上面用 `query string`传递`ID`参数)。您还可以在`RouteConfig.cs`文件中，添加“`Hello`”的的路由，增加一条路由来传递`name 和 `numtimes`。

在上面的例子中，控制器一直在做着MVC中“VC”部分的职能：也就是视图和控制器的 工作。该控制器直接返回HTML内容。通常情况下，不会让控制器直接返回HTML，因为这样代码会变得非常的繁琐。相反，我们通常会使用一个单独的视图模板文件来帮助 生成返回的HTML。下一篇文章就从视图开始说起。 