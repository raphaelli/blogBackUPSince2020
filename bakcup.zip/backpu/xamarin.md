---
title: Xamarin-C#开发移动App-环境搭建
date: 2017-09-15 15:29:53
tags:
 - dotNET
---

## 为什么是Xamarin
>乔老爷子曾经曰过:"Stay hungry. Stay foolish."   
对的，就是要做一个蠢萌的吃货！！！  
好吧，正确的翻译是，低头前行，永不满足！  
所以喽，开坑Xamarin！

其实早在前年就接触过Xamarin，去年参加全国移动互联网开发大赛，其中的移动App技术选型也考虑过Xamarin，但是几经波折也没有正真的选用这个技术，因为它总给人一种不成熟的感觉。前两天和朋友聊到前端不好混，我说还好我不是前端。朋友问，那你是什么？我恬不知耻的说，哼，我可是全栈！牛逼是吹出去了，趁着本科期间闲暇时间还算多，把`Xamarin`捡起来重新打理大理，包括后续的技术跟进`UWP`和`ASP.NET Core`.

## 安装Xamarin
![VisualStudio安装][1]
Visual Studio 2017添加个新功能，肯定是再简单不过了，二话不说`Visual Studio Installer`点开，勾选`使用.NET的移动开发`。

**注意：**可以取消掉Google Android仿真器的勾选，使用`Genymotion`来替代他。VS自带的虚拟机已经足够好用，可以自行甄别，或使用物理机代替。

勾选完成点击修改，完成安装，然后来看看`Genymotion`.

## 安装Genymotion
[Genymotion官网](https://www.genymotion.com/)

Genymotion本身是收费产品，但是对个人用户免费，所以赶紧注册一下把。免费的下载地址藏得很深，所以我还是提供一下好了。

[Fun-Zone](https://www.genymotion.com/fun-zone/)
![Genymotion免费][2]

安装过程是一路`Next`就对了，不要害怕，这不是某些国产软件，闭着眼睛狂点`Next`就好了！

如果是和我一样选择的是带VirtualBox的版本的话，回弹出来一个Oracle VM VirtualBox的安装界面，同样一路`Next`.

安装好后启动Genymotion，登陆个人邮箱，然后下面有个“醒目”（谁会去点他）的`Personal Use`

![个人用户使用][3]

然后同意下用户协议，添加虚拟机（安卓）

![选择系统][4]

下载比较常见4.3和6.0的系统，因为资源在国外，速度可能回有点慢，耐心等待！

>**注意**：如果遇到虚拟机无法启动等情况，可以尝试卸载软件，清除注册表，自行安装VultureBox，和单独版的Genymotion。也可以使用VS自带的虚拟机或真机调试。


## 调试Demo
启动Visual Studio 2017，新建项目，选择`Andriod`,空白应用。

![创建安卓项目][5]

调试运行

![调试运行][6]

OK,Xamarin的安装到此完成，后续有更多Xamarin的相关学习笔记和记录。

[1]: xamarin/vsinstall.PNG
[2]: xamarin/gefree.PNG
[3]: xamarin/ges1.PNG
[4]: xamarin/ges2.PNG
[5]: xamarin/vssapp.PNG
[6]: xamarin/vsrapp.PNG