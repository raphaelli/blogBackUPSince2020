---
title: Oracle 查询日期出现多余时间内容
date: 2018-11-19 14:44:44
tags:
 - WorkNote
---

> 博客新建一个分类，记录工作中遇到的一些问题和笔记。

# Oracle 查询日期出现多余时间内容
>访问API获取日期时，出现了全0的时间。而数据库查询的结果正常。

![问题](./oracle-data-query/img1.png)
![问题](./oracle-data-query/img2.png)

实际上，数据库中存储的数据是没有时间信息的，只有日期信息，因此需要转换后。

![解决](./oracle-data-query/img3.png)

```sql
TO_CHAR(A.SWRQ,'YYYY/MM/DD')AS SWRQ
```