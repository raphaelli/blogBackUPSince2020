---
title: 基于Senparc开发微信公众号
date: 2019-10-11 16:32:55
tags:
 - Senparc
---

>帮朋友做一套微信公众号/企业号下的用户积分，分享追踪的服务，初次使用Senparc，记录使用笔记和开发过程。

# 公众号信息确认/服务器关联

## 公众号
公众号注册，开通，验证，进入开发选项，完成相关配置，此处略过。

## 服务器关联
这里采用了 Senparc 框架来进行快速开发。

### 验证服务器
Nuget 安装 Senparc SDK ，这里采用 .NET Core MVC WEB API 来开发。
```c#
namespace WX_H5_ShareCount_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WeiXInController : ControllerBase
    {
        public readonly string Token = "raphaelli";

        public ActionResult Get(string signature, string timestamp, string nonce,string echostr)
        {
            if (CheckSignature.Check(signature, timestamp, nonce, Token))
            {
                return Content(echostr); //返回随机字符串则表示验证通过
            }
            else
            {
                return Content("failed:" + signature + "," + Senparc.Weixin.MP.CheckSignature.GetSignature(timestamp, nonce, Token) + "。如果您在浏览器中看到这条信息，表明此Url可以填入微信后台。");
            }
        }

    }
}
```

运行，打开浏览器，访问对应API，成功！

部署方面，这里采用了 Auzre 的直接部署，当然也可以采用其它的部署方式。

# Senparc SDK MP

## 配置

### ConfigureServices
在 ConfigureServices() 方法中加入：
```C#
    public void ConfigureServices(IServiceCollection services)
    {
        //...
        services.AddSenparcGlobalServices(Configuration)//Senparc.CO2NET 全局注册
                .AddSenparcWeixinServices(Configuration);//Senparc.Weixin 注册
    }
```
### Configure
修改 Configure() 方法传入参数，并添加代码：
```c#
    public void Configure(IApplicationBuilder app, IHostingEnvironment env, IOptions<SenparcSetting> senparcSetting, IOptions<SenparcWeixinSetting> senparcWeixinSetting)
    {
        //app.UseMvc()等设置...

        // 启动 CO2NET 全局注册，必须！
        IRegisterService register = RegisterService.Start(env, senparcSetting.Value)
                                                    .UseSenparcGlobal(false, null);

        //开始注册微信信息，必须！
        register.UseSenparcWeixin(senparcWeixinSetting.Value, senparcSetting.Value)
    }
```

### appsetting.json 
在 appsetting.json 文件下插入以下设置（可参考 Demo）：
```c#
  //以下信息会被自动识别，如无特殊说明，不用的参数可以删除，但修改 key 后将会无法自动识别！

  //CO2NET 设置
  "SenparcSetting": {
    //以下为 CO2NET 的 SenparcSetting 全局配置，请勿修改 key，勿删除任何项

    "IsDebug": true,
    "DefaultCacheNamespace": "DefaultCache",
    //分布式缓存
    "Cache_Redis_Configuration": "Redis配置",
    //"Cache_Redis_Configuration": "localhost:6379",
    "Cache_Memcached_Configuration": "Memcached配置",
    "SenparcUnionAgentKey": "SenparcUnionAgentKey"
  },
  //Senparc.Weixin SDK 设置
  "SenparcWeixinSetting": {
    //以下为 Senparc.Weixin 的 SenparcWeixinSetting 微信配置

    //微信全局
    "IsDebug": true,

    //以下不使用的参数可以删除，key 修改后将会失效

    //公众号
    "Token": "weixin",
    "EncodingAESKey": "",
    "WeixinAppId": "WeixinAppId",
    "WeixinAppSecret": "WeixinAppSecret",
    //小程序
    "WxOpenAppId": "WxOpenAppId",
    "WxOpenAppSecret": "WxOpenAppSecret",
    "WxOpenToken": "WxOpenToken",
    "WxOpenEncodingAESKey": "WxOpenEncodingAESKey",
    //企业微信
    "WeixinCorpId": "WeixinCorpId",
    "WeixinCorpSecret": "WeixinCorpSecret",

    //微信支付
    //微信支付V2（旧版）
    "WeixinPay_PartnerId": "WeixinPay_PartnerId",
    "WeixinPay_Key": "WeixinPay_Key",
    "WeixinPay_AppId": "WeixinPay_AppId",
    "WeixinPay_AppKey": "WeixinPay_AppKey",
    "WeixinPay_TenpayNotify": "WeixinPay_TenpayNotify",
    //微信支付V3（新版）
    "TenPayV3_MchId": "TenPayV3_MchId",
    "TenPayV3_Key": "TenPayV3_Key",
    "TenPayV3_AppId": "TenPayV3_AppId",
    "TenPayV3_AppSecret": "TenPayV3_AppId",
    "TenPayV3_TenpayNotify": "TenPayV3_TenpayNotify",

    //开放平台
    "Component_Appid": "Component_Appid",
    "Component_Secret": "Component_Secret",
    "Component_Token": "Component_Token",
    "Component_EncodingAESKey": "Component_EncodingAESKey",

    //扩展及代理参数
    "AgentUrl": "AgentUrl",
    "AgentToken": "AgentToken",
    "SenparcWechatAgentKey": "SenparcWechatAgentKey"
  }

```
