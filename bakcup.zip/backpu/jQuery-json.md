---
title: jQuery获取操作Form 信息
date: 2018-12-18 15:07:29
tags:
 - WorkNote
---
> 入职写的第一个功能某块，在新的流程系统中添加一个日程提醒功能，基础框架是基于 `ASP.NET MVC 5`的底层框架，前端使用了 Layui 来处理样式。在处理时，遇到了空值判断这个问题，需要用jQuery 来获取 Form 的数据，并对其进行操作和判断。

```js
var form = $("#ScheduleInfo").serializeArray();
for (var item in form) {
    //console.log(form[item].name + " is " + form[item].value);
    if (form[item].name == "ScheduleTitle" && form[item].value== "")
    {
        layer.msg("标题不能为空", { icon: 2, time: 1000, shade: [0.2, '#000', true] });
        return false;
    }
    if (form[item].name == "ScheduleContent" && form[item].value == "") {
        layer.msg("内容不能为空", { icon: 2, time: 1000, shade: [0.2, '#000', true] });
        return false;
    }
}
```

说明：
- `$("#ScheduleInfo").serializeArray();`  将form 获取为 序列化的json 。
- `form[item].name` Json 是以键值对的形式进行拼接的。