---
title: 软件系统数据字典
date: 2018-12-26 10:19:33
tags:
 - WorkNote
---

>在实际商用软件开发中，考虑到系统的配置经常需要变更，而每次都要修改系统功能或设置甚至数据内容则太过复杂，因此可以考虑引入 数据字典 这一设计，来完成软件系统功能的配置，对数据进行细化配置。

### 数据字典
数据字典的实现，总结起来大致如下：
1. 对应用程序不同类型数据集合，进行分类，管理 
2. 用code标识数据，在存储时存储code就行了

### 数据字典的好处
1. 数据集合统一在一个地方管理，便于阅读所有数据集合，理解程序。
2. 用code标识数据，在存储时存储code就行了，这样即使数据改变了，也不影响程序

### 数据字典表设计
表设计时达到的目标：**使配置的数据（字典名称，字典值），不因数据的改变，影响数据的存储（这样就需要设计字典名称的code、字典 值的code,来表示它们的唯一标识）**

注意点：设计表字段时，要有一个字典名称code,字典值code，它们要固定,不能改变。

### 数据字典设计实例 一
>附上公司目前项目的 字典表的设计 ：

![字典表](data-dic/dic.png)

这个设计中，SYS_DIC_MAIN 实现了对字典的基本管理，包括其名称，排序，类型，备注，子字典，创建/修改时间记录，伪删除功能。

在 SYS_DIC_ITEM 中则详细的定义了字典的内容，通过唯一主键ID来标识，通过PARENTID 来限定归属，同时添加了扩展参数，可以存储JSON来进行复杂配置的修改。

### 数据字典设计实例 二
这是一个从网上找到的，单表的数据字典设计：
```sql
CREATE TABLE `t_ci` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parentId` bigint(20) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL COMMENT '名称',
  `seq` int(11) DEFAULT NULL COMMENT '序号',
  `hasChild` int(11) DEFAULT NULL COMMENT '是否有子配置',
  `property` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8 COMMENT='配置表' |

```

### 数据字典设计实例 三
这是一个从网上找到的，双表的数据字典设计：
```sql
CREATE TABLE dictionary_type` (
  `ID` varchar(255) NOT NULL COMMENT '主键',
  `CODE` varchar(255) DEFAULT NULL COMMENT '编码',
  `STATUS` int(11) DEFAULT NULL COMMENT '状态',
  `TEXT` varchar(255) DEFAULT NULL COMMENT '字典类型名称',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='字典类型表' 
 
 CREATE TABLE `dictionary_item` (
  `ID` varchar(255) NOT NULL COMMENT '主键',
  `SORT` int(11) DEFAULT NULL COMMENT '序号',
  `TEXT` varchar(255) DEFAULT NULL COMMENT '字典内容',
  `VALUE` int(11) DEFAULT NULL COMMENT '值',
  `TYPE_ID` varchar(255) DEFAULT NULL COMMENT '类型ID',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='字典类型条目表'
```

### 说回到数据字典
不论怎么设计数据字典的表都可以，按照自己的实际项目的需要，对数据字典表进行设计，以实现最方便的配置数据，配置项目系统参数，从而实现项目开发和项目实施的高效率。这应该就是数据字典的意义所在。