---
title: dotNet Core搭建图床
date: 2017-12-30 23:53:08
tags:
 - dotNET
---

>折腾dotNet Core也有一段时间了，立个小项目写一写，实现一下。

- [Github](https://github.com/raphaelli/dotNet-ImgBed)

# 功能

预计实现：
图片上传返回唯一Url
用户功能
时效功能
前端部分优化


分支:
最小功能图床
复杂功能

