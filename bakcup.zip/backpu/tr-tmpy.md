---
title: 【译】用于时间序列预测的Python环境
date: 2018-02-07 22:39:58
tags:
 - Other
---
>原文作者：Jason Brownlee  
原文地址：https://machinelearningmastery.com/python-environment-time-series-forecasting/  
受腾讯云云＋社区翻译社委托翻译 译者：楠槡

Python生态系统正在不断的成长和壮大，并可能成为应用机器学习的主要平台。

采用Python进行时间序列预测的主要原因是因为它是一种通用编程语言，可以用于研发和生产。

在这篇文章中，您将了解到Python环境下的时间序列预测。

阅读这篇文章后，您会掌握：

- 三个对时间序列预测至关重要的标准Python库。
- 如何安装和设置开发的Python和SciPy环境。
- 如何确认您的开发环境正确工作，并准备好进行时间序列预测。

让我们开始吧。

## 为什么是Python？

Python是一种通用的解释性编程语言（不同于R或Matlab）。

主要是因为语言的重点在于可读性，所以学习和使用很容易。

这是一种普遍流行的语言，在StackOverflow的调查中一直出现在前十名编程语言中。（例如[2015年的调查结果](http://stackoverflow.com/research/developer-survey-2015)）

Python是一种动态语言，非常适合于交互式开发和快速原型开发，支持大型应用程序的开发。

由于优秀的库支持，Python也广泛用于机器学习和数据科学。它已经迅速成为[机器学习和数据科学从业者的主要平台](http://machinelearningmastery.com/python-growing-platform-applied-machine-learning/)之一，甚至比R平台更受用户们喜爱（见下图）。

![Python机器学习职位与R机器学习职位对比](https://3qeqpr26caki16dnhd19sv6by6v-wpengine.netdna-ssl.com/wp-content/uploads/2016/10/Python-Machine-Learning-Jobs-vs-R-Machine-Learning-Jobs.png)

这是一个显而易见且非常重要的考虑因素。

这意味着你可以用同一种编程语言来完成你的研究和开发（弄清楚所要使用的模型），从而大大简化了从开发到实际操作的过渡。 

## Python时间序列库

[SciPy](https://www.scipy.org/)是用于数学，科学和工程学的一个Python库 。它是进行时间序列预测的一个Python附加内容。

两个SciPy库为大多数人提供了基础; 他们是[NumPy](http://www.numpy.org/)用于提供高效的数组操作，[Matplotlib](http://matplotlib.org/)用于绘制数据。有三个高级SciPy库，它们为Python中的时间序列预测提供了关键特性。

他们分别是`pandas`，`statsmodels`和用于数据处理的 `scikit-learn` ，时间序列建模和机器学习。

我们来一一了解一下。

### pandas

[pandas 库](http://pandas.pydata.org/)提供了Python中加载和处理数据的高性能工具。

它建立在SciPy生态系统的基础之上，主要使用NumPy数组，但提供了方便易用的`_DataFrame_`和`_Series_`数据结构来表示数据。

pandas 提供了[对时间序列数据支持的特别关注](http://pandas.pydata.org/pandas-docs/stable/timeseries.html)。

与`pandas`时间序列预测相关的主要功能包括：

- 用于表示单变量时间序列的`_Series_`对象。
- 显式处理数据和日期时间范围内的日期时间索引。
- 变换，如移位、滞后和填充。 
- 重采样、下采样和聚集等重采样方法 

### statsmodels

[statsmodels库](http://statsmodels.sourceforge.net/)提供统计建模的工具。

它建立在SciPy生态系统的基础之上，并支持NumPy阵列和Pandas _系列_对象形式的数据。

它提供了一套统计测试和建模方法，以及[专门用于时间序列分析的工具](http://statsmodels.sourceforge.net/stable/tsa.html)，也可以用于预测。

与时间序列预测相关的statsmodels的主要特点包括：

- 平稳性的统计测试，例如增强型Dickey-Fuller单位根检验。
- 时间序列分析图如自相关函数（ACF）和部分自相关函数（PACF）。
- 线性时间序列模型，如自回归（AR），移动平均（MA），自回归移动平均（ARMA）和自回归积分移动平均（ARIMA）。

### scikit-learn

[scikit-learn](http://scikit-learn.org/)是Python中用于开发和实践机器学习的库。

它建立在SciPy生态系统的基础之上。名称“sckit”表明它是一个SciPy插件或工具包。您可以[查看可用SciKits的完整列表](http://scikits.appspot.com/scikits)。

这个库重点用于分类，回归，聚类等的机器学习算法。它还提供了相关任务的工具，如评估模型，调整参数和预处理数据。

与scikit-learn中的时间序列预测相关的主要功能包括：

- 数据准备工具套件，比如缩放和输入数据。
- 这套机器学习算法可以用来模拟数据并进行预测。
- 重采样方法估计一个不可视的数据模型的性能，特别是[TimeSeriesSplit](http://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html)。

## Python环境安装

本节将为您提供有关设置Python环境，并将之用于进行时间序列预测的一般建议。

我们将涵盖：

1. 用Anaconda自动安装。
2. 用您的平台的包管理手动安装。
3. 确认已安装环境。

如果您已经有一个正常运行的Python环境，请跳到确认步骤以检查您的软件库是否是最新的。

让我们开始吧

### 1.自动安装

如果您对在您的机器上手动安装软件没有信心，或者您在使用Microsoft Windows系统，那么有一个简单的选择。

有一个名为[Anaconda Python](https://www.continuum.io/downloads)的发行版，可以免费下载和安装。

它支持Microsoft Windows，Mac OS X和Linux三大平台。

它包括Python，SciPy和scikit-learn——您所需要的用于学习，练习和使用Python环境下的时间序列预测的所有环境。

您可以在这里开始使用Anaconda Python：

- [Anaconda 安装](https://docs.continuum.io/anaconda/install)

### 2.手动安装

有多种方法来安装特定于您的平台的Python环境。

在本节中，我们介绍如何安装Python环境并进行时间序列预测。

#### 如何安装Python

第一步是安装Python。我推荐使用Python 2.7或Python 3.5。

每个平台的Python的安装会有不少差异。相关说明请参阅：

- [Python入门指南中](https://wiki.python.org/moin/BeginnersGuide)
- [下载Python](https://wiki.python.org/moin/BeginnersGuide/Download)

在Mac OS X与MacPorts，使用如下指令即可安装：

```
sudo port install python35
sudo port select --set python python35
sudo port select --set python3 python35
```

#### 如何安装SciPy

有很多方法可以安装SciPy。

例如，两种常用的方法是在您的平台上使用包管理（例如 ，RedHat 上的_dnf_或OS X 上的_macports_）或使用Python包管理工具（如_pip）_。

SciPy文档非常出色，涵盖了页面上多个不同平台的操作说明[安装SciPy Stack](https://www.scipy.org/install.html)。

安装SciPy时，请确保已经安装以下包：

- SciPy
- numpy
- matplotlib
- pandas
- statsmodels

在Mac OS X与_MacPorts_，请输入：

```
sudo port install py35-numpy py35-scipy py35-matplotlib py35-pandas py35-statsmodels py35-pip
sudo port select --set pip pip35
```

在Fedora Linux上用_dnf_，请输入：

```
sudo dnf install python3-numpy python3-scipy python3-pandas python3-matplotlib python3-statsmodels
```

#### 如何安装scikit-learn

scikit-learn 库必须单独安装。

我建议你使用与安装SciPy一样的方法来安装scikit-learn：

查阅[安装scikit-learn的说明](http://scikit-learn.org/stable/install.html)，但仅适用于使用Python _pip_包管理器安装。

在Linux和Mac OS X上，建议通过键入以下命令来安装scikit-learn：

```
sudo pip install -U scikit-learn
```

### 3.确认您的环境

搭建好开发环境后，还必须确认它是否能正常的运行。

首先检查一下Python是否安装成功。打开命令行并输入：

```
python -V
```

应该会看到如下的回应：

```
Python 2.7.12
```

或则

```
Python 3.5.3
```

现在，已经确认这些库已经安装成功。

创建一个名为versions.py的新文件，复制并粘贴下面的代码片段，并将文件保存为_versions.py_。

```
# scipy
import scipy
print('scipy: %s' % scipy.__version__)
# numpy
import numpy
print('numpy: %s' % numpy.__version__)
# matplotlib
import matplotlib
print('matplotlib: %s' % matplotlib.__version__)
# pandas
import pandas
print('pandas: %s' % pandas.__version__)
# statsmodels
import statsmodels
print('statsmodels: %s' % statsmodels.__version__)
# scikit-learn
import sklearn
print('sklearn: %s' % sklearn.__version__)
```

在命令行或者您最喜欢的Python编辑器中运行该文件。例如，键入：

```
python versions.py
```

这将打印您需要的每个库的版本。

例如，在我撰写本系统的时候，我得到了以下结果

```
scipy: 0.18.1
numpy: 1.11.3
matplotlib: 1.5.3
pandas: 0.19.1
statsmodels: 0.6.1
sklearn: 0.18.1
```

如果您有错误，请立即停止并修复。您可能需要查阅针对您平台的文档。

## 概要

这篇文章，带您大致了解了Python环境下的的时间序列预测。

诸如一下内容：

- Pandas，statsmodels 和 scikit-learn 库是使用Python预测时间序环境中最重要的部分。
- 如何自动和手动设置Python SciPy环境用于开发。
- 如何确认您的环境已正确安装，并准备好开始开发模型。

还为您介绍了如何在工作站上安装用于机器学习的Python环境。