---
title: 使用谷歌 BBR TCP 拥塞控制算法为服务器加速
date: 2018-07-11 21:37:01
tags:
 - Linux
---



> 最近在Anduin大佬的视频- [用谷歌的黑科技让网速提升几百倍 - 完整教学、测速](https://www.bilibili.com/video/av26516833) 中了解到了谷歌的BBR，在实际测试时候发现这的确是一个能够大大增强服务器使用体验的神器，记录下操作笔记，备忘。



服务器 ： aliyun-ubuntu 16.04 使用 HWE 更换内核 - [HWE相关](https://askubuntu.com/questions/248914/what-is-hardware-enablement-hwe)



# 什么是BBR

BBR 是 Google 推出的一个开源「TCP 拥塞控制算法」，它是以 Linux 内核模块的形式加载，可以最大化 Linux Server 的网络吞吐量。

简单地说，开启 BBR 的 Linux Server 和不开启 BBR 的 Linux Server，在持续传输数据方面可以有非常大的不同。这个技术非常合适应用在视频、下载网站上，个人的话，当然是科学上网了。

BBR 尽管还没有在主流发行版中默认开启，但 Google 已经在 YouTube 网站上实践了很久，可以说是很成熟的一样技术了。

- [BBR - Github 地址](https://github.com/google/bbr)
-  [Linux Kernel 4.9 中的 BBR 算法与之前的 TCP 拥塞控制相比有什么优势？ - 李博杰的回答 - 知乎](https://www.zhihu.com/question/53559433/answer/135903103)



# 开启BBR

开启BBR 大致分为如下几步：

- 检测当前算法
- 查看内核版本
- 更换到合适的内核
- 安装BBR

**Here we go ！~**

## 检测当前TCP 控制算法

在开始之前，我们可以先看看 BBR 是否已经启用了：

执行这条指令可以返回当前 Linux 内核可以使用的 TCP 拥堵控制算法：

```sh
sysctl net.ipv4.tcp_available_congestion_control
```

在我的 Server 上，返回了：

```sh
net.ipv4.tcp_available_congestion_control = cubic reno
```

我们再确认一次当前使用的控制算法：

```sh
sysctl net.ipv4.tcp_congestion_control
```

返回内容是：

```sh
net.ipv4.tcp_congestion_control = cubic
```

很显然，就是使用了 cubic 这一默认的算法。



## 为 Ubuntu 16.04 安装 4.10 + 新内核

因为 BBR 只能配合 Linux Kernel 4.10 以上内核才能使用。而Ubuntu 16.04 默认使用的是  Linux 4.4.0 内核 。

有 Linux 基础知识的小伙伴应该都知道，手动下载安装的新内核，是十分危险的操作，而且无法保证后续能得到及时的安全更新。那么怎么办？

这里推荐使用 HWE 版本的内核，它就在官方源里。

HWE，即：Hardware Enablement，是专门为在老的系统上支持新的硬件而推出的内核。你可以像安装其他软件包一样在 Ubuntu 16.04 里非常容易的安装它：

```sh
sudo apt-get install linux-generic-hwe-16.04
```

安装好以后使用`reboot` 或物理重启电脑

然后输入：

```
uname -a
```

看看是不是变成 4.10 内核了？

```
Linux ubuntu 4.13.0-45-generic 
```



## 为 Ubuntu 16.04 启用 BBR

有了新内核以后，我们就可以为新内核装载 BBR 模块了：

```sh
sudo modprobe tcp_bbr
echo "tcp_bbr" | sudo tee -a /etc/modules-load.d/modules.conf
```



装载后，再执行 `sysctl net.ipv4.tcp_available_congestion_control` 命令，你就可以看到 BBR 出现在输出结果里了。

接下去再正式启用它：

```sh
echo "net.core.default_qdisc=fq" | sudo tee -a /etc/sysctl.conf
echo "net.ipv4.tcp_congestion_control=bbr" | sudo tee -a /etc/sysctl.conf
sudo sysctl -p
```

执行完这几条指令后，再用 `sysctl net.ipv4.tcp_congestion_control` 验证一下，看到返回结果是：

```
net.ipv4.tcp_congestion_control = bbr
```

It works！



