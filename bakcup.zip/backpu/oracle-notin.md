---
title: Oracle IN 和 <> 的用法
date: 2018-11-21 09:03:36
tags:
 - WorkNote
---

在Oracle 中查询数据时，有时候可能会跨表查询一些某一字段内容不为某些内容的数据，就可以用到`NOT IN`和`<>`.

如下：

```sql
SELECT K.*
FROM (
	SELECT PRJID
	FROM Wfm_Actinst t
	WHERE ACCEPTBY <> 'ADMIN'
		AND StepState IN (N'待接收'',', N'待完成')
) A
	INNER JOIN (
		SELECT *
		FROM WFM_ACTINST
		WHERE ACCEPTBY = 'ADMIN'
			AND STEPSTATE = N'已完成'
	) K ON K.PRJID = A.PRJID 
```

就可以过滤由 ADMIN 完成 且 接收状态不为 ADMIN 的所有记录。

实际的需求是： 展示一个用户参与的项目，而当前环节参与完后，记录状态则会标记为 待接收 或待完成，而现在要求查询出有该用户参与过的项目，则可以查出该表中，不由该用户接收完成的，和该用户已经接收完成的所有记录，通过 唯一key Prjid 来关联。

>另外，Oracle 中文编码的问题，IN 和 NOT IN 在处理中文数据执行后发现无结果，可以加 `N''` 来处理。

