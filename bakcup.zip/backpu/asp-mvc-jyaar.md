---
title: ASP.NET MVC 页面校验和区域
date: 2018-04-01 16:00:28
tags:
 - dotNET
---
>两个内容较少的point，放在一起说一下。

# 校验
通常来说，web项目通常使用前后端混合校验，使用诸如：`Bootstrap Validator`,`jquery.validate.js`，配合 MVC框架来做校验则。

>其实不论是前端校验还是后端校验，亦或是混合校验，都是为了避免用户输入异常的数据，导致程序出错或数据非法，同时规避Sql注入和反爬虫等等。在保证数据和信息的安全性的同时，也要考虑用户体验，大量的数据输入限制，同时也会影响用户对系统的体验。


具体步骤分为两步：

1. MVC 的 HtmlHelper 提供了一个 `Html.ValidationMessageFor()` 的方法来显示校验信息，也可以用 `Html.ValidationSummary()` 统一显示。

2. 在点击提交按钮后，转到后端 Action ，使用 `ModelState.IsVaild()` 判断前端验证是否成功，如果返回true 表示验证成功。

先来创建类，作为Model
```cs
public class User
{
    public int Uid { get; set; }
    public string Uname { get; set; }
    public string Upass { get; set; }
}
```

> .Net框架中 System.ComponetModel.DataAnnotations命名空间包括了很多内置的验证特性，用于修饰属性，列举几个常用项:
- [Required]  必须的
- [StringLength]  限制长度
- [Range]  范围
- [RegularExpression]  正则表达式
- 属性 ErrorMessage 指定错误信息

```cs
public class User
{
    [Required(ErrorMessage ="Uid不能为空😊")]
    [Range(1,999,ErrorMessage ="Uid不在合理范围内（1-999）😱")]
    public int Uid { get; set; }
    public string Uname { get; set; }
    public string Upass { get; set; }
}
```

全部方法属性可以查看
 [DataAnnotations 命名空间](https://msdn.microsoft.com/zh-cn/library/system.componentmodel.dataannotations(v=vs.110).aspx)

然后在视图中创建一个表单用于提交和验证：
```cs
@model STU_mvc.Models.User
@{
    ViewBag.Title = "Add";
}
<script src="~/Scripts/jquery-1.10.2.min.js"></script>
<script src="~/Scripts/jquery.validate.min.js"></script>
<script src="~/Scripts/jquery.validate.unobtrusive.min.js"></script>
<h2>Add</h2>

@using (Html.BeginForm("Add", "User", FormMethod.Post))
{
    <span>Uid: </span> @Html.TextBoxFor(u => u.Uid) @Html.ValidationMessageFor(u => u.Uid) <br />
    <span>Name: </span>@Html.TextBoxFor(u => u.Uname) @Html.ValidationMessageFor(u => u.Uname) <br />
    <span>Pass: </span>@Html.TextBoxFor(u => u.Upass) @Html.ValidationMessageFor(u => u.Upass)<br. />
    <input type="submit" name="reg" value="Registered" />

}
```

这里引用了已经封装好的 jQuery.validate 插件，及其异步版本。

控制器中的方法此处略过。

# 区域
区域的意义在于，当项目结构过于复杂之后，使用区域分层，将项目结构进行优化。

直接选中当前的项目，右键添加区域。

区域实际上是将MVC拆分成了不同的子模块，每个模块都有自己的MVC。

重点说一下区域的路由注册，在创建一个区域后，会自动生成一个 `区域名`+`AreaRegistration.cs` 的文件，他会重写 `RegisterArea` 方法来注册路由。

```cs
public override void RegisterArea(AreaRegistrationContext context) 
{
    context.MapRoute(
        "UserManage_default",
        "UserManage/{controller}/{action}/{id}",
        new { action = "Index", id = UrlParameter.Optional }
    );
}
```

**注意**：此时，根目录下的`Global.asax`文件中，可以看到，在原路由注册之前，新增了一行：`AreaRegistration.RegisterAllAreas();` 因此，区域路由的匹配优先级是高于默认路由的。