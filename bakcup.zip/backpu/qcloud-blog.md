---
title: 腾讯云服务器搭建个人博客教程
date: 2016-10-30 21:56:37
tags:
 - Other
---
# 腾讯云服务器搭建个人博客教程
> 本教程用于武汉商贸职业学院2016年10月云+校园推广活动公开课使用，发布于博客暂作存档。

---
## 实验架构

![此处输入图片的描述][1]
***

## 环境说明

实验环境采用Ubuntu下Nginx服务+PHP（WordPress软件）+MySql数据库。
    如下图所示：
![服务器环境说明][2]

其中Ubuntu作为服务器系统，Nginx作为网站服务器，PHP作为语言环境，并安装WordPress博客软件，连接MySql数据库，最终搭建完成一个个人博客。
    
闲话少叙，我们直接进入搭建。
***

## 登陆云主机

#### **Step1:**
从本地登陆到Linux云服务器，我们需要下载一款链接工具。 
这里我们使用Putty来链接服务器。  
访问：[Putty](http://demofile-10065184.cos.myqcloud.com/putty.exe)  
下载Putty.exe

#### **Step2：**
登录到Linux服务器 
1. 双击打开Putty，在Hostname中输入IP地址，见我们发给大家的小纸条上的服务器IP
2. 点击下方的Open，进入命令行界面 
3. 登录用户名ubuntu，密码见小纸条
4. 登陆成功后，输入命令sudo su 切换到root用户下。 （ubuntu权限机制）
![登录到服务器][3]
***

## 安装并配置必要的软件

#### **Step1:更新apt源**
`# apt-get update`


#### **Step2:安装Nginx**
`# apt-get install nginx`

#### **Step3:重启并验证Nginx安装是否成功**
`# service nginx restart`
浏览器中输入服务器IP，显示 Welcome to nginx!则成功！

#### **Step4:安装PHP执行环境**
`# apt-get install php5-fpm`

#### **Step5:安装PHP MySQL扩展**
`# apt-get install php5-mysql`

***

## 获取wordpress源码，完成相关配置
#### **Step1:获取WordPress源码**
`# wget http://download-10012769.cos.myqcloud.com/wordpress-4.5.3-zh_CN.tar.gz `

#### **Step2:创建web service工作目录**
`# mkdir /var/www `

#### **Step3:将wordpress源码解压到web service 工作目录**
`# tar -xzf wordpress-4.5.3-zh_CN.tar.gz -C /var/www `

#### **Step4:修改目录权限**
`# chown -R www-data:www-data /var/www/wordpress`

##配置Nginx
#### **Step1:获取在线脚本**
`# wget http://edustack-10027546.cos.myqcloud.com/Linux%20Tools/qcloud-wordpress`

#### **Step2:执行脚本**
`# sh qcloud-wordpress`

#### **Step3:重启web service**
`# service nginx restart`

#### **Step4:重启php-fpm**
`# service php5-fpm restart`

***
##安装配置wordpress
#### **Step1:访问站点**
浏览器输入服务器IP访问

#### **Step2:填写数据库信息**
点击下一步安装，输入你的数据库信息
数据库地址，用户名，密码，参见小纸条
表头不用做修改
然后点击下一步安装 

#### **Step2:填写博客（站点）信息**
根据自己的信息填写博客信息，并完成安装


[1]: qcloud-blog/1.png
[2]: qcloud-blog/2.png
[3]: qcloud-blog/3.gif