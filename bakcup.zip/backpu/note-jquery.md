---
title: jQuery Cheat—Sheet（jQuery学习笔记）
date: 2016-11-05 09:18:33
tags:
 - Font-end
---
# jQuery Cheat—Sheet（jQuery学习笔记）

>Web前端学习笔记之——jQuery学习笔记

---
# 什么是jQuery？

jQuery是一种JavaScript库，实现了常见任务的自动化和复杂任务简单化。
  jQuery库为Web脚本编程提供了通用的抽象层，使之适合任何脚本编程情景。
  jQuery能满足以下需求：
> 取得文档中的元素、修改页面外观、改变文档内容、响应用户的交互操作、为页面添加动态效果、不刷新加载、简化常见的JavaScript任务。

---


# jQuery版本？

> jQuery 2.0 不再支持IE 6/7/8 了，但是 jQuery 1.9 会继续支持

  jQuery可以下载使用，有两个版本的 jQuery 可供下载

 - jquery-X.X.X.min.js   Production version - 用于实际的网站中，已被精简和压缩。  
   
 - jquery-X.X.X.js       Development version - 用于测试和开发（未压缩，是可读的代码）

---

# 使用jQuery
可以通过多种方法在网页中添加 jQuery。 您可以使用以下方法：

 - 从 jquery.com 下载 jQuery 库
 - 从 CDN 中载入 jQuery, 如从 Google 中加载 jQuery

### 本地jQuery
```
<head>
    <script src="jquery-1.10.2.min.js"></script>
    <!--Src 填写本地下载的jquery路径-->
 </head>
```
### 在线jQuery
```
<head>
    <script src="http://libs.baidu.com/jquery/1.10.2/jquery.min.js"></script>
    <!--百度CDN提供的在线jquery库-->
</head>
```
---

# jQuery语法
通过 jQuery，可以选取（查询，query） HTML 元素，并对它们执行"操作"（actions）。
### jQuery 语法
jQuery 语法是通过选取 HTML 元素，并对选取的元素执行某些操作。
基础语法： `$(selector).action()`

 - 美元符号定义 jQuery
 - 选择符（selector）"查询"和"查找" HTML 元素
 - jQuery 的 action() 执行对元素的操作

### 实例:
```
$(this).hide() - 隐藏当前元素
$("p").hide() - 隐藏所有 <p> 元素
$("p.test").hide() - 隐藏所有 class="test" 的 <p> 元素
$("#test").hide() - 隐藏所有 id="test" 的元素
```
### 文档就绪事件
所有 jQuery 函数位于一个 document ready 函数中：
```
$(document).ready(function(){

   // 开始写 jQuery 代码...

});
```
**这是为了防止文档在完全加载（就绪）之前运行 jQuery 代码。**
如果在文档没有完全加载之前就运行函数，操作可能失败。下面是两个具体的例子：

 - 试图隐藏一个不存在的元素
 - 获得未完全加载的图像的大小

提示：简洁写法（与以上写法效果相同）:
```
$(function(){

   // 开始写 jQuery 代码...

});
```
以上两种方式你可以选择你喜欢的方式实现文档就绪后执行jQuery方法。

---
# jQuery选择元素
  DOM-Document Object Model 文档对象模型 以树状表示的文档模型
> 为了创建jQuery对象，就用使用$()函数。函数接受CSS选择符作为参数，充当一个工厂，返回包含页面中对应元素的jQuery对象。jQuery对象选择符有三种：标签名、ID、类  可以单独使用，也可以与其他选择符组合使用


### 元素选择器
jQuery 元素选择器基于元素名选取元素。
在页面中选取所有`<p>`元素:
```
$("p")
```

### id选择器
通过 id 选取元素语法如下：
```
$("#test")
```

### .class 选择器
jQuery 类选择器可以通过指定的 class 查找元素。
```
$(".test")
```

### 其他选择器
![jQuery其他选择器][1]


### 混合选择 eg：
`$('#selected-plays > li')`
> 子元素选择符 >  查找ID为selected-plays元素的子元素（>）中所有的列表项

---

# jQuery 事件
什么是事件？

> 页面对不同访问者的响应叫做事件。 
事件处理程序指的是当 HTML 中发生某些事件时所调用的方法。

### jQuery 事件方法语法

> 在 jQuery 中，大多数 DOM 事件都有一个等效的 jQuery 方法。

页面中指定一个点击事件：
```
$("p").click();
```
下一步是定义什么时间触发事件。您可以通过一个事件函数实现：
```
$("p").click(function(){
  // 动作触发后执行的代码!!
});
```
### 常用的 jQuery 事件方法
#### 文档DOM加载完成
```
$(document).ready()
```

方法允许我们在文档完全加载完后执行函数。该事件方法在 jQuery 语法 章节中已经提到过。

#### 点击事件
当点击元素是，会发生 click 事件。
在下面的实例中，当点击事件在某个 `<p>` 元素上触发时，隐藏当前的`<p>`元素：
```
$("p").click(function(){
  $(this).hide();
});
```

#### 双击事件
当双击元素时，会发生 dblclick 事件。
在下面的实例中，当双击事件在某个 `<p>` 元素上触发时，隐藏当前的`<p>`元素：
```
$("p").dblclick(function(){
  $(this).hide();
});
```

#### 鼠标穿过事件
当鼠标指针穿过元素时，会发生 mouseenter 事件。
在下面的实例中，当鼠标穿过 `<p1>` 元素时，弹出`“You entered p1!”`警告框：
```
$("#p1").mouseenter(function(){
  alert("You entered p1!");
});
```

#### 鼠标离开事件
当鼠标指针离开元素时，会发生 mouseleave 事件。
在下面的实例中，当鼠标离开 `<p1>` 元素时，弹出`“Bye! You now leave p1!”`警告框：
```
$("#p1").mouseleave(function(){
  alert("Bye! You now leave p1!");
});
```

#### 鼠标移入并点击事件
当鼠标指针移动到元素上方，并按下鼠标按键时，会发生 mousedown 事件。
在下面实例中，鼠标移入`<p1>`元素，并点击时，弹出`“Bye! You now leave p1!”`警告框：
```
$("#p1").mousedown(function(){
  alert("Mouse down over p1!");
});
```

#### 鼠标释放事件
当在元素上松开鼠标按钮时，会发生 mouseup 事件。
在下面实例中，鼠标点击`<p1>`元素，释放时，弹出`“Mouse up over p1!”`警告框：
```
$("#p1").mouseup(function(){
  alert("Mouse up over p1!");
});
```

#### 鼠标经过悬停事件
`hover()`方法用于模拟光标悬停事件。
当鼠标移动到元素上时，会触发指定的第一个函数(mouseenter，);
当鼠标移出这个元素时，会触发指定的第二个函数(mouseleave)。
下面实例中，鼠标移入`<p1>`元素时，触发mouseenter，弹出`“Mouse up over p1!”`警告框；
鼠标移出`<p1>`元素时，触发mouseleave，弹出`“Bye! You now leave p1!”`警告框；
```
$("#p1").hover(function(){
  alert("You entered p1!");
  },
  function(){
  alert("Bye! You now leave p1!");
});
```

#### 获得焦点事件
当元素获得焦点时，发生 focus 事件。
当通过鼠标点击选中元素或通过 tab 键定位到元素时，该元素就会获得焦点。
下面实例中，`<input>`元素获得焦点，将其CSS样式做出修改。
```
$("input").focus(function(){
  $(this).css("background-color","#cccccc");
});
```

#### 失去焦点事件
当元素失去焦点时，发生 blur 事件。
下面实例中，`<input>`元素失去焦点，将其CSS样式做出修改。
```
$("input").blur(function(){
  $(this).css("background-color","#ffffff");
});
```
### 其他jQuery事件
![jQuery事件][2]

---

#jQuery 效果
### 隐藏和显示

#### jQuery hide() 和 show()
jQuery hide() 和 show()
通过 jQuery，您可以使用 hide() 和 show() 方法来隐藏和显示 HTML 元素：
```
//hide元素点击时隐藏<p>标签
$("#hide").click(function(){
  $("p").hide();
});
//show元素点击时隐藏<p>标签
$("#show").click(function(){
  $("p").show();
});
```

**语法:**
```
$(selector).hide(speed,callback);
$(selector).show(speed,callback);
```
可选的 speed 参数规定隐藏/显示的速度，可以取以下值："slow"、"fast" 或毫秒。
可选的 callback 参数是隐藏或显示完成后所执行的函数名称。
下面的例子演示了带有 speed 参数的 hide() 方法：
```
$("button").click(function(){
  $("p").hide(1000);
});
```
#### jQuery toggle()
通过 jQuery，您可以使用 toggle() 方法来切换 hide() 和 show() 方法。
显示被隐藏的元素，并隐藏已显示的元素：
```
//点击button隐藏p标签，再次点击显示
$("button").click(function(){
  $("p").toggle();
});
```

### 淡入和淡出
#### jQuery fadeIn()
jQuery fadeIn() 用于淡入已隐藏的元素。
语法:`$(selector).fadeIn(speed,callback);`

> 可选的 speed 参数规定效果的时长。它可以取以下值："slow"、"fast" 或毫秒。.
可选的 callback 参数是 fading 完成后所执行的函数名称。

下面的例子演示了带有不同参数的 fadeIn() 方法：
```
$("button").click(function(){
  $("#div1").fadeIn();   //淡入已经隐藏的div1
  $("#div2").fadeIn("slow");   //慢速淡入已经隐藏的div2
  $("#div3").fadeIn(3000);     //3000ms后完全淡入隐藏的div3
});
```

#### jQuery fadeOut()
jQuery fadeOut() 方法用于淡出可见元素。
语法:`$(selector).fadeOut(speed,callback);`
可选的 speed 参数规定效果的时长。它可以取以下值："slow"、"fast" 或毫秒。
可选的 callback 参数是 fading 完成后所执行的函数名称。
下面的例子演示了带有不同参数的 fadeOut() 方法：
```
$("button").click(function(){
  $("#div1").fadeOut();   //淡出要隐藏的div1
  $("#div2").fadeOut("fast");   //快速淡出要隐藏的div2
  $("#div3").fadeOut(5000);     //5000ms后完全淡出要隐藏的div3
});
```

#### jQuery fadeToggle()
jQuery fadeToggle() 方法可以在 fadeIn() 与 fadeOut() 方法之间进行切换。

 - 如果元素已淡出，则 fadeToggle() 会向元素添加淡入效果。
 - 如果元素已淡入，则 fadeToggle() 会向元素添加淡出效果。

语法:`$(selector).fadeToggle(speed,callback);`
可选的 speed 参数规定效果的时长。它可以取以下值："slow"、"fast" 或毫秒。
可选的 callback 参数是 fading 完成后所执行的函数名称。
下面的例子演示了带有不同参数的 fadeToggle() 方法：
```
$("button").click(function(){
  $("#div1").fadeToggle();    //若未隐藏，则淡出；若已隐藏，则淡入
  $("#div2").fadeToggle("slow");
  $("#div3").fadeToggle(3000);
});
```

#### jQuery fadeTo()
jQuery fadeTo() 方法允许渐变为给定的不透明度（值介于 0 与 1 之间）。
语法:`$(selector).fadeTo(speed,opacity,callback);`

 - 必需的 speed 参数规定效果的时长。它可以取以下值："slow"、"fast" 或毫秒。 
 - fadeTo() 方法中必需的opacity 参数将淡入淡出效果设置为给定的不透明度（值介于 0 与 1 之间）。 
 - 可选的 callback参数是该函数完成后所执行的函数名称。

下面的例子演示了带有不同参数的 fadeTo() 方法：
```
$("button").click(function(){
  $("#div1").fadeTo("slow",0.15);   //慢速褪色到15%的透明度
  $("#div2").fadeTo("fast",0.4);    //快速褪色到40%的透明度
```

### 滑动效果
#### jQuery slideDown() 
jQuery slideDown() 方法用于向下滑动元素。
语法:`$(selector).slideDown(speed,callback);`

 - 可选的 speed 参数规定效果的时长。它可以取以下值："slow"、"fast" 或毫秒。 
 - 可选的 callback参数是滑动完成后所执行的函数名称。

下面的例子演示了 slideDown() 方法：
```
$("#flip").click(function(){
  $("#panel").slideDown();   //点击<flip>标签之后，<panel>元素将会向下滑动显示
});
```

#### jQuery slideUp()
jQuery slideUp() 方法用于向上滑动元素。
语法:`$(selector).slideUp(speed,callback);`

 - 可选的 speed 参数规定效果的时长。它可以取以下值："slow"、"fast" 或毫秒。 
 - 可选的 callback参数是滑动完成后所执行的函数名称。

下面的例子演示了 slideUp() 方法：
```
$("#flip").click(function(){
  $("#panel").slideUp();     //点击<flip>标签之后，<panel>元素将会向上滑动隐藏
});
```

#### jQuery slideToggle()
jQuery slideToggle() 方法可以在 slideDown() 与 slideUp() 方法之间进行切换。

 - 如果元素向下滑动，则 slideToggle() 可向上滑动它们。 
 - 如果元素向上滑动，则 slideToggle() 可向下滑动它们。

语法:`$(selector).slideToggle(speed,callback);`

 - 可选的 speed 参数规定效果的时长。它可以取以下值："slow"、"fast" 或毫秒。 
 - 可选的 callback参数是滑动完成后所执行的函数名称。

下面的例子演示了 slideToggle() 方法：
```
$("#flip").click(function(){
  $("#panel").slideToggle();  //若panel已经展开，则上滑隐藏；若已隐藏，则下滑展开
});
```

### 动画
jQuery animate() 方法允许您创建自定义的动画。
> **默认情况下，所有 HTML 元素都有一个静态位置，且无法移动。
如需对位置进行操作，要记得首先把元素的 CSS position 属性设置为 relative、fixed 或 absolute！**

可以用 animate() 方法来操作所有 CSS 属性吗？
> 是的，几乎可以！不过，需要记住一件重要的事情：当使用 animate() 时，必须使用 Camel 标记法书写所有的属性名，比如，必须使用paddingLeft 而不是 padding-left，使用 marginRight 而不是 margin-right，等等。

#### jQuery animate()
jQuery animate() 方法用于创建自定义动画。
语法：`$(selector).animate({params},speed,callback);`

 - 必需的 params 参数定义形成动画的 CSS 属性。 
 - 可选的 speed
 - 参数规定效果的时长。它可以取以下值："slow"、"fast" 或毫秒。 
 - 可选的 callback 参数是动画完成后所执行的函数名称。

下面的例子演示 animate() 方法的简单应用。它把 <div> 元素往右边移动了 250 像素：
```
$("button").click(function(){
  $("div").animate({left:'250px'});   //将div向左移动250px
}); 
```

#### jQuery animate() - 操作多个属性
请注意，生成动画的过程中可同时使用多个属性：
```
$("button").click(function(){
  $("div").animate({   //写在{}中，属性直接用半角,隔开
    left:'250px',      //左移动250px
    opacity:'0.5',     //透明度改变为50%
    height:'150px',    //高度改变为150px
    width:'150px'      //宽度改变为150px
  });
}); 
```

#### jQuery animate() - 使用相对值
也可以定义相对值（该值相对于元素的当前值）。需要在值的前面加上 += 或 -=：
```
$("button").click(function(){
  $("div").animate({
    left:'250px',     //左移动250px
    height:'+=150px', //高度增加150px
    width:'+=150px'   //宽度增加150px
  });
}); 
```

#### jQuery animate() - 使用预定义的值
也可以把属性的动画值设置为 "show"、"hide" 或 "toggle"：
```
$("button").click(function(){
  $("div").animate({
    height:'toggle'   //点击button，给div的height一个隐藏动画效果
  });
}); 
```

#### jQuery animate() - 使用队列功能
默认地，jQuery 提供针对动画的队列功能。
这意味着如果您在彼此之后编写多个 animate() 调用，
jQuery 会创建包含这些方法调用的"内部"队列。然后逐一运行这些 animate 调用。
```
$("button").click(function(){
  var div=$("div");   //定义一个div 表示$("div") 对该元素有多个操作是的简便写法
  div.animate({height:'300px',opacity:'0.4'},"slow"); //首先执行，高度增加到300px，透明度40%
  div.animate({width:'300px',opacity:'0.8'},"slow");  //然后执行，宽度增加到300px，透明度80% 
  div.animate({height:'100px',opacity:'0.4'},"slow"); //继续执行，高度减少到100px，透明度40%
  div.animate({width:'100px',opacity:'0.8'},"slow");  //最后执行，宽度减少到100px，透明度80%
  //以从上到下的顺序执行动画队列
}); 
```

### 停止动画
jQuery stop() 方法用于停止动画或效果，在它们完成之前。
stop() 方法适用于所有 jQuery 效果函数，包括滑动、淡入淡出和自定义动画。
语法:`$(selector).stop(stopAll,goToEnd);`

 - 可选的 stopAll 参数规定是否应该清除动画队列。默认是false，即仅停止活动的动画，允许任何排入队列的动画向后执行。 
 - 可选的goToEnd 参数规定是否立即完成当前动画。默认是 false。

因此，默认地，stop() 会清除在被选元素上指定的当前动画。
```
$(document).ready(function(){
  $("#start").click(function(){
    $("div").animate({left:'100px'},5000);    //动画效果：div左移100px，
    $("div").animate({fontSize:'3em'},5000);  //内部文字的字体大小变为3em
  });
  
  $("#stop").click(function(){
    //无参数的暂停，一次点击，暂停一个animate动画，点击两次暂停两个动画
    $("div").stop();     
  });

  $("#stop2").click(function(){
    //stopAll参数为true，暂停所有animate动画
    $("div").stop(true);
  });

  $("#stop3").click(function(){
    //stopAll参数为true，goToEnd参数为true，暂停所有animate动画，并直接显示结果
    $("div").stop(true,true);
  });
  
});
```

### jQuery Callback 回调
**Callback 函数在当前动画 100% 完成之后执行。**
jQuery 动画的问题

> 许多 jQuery 函数涉及动画。这些函数也许会将 speed 或 duration 作为可选参数。
例子：`$("p").hide("slow")` speed 或 duration 参数可以设置许多不同的值，比如 "slow","fast", "normal" 或毫秒。

**以下实例在隐藏效果完全实现后回调函数:**
```
$("button").click(function(){
  $("p").hide("slow",function(){
    alert("The paragraph is now hidden");
  });
});
```
**没有回调函数（Callback）**
```
$("button").click(function(){
  $("p").hide(1000);
  alert("The paragraph is now hidden");   //警告框将在隐藏效果之前弹出
});
```

#jQuery - Chaining
通过 jQuery，可以把动作/方法链接在一起。
**Chaining 允许我们在一条语句中运行多个 jQuery 方法**（在相同的元素上）
### jQuery 方法链接
有一种名为链接（chaining）的技术，允许我们在相同的元素上运行多条 jQuery 命令，一条接着另一条。
提示： 这样的话，**浏览器就不必多次查找相同的元素**。
如需链接一个动作，您只需简单地把该动作追加到之前的动作上。
下面的例子把 css()、slideUp() 和 slideDown() 链接在一起。"p1" 元素首先会变为红色，然后向上滑动，再然后向下滑动：
```
$("#p1").css("color","red").slideUp(2000).slideDown(2000);
```
如果需要，我们也可以添加多个方法调用。
提示：

> 当进行链接时，代码行会变得很差。不过，jQuery语法很宽松；可以按照希望的格式来写，包含换行和缩进。

如下书写也可以很好地运行：
```
$("#p1").css("color","red")
  .slideUp(2000)
  .slideDown(2000);
```
jQuery 会抛掉多余的空格，并当成一行长代码来执行上面的代码行。

#jQuery 获取内容和属性
jQuery 拥有可操作 HTML 元素和属性的强大方法。
### jQuery DOM 操作
jQuery 中非常重要的部分，就是操作 DOM 的能力。
jQuery 提供一系列与 DOM 相关的方法，这使访问和操作元素和属性变得很容易。

> **DOM = Document Object Model（文档对象模型）**
DOM 定义访问 HTML 和 XML文档的标准：
"W3C文档对象模型独立于平台和语言的界面，允许程序和脚本动态访问和更新文档的内容、结构以及样式。"

#### 获得内容 - text()、html() 以及 val()
三个简单实用的用于 DOM 操作的 jQuery 方法：

 - text() - 设置或返回所选元素的文本内容
 - html() - 设置或返回所选元素的内容（包括 HTML 标记）
 - val() - 设置或返回表单字段的值

下面的例子演示如何通过 jQuery text() 和 html() 方法来获得内容：
```
$("#btn1").click(function(){
  alert("Text: " + $("#test").text());   //警告框弹出test内的文本内容
});
$("#btn2").click(function(){
  alert("HTML: " + $("#test").html());  //警告框弹出test内的html代码
});
```
下面的例子演示如何通过 jQuery val() 方法获得输入字段的值：
```
$("#btn1").click(function(){
  alert("值为: " + $("#test").val());   //警告框弹出test 标签输入的文本值
});
```
#### 获取属性 - attr()
jQuery attr() 方法用于获取属性值。
下面的例子演示如何获得链接中 href 属性的值：
```
$("button").click(function(){
  alert($("#derwer").attr("href"));  //警告框弹出 derwer 标签的 href 属性
});
```

#jQuery 设置内容和属性
### 设置内容 - text()、html() 以及 val()
我们将使用前一章中的三个相同的方法来设置内容：

 - text() - 设置或返回所选元素的文本内容
 - html() - 设置或返回所选元素的内容（包括 HTML 标记）
 - val() - 设置或返回表单字段的值

下面的例子演示如何通过 text()、html() 以及 val() 方法来设置内容：
```
$("#btn1").click(function(){ 
    $("#test1").text("Hello world!");   //设置text1的值为 "Hello world!"
}); 
$("#btn2").click(function(){ 
    $("#test2").html("<b>Hello world!</b>");   //设置text2的HTML代码为 "<b>Hello world!</b>"
}); 
$("#btn3").click(function(){ 
    $("#test3").val("DERWER");   //设置test的输入框内容为 DERWER
});
```


[1]: http://ofy85obwe.bkt.clouddn.com/jquery_cs_01.png
[2]: http://ofy85obwe.bkt.clouddn.com/jquery_cs_02.png
[3]: http://jquery.com/download/