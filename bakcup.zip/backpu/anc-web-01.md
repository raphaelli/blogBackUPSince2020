---
title: ANCWEB - 基于 ASP.NET CORE 2.0 的 WEB 开发
date: 2018-06-10 03:14:31
tags: 
 - dotNET
---

> ASP.NET Core 2 开发实战练习，基于 ASP.NET Core 2.0 + MSSQL + Angular 5 + Bootstrap 4 的 WEB 项目实例，项目内容开源于 [raphaelli/ANCWEB - Github](https://github.com/raphaelli/ANCWEB)  

# 项目说明

本项目参考 - [草根专栏 - 系列文章 ](http://www.cnblogs.com/cgzl/p/8478993.html) 教材，并以此为基础调整。



 ##  技术栈说明

参考技术文章，使用如下技术：

- ASP.NET Core 2.0  Web API
-  MSSQL
-  Angular 5
- Bootstrap 4



## 开发环境说明

使用VS Code 开发，插件列表：

![addin](anc-web-01\addin.png)

## 环境搭建

- .NET CORE 环境安装  [.NET Core 实战笔记1-介绍和安装](https://ns96.com/2017/11/21/dotNet-core-1/)
- Visual Studio Code 即 上述插件列表的插件安装
- SqlServer 2017 on linux  [SQL Server on Linux by Docker](https://ns96.com/2018/06/05/docker-compose-mssql/)
- angular cli  - npm 安装： `npm install -g @angular/cli`



# 创建项目

## 指令创建

VS code 中使用终端，并执行`dotnet new webapi` 指令创建 ASP.NET CORE WEB API 项目。

![newweb](anc-web-01\newweb.png)



## 运行项目

创建成功后会自动生成项目，执行 `dotnet run ` 试着运行下。

![run](anc-web-01\run.png)

**注意**： 这里的 `Hosting environment` 为 `Production`  即生产环境，我们可以切换到 `development`和`Staging`模式。

有几种办法可以更改这个环境变量的值:

1. 在执行`dotnet run`之前设置环境变量:

`mac: export ASPNETCORE_ENVIRONMENT=Development`

`windows: set ASPNETCORE_ENVIRONMENT="Development"`

2. windows下可以在控制面板--系统--高级设置里面设置环境变量的值 
3. 在项目的`appSettings.json`文件里面设置也可以:

使用visual studio 2017的话, 可以在项目的`launchSettings.json`设置.

使用`vscode`的话, 可以在项目目录的`launch.json`进行设置.



**注意**：在VS Code 中使用` lanch.json` 设置后，只有使用VS Code启动项目才能生效。

![dev](anc-web-01\dev.png)

## 安装 `.net watch tool` 

打开`.csproj`添加此行:

```
<ItemGroup>
    <DotNetCliToolReference Include="Microsoft.VisualStudio.Web.CodeGeneration.Tools" Version="2.0.2" />
    <DotNetCliToolReference Include="Microsoft.DotNet.Watcher.Tools" Version="2.0.0" />
  </ItemGroup>
```

然后执行命令:

```
dotnet restore
```

这样就使用下面的命令来代替dotnet run:

```
dotnet watch run
```

您可以随便修改一点代码, 然后就可以看到项目被重新编译并运行了。



# 配置ASP.NET Core 2.0  Web API

刚才已经创建好了 WEB API 的项目，接下来开始配置WEB API 。

分为下面四个步骤：

- 建立API
- 配置和使用Entity Framework Core 2.0
- 配置ASP.NET Core
- 使用`automapper`



## 添加模型（Models）

参考学习项目，建立模型如下：

 `Models/TvNetwork.cs`:

```cs
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Tv.Models
{
    public class TvNetwork
    {
        public TvNetwork()
        {
            TvShows = new Collection<TvShow>();
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<TvShow> TvShows { get; set; }
    }
}
```



`Models/TvShow.cs `:

```cs

namespace Tv.Models
{
    public class TvShow
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int TvNetworkId { get; set; }
        public TvNetwork TvNetwork { get; set; }
    }
}
```



VS Code 使用 C# 开发时，安装插件后实际效率非常高，使用 `prop` 和代码块功能能快速创建实体类和属性。



## 添加Entity Framework Core

使用指令直接添加：

````sh
dotnet add package Microsoft.EntityFrameworkCore.Design
dotnet restore
````

先添加NUGET包 ，还原，添加应用：

```cs
  <ItemGroup>
    <DotNetCliToolReference Include="Microsoft.VisualStudio.Web.CodeGeneration.Tools" Version="2.0.2" />
    <DotNetCliToolReference Include="Microsoft.DotNet.Watcher.Tools" Version="2.0.0" />
    <DotNetCliToolReference Include="Microsoft.EntityFrameworkCore.Tools.DotNet" Version="2.0.0" />
  </ItemGroup>
```

然后使用 EF。

```cs
dotnet ef
```



## **创建 `DbContext`**  上下文

创建一个文件夹叫做Database, 然后在里面建立一个文件`TvContext.cs`: 

```cs
using Microsoft.EntityFrameworkCore;

namespace Tv.Database
{
    public class TvContext : DbContext
    {
        public TvContext(DbContextOptions<TvContext> options):base(options)
        {
        }
    }
}
```



使用`Dbcontext`时需要依赖注入，因此需要在 `Startup.cs`的`ConfigureServices `中把`TvContext` 注册到容器：

```cs
 public void ConfigureServices(IServiceCollection services)
 {
     services.AddDbContext<TvContext>(opt => opt.UseSqlServer(""));
     services.AddMvc();
 }
```

**注意**：此处需要添加 `Database文件夹` 的引用和 `EntityFrameworkCore` 的引用。




在`appSettings.json`中添加 数据库连接字符串：

```json
"ConnectionStrings": {
    "Default": "server=localhost; database=tvdb; user id=sa; password=password;"
  },
```

**注意**:这里使用了实例字符串，按实际连接字符串修改。

回到`Startup.cs`, 可以使用这两种方式取得连接字符串: 

```cs
public void ConfigureServices(IServiceCollection services)
{
    // services.AddDbContext<TvContext>(opt => opt.UseSqlServer(Configuration["ConnectionStrings:Default"]));
    services.AddDbContext<TvContext>(opt => opt.UseSqlServer(Configuration.GetConnectionString("Default")));
    services.AddMvc();
}
```



## 创建数据库

为 `TvContext`添加 `DbSet`数据集：

```cs
using Microsoft.EntityFrameworkCore;
using Tv.Models;

namespace Tv.Database
{
    public class TvContext : DbContext
    {
        public TvContext(DbContextOptions<TvContext> options)
            : base(options)
        {

        }

        public DbSet<TvNetwork> TvNetworks { get; set; }
        public DbSet<TvShow> TvShows { get; set; }
    }
}
```



然后添加migrations:

```sh
dotnet ef migrations add Initi
```



最后执行生成数据库

```sh
dotnet ef database update
```

![sqlr](anc-web-01\sqlr.png)



数据库成功生成！