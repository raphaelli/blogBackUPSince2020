---
title: 把网站改成APP吧-Xamarin WebView
date: 2017-09-17 11:10:25
tags:
 - dotNET
---

>搭建好Xamarin环境，先来小试牛刀，使用Xamarin的webView来访问网页，从而实现伪WebApp的效果（网站本身移动设备兼容WebView调用）。主要是通过WebApp来访问页面，同时通过`重写页面加载方法`来防止调用系统浏览器来实现。

## 使用WebView构建基础框架
首先创建一个项目，并打开`Resources - layout -Main.axml`文件，从工具箱中添加一个WebView.

从左侧工具栏中找到WebView并拖到我们的界面中,并放大到覆盖整个页面,位置如图:

![添加WebView][1]

**注意**：在左下角的`Source`中查看源代码
```
<android.webkit.WebView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:id="@+id/webView1" />
```
其中`width="match_parent"`和`height="wrap_content"`默认自适应屏幕尺寸。

添加好WebView，编写根目录的`MainActivity.cs`文件，在`OneCreate()`方法中获取WebView进行基础设置。

```
//获取WebView对象
var webView = FindViewById<WebView>(Resource.Id.webView1);

//申明WebView的配置
WebSettings settings = webView.Settings;

//允许执行JS
settings.JavaScriptEnabled = true;

//设置可以通过js打开窗口
settings.JavaScriptCanOpenWindowsAutomatically = true;

//创建webView客户端类
var webc = new MyCommWebClient();

//设置WebVIew客户端
webView.SetWebViewClient(webc);

//加载的Url
webView.LoadUrl("https://ns96.com");
```

上述代码中的`MyCommWebClient()`方法的意义在于，阻止系统调用原生浏览器访问新页面，方法内容如下。
```
class MyCommWebClient : WebViewClient
{
    //重写加载方法
    public override bool ShouldOverrideUrlLoading(WebView view, string url)
    {
        //使用文本空间加载
        view.LoadUrl(url);
        return true;
    }
}
```

代码截图：
![代码截图][2]

调试运行后结果如下图

![demo][3]


## 部署，测试，发布

部署测试参考Xamarin官方文档 [部署、测试和指标](https://developer.xamarin.com/zh-cn/guides/android/deployment,_testing,_and_metrics/)

程序发布参考Xamarin官方文档 [发布应用程序](https://developer.xamarin.com/zh-cn/guides/android/deployment,_testing,_and_metrics/publishing_an_application/)

[1]: xamarin-webview/webview.png
[2]: xamarin-webview/code.png
[3]: xamarin-webview/demo.png