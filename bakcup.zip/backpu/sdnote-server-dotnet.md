---
title: Sdnote 服务器 基于.net core 重写
date: 2018-05-31 18:24:30
tags:
 - Other
---

> 前端时间，参加一个比赛，同时也是作为软件工程的课程设计，我们创建了 [Sdnote项目](https://github.com/Sdnote) - 一个便捷的笔记工具，其中，[服务端](https://github.com/Sdnote/Sdnote.Server)使用了基于 Java 的 jresey框架 ，[客户端](https://github.com/Sdnote/Sdnote.Mobile)暂使用了基于 MUI 的移动端开发框架。**目前计划：使用.net 重写服务端，并优化部分设计之初遗留的缺陷，客户端方面，使用 WEB/PWA和移动端混合开发**



# 服务端

