---
title: Layui表格分页数据异常
date: 2018-12-25 11:06:31
tags: 
 - WorkNote
---

# Layui表格分页数据异常

>在处理Layui的表格分页时遇到了，在切换搜索条件和列表后，分页数据page参数被保留，从而导致加载出来的表单数据结果异常的情况，其实解决起来非常简单

在 Option 中加入 
```js
 , page: {
    curr: 1 //重新从第 1 页开始
}
```
参考官方实例 ：
```js
//这里以搜索为例
tableIns.reload({
  where: { //设定异步数据接口的额外参数，任意设
    aaaaaa: 'xxx'
    ,bbb: 'yyy'
    //…
  }
  ,page: {
    curr: 1 //重新从第 1 页开始
  }
});
```

感觉Layui 的文档比较混乱，要查询相关的接口和示例都比较麻烦。