---
title: ubuntu 搭建 SS 服务端
date: 2018-12-05 15:21:04
tags:
 - Linux
---
> 十一月中回到原来公司实习，算起来也有半个多月了，但是公司的网络一直忽快忽慢，很多网站根本都打不开，灵机一动想着在服务器上挂个SS，需要打开某些网站的时候直接通过SS来访问，实测效果不错。

# 素质三连
```sh
$ sudo apt-get update
$ sudo apt-get install python3-pip
$ pip3 install https://github.com/shadowsocks/shadowsocks/archive/master.zip
```

更新apt 源，shadowsocks 托管与 pip ，安装pip，  pip 安装 shadowsocks 。

查看 Shadowsocks 是否安装完成
```sh
$ sudo ssserver --version
```
# 运行 shadowsocks 服务器
ss 安装了就能直接运行，也可以以配置参数运行，当然也可以安装在docker 中。

## 直接运行
```sh
$ sudo ssserver -p 8388 -k password -m rc4-md5 -d start
```

就这么简单

打开客户端，输入ip 端口 密码 ，大功告成

等等！ 怎么关？
```sh
$ sudo ssserver 8388 -k password -m aes-256-cfb -d stop
```

## 配置文件
创建配置文件

```sh
$ sudo mkdir /etc/shadowsocks
$ sudo vim /etc/shadowsocks/config.json
```

写入配置
```sh
{
    "server":"::",
    "server_port":8388,
    "local_address": "127.0.0.1",
    "local_port":1080,
    "password":"mypassword",
    "timeout":300,
    "method":"aes-256-cfb",
    "fast_open": false
}
```

多用户：
```sh
{
    "server":"my_server_ip",
    "port_password": {
        "端口1": "密码1",
        "端口2": "密码2"
    },
    "timeout":300,
    "method":"rc4-md5",
    "fast_open": false
}
```

### 注意事项
**权限**： 
```sh
$ sudo chmod 755 /etc/shadowsocks.json
```

没啥好说的。

**加密方式：**
```sh
$ sudo apt–get install python–m2crypto
```

以配置文件方式后台运行：
```sh
sudo ssserver -c /etc/shadowsocks.json -d start
```

## 配置Systemd管理Shadowsocks
新建Shadowsocks管理文件

```bash
$ sudo vim /etc/systemd/system/shadowsocks-server.service
```
复制粘贴：
```sh
[Unit]
Description=Shadowsocks Server
After=network.target

[Service]
ExecStart=/usr/local/bin/ssserver -c /etc/shadowsocks/config.json
Restart=on-abort

[Install]
WantedBy=multi-user.target
```

启动Shadowsocks：

```Bash
$ sudo systemctl start shadowsocks-server
```
设置开机启动Shadowsocks：

```Bash
sudo systemctl enable shadowsocks-server
```

到此重启服务器后，会自动启动。

# 其他 
## 开启BBR对服务器端进行优化。

参考 - [使用谷歌 BBR TCP 拥塞控制算法为服务器加速](https://ns96.com/2018/07/11/tcp-bbr/)

## 其他

参考- [Ubuntu 16.04下Shadowsocks服务器端安装及优化](https://www.polarxiong.com/archives/Ubuntu-16-04%E4%B8%8BShadowsocks%E6%9C%8D%E5%8A%A1%E5%99%A8%E7%AB%AF%E5%AE%89%E8%A3%85%E5%8F%8A%E4%BC%98%E5%8C%96.html)