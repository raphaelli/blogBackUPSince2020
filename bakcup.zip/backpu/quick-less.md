---
title: Less快速入门
date: 2016-11-07 08:38:53
tags:
 - Font-end
---
# Less快速入门
> Web前端学习笔记之——Less快速入门

---
# 什么是Less 
Less 是一门 CSS 预处理语言，它扩充了 CSS 语言，增加了诸如变量、混合（mixin）、函数等功能，让 CSS 更易维护、方便制作主题、扩充。

Less 可以运行在 Node、浏览器和 Rhino 平台上。网上有很多第三方工具帮助你编译 Less 源码。

实例:
```
@base: #f938ab;

.box-shadow(@style, @c) when (iscolor(@c)) {
  -webkit-box-shadow: @style @c;
  box-shadow:         @style @c;
}
.box-shadow(@style, @alpha: 50%) when (isnumber(@alpha)) {
  .box-shadow(@style, rgba(0, 0, 0, @alpha));
}
.box {
  color: saturate(@base, 5%);
  border-color: lighten(@base, 30%);
  div { .box-shadow(0 0 5px, 30%) }
}
```

编译之后的结果
```
.box {
  color: #fe33ac;
  border-color: #fdcdea;
}
.box div {
  -webkit-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
}
```

# 使用 Less
Less 可以通过 npm 在命令行上运行；在浏览器上作为脚本文件下载；或者集成在广大的第三方工具内。

### 安装
在服务器端最容易的安装方式就是通过 npm （node.js 的包管理器），方法如下：
```
$ npm install -g less
```
#### 命令行用法：
安装 Less 后，就可以在命令行上调用 Less 编译器了，如下：
```
$ lessc styles.less
```
这将输出编译之后的 CSS 代码到 stdout，你可以将输出重定向到一个文件：
```
$ lessc styles.less > styles.css
```
若要输出压缩过的 CSS，只需添加 -x 选项。如果希望获得更好的压缩效果，还可以通过 --clean-css 选项启用 Clean CSS 进行压缩。

执行 lessc 且不带任何参数，就会在命令行上输出所有可用选项的列表。

#### 代码中使用
可以像下面这样在代码中调用 Less 编译器（Node 平台）。
```
var less = require('less');

less.render('.class { width: (1 + 1) }', function (e, css) {
  console.log(css);
});
```

**输出结果为：**
```
.class {
  width: 2;
}
```
你还可以手动调用分析器（paser）和编译器：
```
var parser = new(less.Parser);

parser.parse('.class { width: (1 + 1) }', function (err, tree) {
  if (err) {
    return console.error(err)
  }
  console.log(tree.toCSS());
});
```

### 配置
可以给编译器传递多个参数：
```
var parser = new(less.Parser)({
  paths: ['.', './lib'], // Specify search paths for @import directives
  filename: 'style.less' // Specify a filename, for better error messages
});

parser.parse('.class { width: (1 + 1) }', function (e, tree) {
  tree.toCSS({
    // Minify CSS output
    compress: true
  });
});
```