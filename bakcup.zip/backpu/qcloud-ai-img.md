---
title: 腾讯云人脸检索引入教程
date: 2018-04-08 20:57:32
tags:
 - Other
---

# 人脸检索

先说下什么是人脸检索：

> 本接口用于对一张待识别的人脸图片，在一个 group 中识别出最相似的 Top5 person 作为其身份返回，返回的 Top5 中按照相似度从大到小排列。

Qcloud 官方文档中是这样定义人脸检索的 API 的概述的。

用大白话来说，就是从一张合影中，匹配出与默认添加个体最相似的一个个体（API会给出最高的五个，从匹配度由高到低排列）。



那么接下来看看如何操作：

## 创建鉴权签名

Qcloud 的付费接口，在调用的时候大多都需要进行鉴权签名的认证，而鉴权签名这需要使用用的 APPID 、Bucket、Secret ID 和 Secret Key。

> **另外：** 
> （1）如果您使用的是 125 开头的 APPID，请使用 [API 密钥](https://console.cloud.tencent.com/capi) ；
> （2）如果您使用的是 100、101 等开头的 项目 ID，请使用 [项目密钥](https://console.cloud.tencent.com/capi/project)。

点击上述链接，进入新建或查看秘钥：

![API秘钥](qcloud-ai-img/api.png)



保存如图所示的三个值，而 Bucket 存储桶，则可以前往[COS云对象存储](https://console.qcloud.com/cos/bucket) 创建并获取其 Bucket 的名称：

![bucket](qcloud-ai-img/bucket.png)



> 现在，我们拥有了创建鉴权签名所需的四个参数，选择合适的环境创建即可：

[鉴权签名](https://cloud.tencent.com/document/product/641/12409#java.E7.AD.BE.E5.90.8D.E7.94.9F.E6.88.90.E7.A4.BA.E4.BE.8B)的官方示例提供了两种方法来完成鉴权签名的生成，分别依托 PHP 和 JAVA 环境，

这里我们使用已有的 PHP 环境来执行，将官方提供的鉴权签名生成代码添加到一个 PHP 页面中，并上传到 PHP 环境下执行：

```Php
<?php
$appid = "1252821871";
$bucket = "tencentyun";
$secret_id = "AKIDgaoOYh2kOmJfWVdH4lpfxScG2zPLPGoK";
$secret_key = "nwOKDouy5JctNOlnere4gkVoOUz5EYAb";
$expired = time() + 2592000;
$onceExpired = 0;
$current = time();
$rdm = rand();
$userid = "0";
$fileid = "tencentyunSignTest";
$srcStr = 'a='.$appid.'&b='.$bucket.'&k='.$secret_id.'&e='.$expired.'&t='.$current.'&r='.$rdm.'&u='
.$userid.'&f=';
$srcWithFile = 'a='.$appid.'&b='.$bucket.'&k='.$secret_id.'&e='.$expired.'&t='.$current.'&r='.$rdm.'&u='
.$userid.'&f='.$fileid;
$srcStrOnce= 'a='.$appid.'&b='.$bucket.'&k='.$secret_id.'&e='.$onceExpired .'&t='.$current.'&r='.$rdm
.'&u='.$userid.'&f='.$fileid;
$signStr = base64_encode(hash_hmac('SHA1', $srcStr, $secret_key, true).$srcStr);
$srcWithFile = base64_encode(hash_hmac('SHA1', $srcWithFile , $secret_key, true).$srcWithFile );
$signStrOnce = base64_encode(hash_hmac('SHA1',$srcStrOnce,$secret_key, true).$srcStrOnce);
echo "多次有效签名(不绑定资源) " + $signStr."\n"; 
echo "多次有效签名(绑定资源) " + $srcWithFile ."\n";
echo "单次有效签名 " + $signStrOnce."\n";
?>
```

> **注意**:将上述php 页面代码的前四项修改为刚才获取到的对应内容！

然后访问当前 php 页面，即可获得鉴权签名的内容！

![authe](qcloud-ai-img/authe.png)

**注意**: 鉴权签名是执行请求并计费的秘钥，在使用过程中注意保密，若泄露易导致他人盗用，产生不必要的额外开支。

完成鉴权签名后，就可以开始使用人脸检索的 API 了。

## 创建个体

在让人脸检索服务能为我们检索到信息之前，我们先需要上传个体。

> 这里使用 Postman 作为请求处理工具，选择一个我比较喜欢的演员[高司令(Ryan Gosling](https://www.interview.de/wp-content/uploads/2015/04/ryangosling.jpg)作为个体，然后在使用人脸检索服务，在合影中找出他。



请求头：

| 参数名         | 值                                      | 描述                                                         |
| -------------- | --------------------------------------- | ------------------------------------------------------------ |
| host           | recognition.image.myqcloud.com          | 腾讯云人脸识别服务器域名                                     |
| content-length | 包体总长度                              | 整个请求包体内容的总长度，单位：字节（Byte）                 |
| content-type   | application/json 或 multipart/form-data | 据不同接口选择：1. 使用 application/json 格式，参数为 url，其值为图片的 url ；2. 使用 multipart/form-data 格式，参数为 image，其值为图片的 base64 。 |
| authorization  | 鉴权签名                                | 多次有效签名，用于鉴权，生成方式见 [鉴权签名方法](https://cloud.tencent.com/document/product/641/12409) |



**请求参数**

使用 application/json 格式，参数选择 url ；使用 multipart/form-data 格式，参数选择 image。

| 参数名      | 必选 | 类型          | 参数说明                                                     |
| ----------- | ---- | ------------- | ------------------------------------------------------------ |
| appid       | 是   | string        | 接入项目的唯一标识，可在 [账号信息](https://console.cloud.tencent.com/developer) 或 [云 API 密钥](https://console.cloud.tencent.com/cam/capi) 中查看。 |
| group_ids   | 是   | array(string) | 加入到组的列表                                               |
| person_id   | 是   | string        | 指定的个体 id                                                |
| image       | 否   | binary        | 图片内容                                                     |
| url         | 否   | string        | 图片的 url、image提供一个即可；如果都提供，只使用url         |
| person_name | 否   | string        | 名字                                                         |
| tag         | 否   | string        | 备注信息                                                     |

按照上表，填写请求：

头部信息如下：

![header](qcloud-ai-img/header.png)



参数部分如下：

> 这里选择如图的所示的 raw 然后使用 json 模式编写，更加直观方便！

![body](qcloud-ai-img/body.png)



> **注意**:图中所有参数请按自己需要请求的内容替换，如 appid 替换为自己的 appid，group 和 person 的 id 都由用户自行划分定义，person_name  为选填参数。



按要求填写完毕后，点击 sent，查看返回值：

![result](qcloud-ai-img/result.png)



返回值如上所示，则表示个体创建成功！

# 人脸校验

先看下参数：

### 请求参数

使用 application/json 格式，参数选择 url ；使用 multipart/form-data 格式，参数选择 image。

| 参数名    | 必选 | 类型          | 参数说明                                                     |
| --------- | ---- | ------------- | ------------------------------------------------------------ |
| appid     | 是   | string        | 接入项目的唯一标识，可在 [账号信息](https://console.cloud.tencent.com/developer) 或 [云 API 密钥](https://console.cloud.tencent.com/cam/capi) 中查看。 |
| group_id  | 否   | string        | 候选人组 id，与group_ids二选一即可                           |
| group_ids | 否   | array(string) | 候选人组 id列表，与group_id二选一即可                        |
| image     | 否   | binary        | 图片内容                                                     |
| url       | 否   | string        | image 和 url 只需提供一个；如果都提供，只使用 url            |

### 返回内容

| 字段            | 类型                | 说明                                      |
| --------------- | ------------------- | ----------------------------------------- |
| data.session_id | string              | 相应请求的 session 标识符，可用于结果查询 |
| data.candidates | array(IdentifyItem) | 识别出的 top5 候选人                      |
| code            | int                 | 返回状态码                                |
| message         | string              | 返回错误消息                              |





人脸校验请求的请求头和创建个体的一样，直接按照上文添加，请求参数如下图所示：

![identity](qcloud-ai-img/identity.png)

点击 sent 

从返回值中可以看出，人脸检索已经成功从合影中检索出了高司令！确认度64！



---



提供下检索用的两张图片：

![ryangosling](qcloud-ai-img/ryangosling.jpg)

![groupphoto](qcloud-ai-img/groupphoto.jpg)



> 声明：图片均来自互联网，不确认版权，若侵权请通知删除！

# 参考：

- [鉴权签名官方文档](https://cloud.tencent.com/document/product/641/12409#java.E7.AD.BE.E5.90.8D.E7.94.9F.E6.88.90.E7.A4.BA.E4.BE.8B)
- [人脸检索官方文档地址](https://cloud.tencent.com/document/product/641/12419)
- [个体信息管理方文档地址](https://cloud.tencent.com/document/product/641/12417#.E4.B8.AA.E4.BD.93.E5.88.9B.E5.BB.BA)

  ​