---
title: Oracle 描述乱码
date: 2018-11-23 16:57:27
tags:
 - WorkNote
---

>Oracle 在查看数据库表描述时乱码，错误提示也乱码，主要是因为本地没有配置与数据库服务器相同的语言设置。

# 查询
先通过查询数据库的语言参数获取当前数据库的语言配置。
```sql
select * from v$nls_parameters
```

# 参数
找到其中 `NLS_LANGUAGE` 的参数，例如：`SIMPLIFIED CHINESE`.

# 配置
在系统环境变量中添加
`NLS_LANGUAGE` 参数为 `SIMPLIFIED CHINESE`。

再次登陆查看描述，就恢复正常了。