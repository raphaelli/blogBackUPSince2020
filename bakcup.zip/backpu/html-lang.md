---
title: HTML页面中的lang属性
date: 2017-09-28 20:36:56
tags:
 - Font-end
---

>最近想做点小项目，好久没写前端了，打开VScode，输了个HTML，突然忘记了中文的lang标识是什么了，只是隐约记得是`zh`，然而科普之后才知道，14年学习的`zh`写法，早在09年就被废弃了。

## 先说下规范
lang属性的取值应该遵循 [CP 47 - Tags for Identifying Languages](https://tools.ietf.org/html/bcp47)

而标识的内容应该依照如下写法：
```
language-extlang-script-region-variant-extension-privateuse
语言文字种类-扩展语言文字种类-书写格式-国家和地区-变体-扩展-私有
```

## 因此推荐使用如下规范：
1. 简体中文页面：html lang=zh-cmn-Hans
2. 繁体中文页面：html lang=zh-cmn-Hant
3. 英语页面：html lang=en

同时考虑浏览器兼容，也可以使用下列规范，前者兼容，后者标准
1. zh-CN 中文 (简体, 中国大陆) 对应 cmn-Hans-CN 普通话 (简体, 中国大陆)
2. zh-SG 中文 (简体, 新加坡)   对应 cmn-Hans-SG 普通话 (简体, 新加坡)
3. zh-HK 中文 (繁体, 香港)     对应 cmn-Hant-HK 普通话 (繁体, 香港)

**注意**：zh 开头写法已于 2009 年废弃，不推荐使用，直接去掉 zh- 前缀并使用 cmn
