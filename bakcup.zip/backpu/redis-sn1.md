---
title: Redis 学习笔记 安装/启动/测试/配置
date: 2019-01-27 22:26:55
tags:
 - Redis
---

# Docker 安装 Redis
docker 安装服务当然是非常简单方便的。

获取容器镜像
```sh
$ docker pull redis
```

启动第一个容器
```sh
$ docker run --name test-redis -p 6379:6379 -d redis
```

附加方式运行 redis-cli
```sh
$ docker exec -it test-redis redis-cli
```

测试一个键值对 (exec 进入容器后)
```
$ set name nick  #设置 key-value
$ get name #获取键值 返回 "nick"
```

# 准备 .Net Core 项目用于测试
新建一个 .Net Core 的控制台程序，并添加 Redis 客户端。

Redis 客户端有很多，C# 的就有很多可供选择，可以参考 https://redis.io/clients#c

这里使用的是 StackExchange.Redis (https://stackexchange.github.io/StackExchange.Redis/)。


Nuget 或 使用包管理控制台指令：
```sh
dotnet add package StackExchange.Redis
```

## 最简单的读取测试
`main.cs` 中引用 `StackExchange.Redis` ,建立连接，获取值
```cs
using System;
using StackExchange.Redis;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //建立连接
            ConnectionMultiplexer redis = ConnectionMultiplexer.Connect("leepush.com");

            //访问 Redis 数据库
            IDatabase db = redis.GetDatabase();
            var name = db.StringGet("name");  //通过Key 获取值

            Console.WriteLine("Hello World! " + $"{name}");
        }
    }
}

```

调试运行，就会输出 "Hello World! nick"

## 写入点啥
读取是 `String.Get`,不用举一反三，写入自然是 `Sting.Set`

```cs
//建立连接
ConnectionMultiplexer redis = ConnectionMultiplexer.Connect("leepush.com");

//访问 Redis 数据库
IDatabase db = redis.GetDatabase();
db.StringSet("age", 18);

var name = db.StringGet("name");
var age = db.StringGet("age");


Console.WriteLine($"{name} is {age} years old.");
```

运行结果 ： "nick is 18 years old."

# Redis 的数据类型
上面的读写操作都是使用的 String 数据类型，Redis 一共有如下几种数据类型：
- Key：就是键的意思
- String：字符串
- List：有序字符串的集合
- Hashes：有点像对象，里面可以有若干个字段，字段都有自己的值，字段和值都是字符串类型的。
- Set：无序唯一字符串的集合
- Sorted-Set：跟Set很像，但是每一个字符串元素都对应一个浮点数值，该数值叫做分数。它里面的元素通常是按照分数来排序的。

- 参考 http://www.runoob.com/redis/redis-keys.html 中每个数据类型的介绍及命令

# Redis 持久化
一共有两种方式：

- AOF（Append-only file）
- RDB（Redis database file）
首先需要知道Redis的操作都是在内存中完成的，因为这样速度快。

## AOF
说重点：
1. 每个操作都记录到文件系统
2. Redis服务器重启，自动重建，故文件逐渐变大
3. Redis自动使用最新版本的数据，并压缩文件

## RDB
同样说重点：
1. Redis 默认模式，类似数据库快照
2. 时间点记录写入 RDB ，时间点恢复

最佳实践是两者都用，使用AOF因为其速度和可用性，使用RDB做灾难恢复。

# Redis 配置
Redis 标准配置文件 https://raw.githubusercontent.com/antirez/redis/4.0/redis.conf

看关键部分：
## Redis 快照相关 
检索关键词 - SNAPSHOTTING

```sh
################################ SNAPSHOTTING  ################################
#
# Save the DB on disk:
#
#   save <seconds> <changes>
#
#   Will save the DB if both the given number of seconds and the given
#   number of write operations against the DB occurred.
#
#   In the example below the behaviour will be to save:
#   after 900 sec (15 min) if at least 1 key changed
#   after 300 sec (5 min) if at least 10 keys changed
#   after 60 sec if at least 10000 keys changed
#
#   Note: you can disable saving completely by commenting out all "save" lines.
#
#   It is also possible to remove all the previously configured save
#   points by adding a save directive with a single empty string argument
#   like in the following example:
#
#   save ""

save 900 1
save 300 10
save 60 10000
```

里面的save 900 1.

这部分是指，900秒过后，如果至少1个key改变了，那么就做一个快照。

下面的就是300秒过后，如果10个key改变了，那就做一个快照。。。

这些就是进行快照动作的触发条件。

## AOF相关 
检索关键词 - APPEND ONLY MODE 

```sh
############################## APPEND ONLY MODE ###############################

# By default Redis asynchronously dumps the dataset on disk. This mode is
# good enough in many applications, but an issue with the Redis process or
# a power outage may result into a few minutes of writes lost (depending on
# the configured save points).
#
# The Append Only File is an alternative persistence mode that provides
# much better durability. For instance using the default data fsync policy
# (see later in the config file) Redis can lose just one second of writes in a
# dramatic event like a server power outage, or a single write if something
# wrong with the Redis process itself happens, but the operating system is
# still running correctly.
#
# AOF and RDB persistence can be enabled at the same time without problems.
# If the AOF is enabled on startup Redis will load the AOF, that is the file
# with the better durability guarantees.
#
# Please check http://redis.io/topics/persistence for more information.

appendonly no

```

AOF模式默认是不开启的，也就是no。如果想开启，那就改成yes即可。

# Docker 使用自定义配置启动容器
下载前文提到的默认配置文件，按需修改内容。

比如： 修改 快照RDB 条件 开启 AOF 
>使用 curl 快速下载 `curl -o redis.conf https://raw.githubusercontent.com/antirez/redis/4.0/redis.conf` 然后使用 vim 编辑（/appendonly 查找） 

然后使用 Docker 的指定 Volume 启动 redis 容器

>docker 删除容器 先stop 容器，然后使用 rm 删除容器

使用如下指令来创建一个自定义的 Redis 服务容器
```sh
 docker run -v /home/ubuntu/redis/redis.conf:/usr/local/etc/redis/redis.conf --name custom-redis -p 6379:6379 redis redis-server /usr/local/etc/redis/redis.conf
```

>说明： -v这部分是指volume，redis.conf在我服务器里的位置是：`/home/ubuntu/redis/redis.conf`，所以我把该位文件的位置挂载到了容器里的`/usr/local/etc/redis/redis.conf`这个地方。然后运行redis这个镜像，同时运行里面的redis-server，而redis-server的配置文件就是/usr/local/etc/redis/redis.conf。

运行成功后，重开一个终端连入服务器，使用 docker ps 查看容器id 

```sh
$ docker exec -it ebd8 redis  # 这里的 ebd8 就是我的容器id前四位
```

此时前面配置的条件如果触发，监控终端就会输出提示。