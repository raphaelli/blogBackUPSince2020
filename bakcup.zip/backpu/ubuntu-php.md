---
title: "Ubuntu下安装Nginx+PHP+MySql环境"
date: 2017-1-31 10:29
tags:
 - Linux
---
## 写在之前：
之前腾讯云线下推广的时候给同学们讲过一趟基于ubuntu系统安装WordPress搭建自己的个人博客的课程。最近刚好有个朋友想要学习下ubuntu系统，然后我就把一个闲置的云服务器给她玩，顺手发个她上次讲课时候的教程（[教程地址](https://www.zybuluo.com/raphael96/note/550004)）然而呢，忘记一个问题，我们当时教学用的服务器是14.2的版本，而我给她重装的是，16.04的LST版本。原本的php5也因为apt源的问题无法安装，于是自己度娘加一顿操作，在ubuntu下安装了php7+mysql5.7，顺带把过程记录下来，方便以后查阅。

---

## Step1：提权
首先，当然是  所有的操作当然要在root权限下进行喽  
`#sudo su`
![SU提权](ubuntu-php/su.png)

---

## Step2：更新apt源
然后咧，更新apt源，都不想用旧版的软件嘛  
`#apt-get update`
![apt update](ubuntu-php/update.png)

---

## Step3：安装mysql
柿子挑软的捏，先装mysql5.7  
`#apt-get -y install mysql-server mysql-client`  
安装没有什么需要特别注意的，中途会询问两次root用户的密码，输入就好了
![安装Sql](ubuntu-php/inssql.png)  

然后在网上查阅资料，发现为了确保数据库的安全，最好是删除匿名用户和测试数据库  
`#mysql_secure_installation`
![Sql安全](ubuntu-php/anquan.png)

输入密码啦，刚刚才设置的，不会忘记了吧!  
然后回车，会依次询问你，是否验证密码，设置密码难度等级，是否重置密码，移出匿名用户，是否关闭远程登录，是否删除测试数据库，是否重新加载权重表。  
根据自己的情况进行选择，最后出现all done！就OK了!  

---

## Step4：安装Nginx
接下来就是安装Nginx喽，Nginx的安装很简单啦，重点在于Nginx的配置这块，这个先不讲，等下安装完PHP之后，一起配置.  
当然如果已经安装了Apache2的话，那必须要先删除掉Apache2再安装Nginx，不然会端口冲突的啦，你想想，就那几个门，你走了，别人怎么走。  
```
#service apache2 stop
#update-rc.d -f apache2 remove
#apt-get remove apache2
```
当然我没有安装Apache2，我是刚刚重装的服务器，上面的代码也是在网上查到的，不知道有没有用（逃  

`#apt-get -y install nginx   `  

Apt源安装Nginx，然后启动  
`#service nginx start`  
这个时候浏览器输入下IP地址，看看Nginx安装好没。
![Nginx](ubuntu-php/nginx.png)

---

## Step5：安装PHP7
这时候要安装PHP啦，但是我们选着安装php7-fpm，那么你要是想问我，什么fpm，为什么不是PHP7呢？这就是因为FPM作为FastCGI进程管理器可以提升性能啦？那FastCGI是什么？好了好了，[FastCGI](https://segmentfault.com/q/1010000000256516)，链接在这里，自己看。  
`#apt-get -y install php7.0-fpm `  
这个安装应该是没有什么问题的啦。
下面就是配置喽!

---

## Step6：配置 Nginx
首先（可以不做修改）调整keepalive_timeout到一个合理的值：  
打开配置文件 `/etc/nginx/nginx.conf`  

`#vim /etc/nginx/nginx.conf`
```
    keepalive_timeout 2;
```
噢噢，对了，顺带一提，vim的退出是 :wq 哦.

然后，修改虚拟主机服务器的容器定义，位于`/etc/nginx/sites-available/default`  

`#vim /etc/nginx/sites-available/default`  
把需要修改的地方发上来，修改的方法嘛，把前面的#注释标志删掉就好了
![配置修改](ubuntu-php/phpconf.png)

还好吧，是不是很简单！顺带说一下：
- `server_name _; `默认捕捉所有虚拟主机
- 根目录 `/var/www/html;`意味着文档根目录位于`/var/www/html.`
- PHP的重要组成部分位置 `~ \.php$ {} stanza. `取消注释它来启用它。

现在保存文件并重新加载nginx：  
`# service nginx reload`

然后是php的php.ini配置，就写在一起喽！  
`#vim /etc/php/7.0/fpm/php.ini`  
设置 `cgi.fix_pathinfo=0: `   
输入 `/cgi.fix_pathinfo `查询，找到后将值1改为0 
![PHP.ini](ubuntu-php/phpini.png)

当然也要去除前面的`；`注释！！！  
重新加载 PHP-FPM:  
`# service php7.0-fpm reload`  
怎么看PHP是不是跑起来了？HelloWorld？肯定不行，探针走起！  
`# vim /var/www/html/info.php`
```
<?php
phpinfo();
?>
```
然后访问`ip/info.php`  
![PHP探针](ubuntu-php/phpinfo.png)

---

## Step7：让 MySQL 获得 PHP 7支持
MySql和PHP的在一起才能跑程序啊，好，下面来撮合他们。  
先搜索一下PHP支持的模块：  
`#apt-cache search php7.0`  
使用下面的命令安装：  
`apt-get -y install php7.0-mysql php7.0-curl php7.0-gd php7.0-intl php-pear php-imagick php7.0-imap php7.0-mcrypt php-memcache  php7.0-pspell php7.0-recode php7.0-sqlite3 php7.0-tidy php7.0-xmlrpc php7.0-xsl php7.0-mbstring php-gettext`  
**上述安装指令源自搜索引擎查询的结果，具体各个模块对应的功能我并未全部了解，有兴趣可以自行搜索。这一步安装的时间稍长，请耐心等待。**  

APCu是随PHP7 PHP Opcache模块的扩展，它增加了一些兼容性功能的支持APC缓存（例如WordPress的插件缓存）软件。  
APCu可以安装如下：  
`#apt-get -y install php-apcu`  
重新加载 PHP-FPM:
`#service php7.0-fpm reload`  

刷新  `ip/info.php ` 浏览器看看模块安装情况：
![PHP探针](ubuntu-php/phpinfo2.png)

---

## Step8让 PHP-FPM 使用 TCP 连接
默认情况下PHP-FPM监听 `/var/run/php/php7.0-fpm.sock`. 另外，也可以使 PHP-FPM 使用 TCP 连接，打开文件 `/etc/php/7.0/fpm/pool.d/www.conf…`

`#vim /etc/php/7.0/fpm/pool.d/www.conf`  

修改如下：
![www.conf](ubuntu-php/wwwconf.png)
--用 `/listen = `查询然后将原有行注释，新增一行。  
这将使PHP-FPM端口`9000`侦听的IP`127.0.0.1`（本地主机）。请确保您使用的端口，是不是在你的系统上使用。  
将Nginx的监听也改成TCP的，不然大家监听的端口都不一样，就不在一个频道了，怎么交流呢？
![Nginx配置](ubuntu-php/nginxconf.png)
最后，重新加载nginx：  

`#service nginx reload`

OK，Nginx下的PHP7+MySql5.6安装完成！

---

## 测试环境
不能我说装完了就装完了，不还得测试下嘛，来，phpMyAdmin走起！  
### 下载phpMyAdmin
`#weget https://files.phpmyadmin.net/phpMyAdmin/4.6.5.2/phpMyAdmin-4.6.5.2-all-languages.tar.gz`  
### 解压到目录
`#tar -xzf phpMyAdmin-4.6.5.2-all-languages.tar.gz -C /var/www`  
### 目录改名
`# mv phpMyAdmin-4.6.5.2-all-languages phpMyadmin`  
### 赋给权限
`#chown -R www-data:www-data /var/www/phpMyadmin`
### 修改Nginx默认站点路径配置
`#vim /etc/nginx/sites-available/default` 


这里我们把站点的根目录设置为  `/var/www`

但凡改设置都是需要重启服务哒！ 

`#service nginx reload`  

这个时候输入ip/phpMyadmin 就可以访问phpMyadmin了！
![phpMyAdmin](ubuntu-php/phpmyadmin.png)


