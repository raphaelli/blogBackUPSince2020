---
title: "nginx下php环境在ubuntu重启后出现502错误"
date: 2017-1-29 11:35
tags:
 - Linux
---

>为了将原本运行在Windows Server 2016 中IIS上的PHP环境（WordPress程序加MySql）迁移到Ubuntu Server下的Nginx上。我考虑先将程序和MySql导入到本地的Ubuntu虚拟机中进行测试，然后重装服务器进行迁移。但是在环境的配置是，发现了一个问题，就是在Ubuntu重启后，本地站点打开php站点phpMyAdmin会出现502错误，通过多次尝试，发现主要可能是一下几个问题，也算是列举下nginx 502错误的解决方法。

---

## Q1:php.ini的memory_limit
用编辑器打开php.ini 将memory_limit修改为更高值  

`#vim /etc/php/7.0/fpm/php.ini`
![Q1](nginx-502/q1.png)
重新加载 PHP-FPM:  
`# service php7.0-fpm reload`

---

## Q2：listen监听设置

`# vim /etc/php5/fpm/pool.d/www.conf`

搜索以下行，并取消注释 `;  `  
`listen.backlog = 65536`  
搜索以下行  
`listen = /var/run/php5-fpm.sock`  
并替换成如下：  
`listen = 127.0.0.1:9000`
![Q2](nginx-502/q2.png)

---

## Q3：listen监听TCP配置出错
php的监听修改为tcp，而nginx的仍然为 sock  
`# vim /etc/nginx/sites-available/default`
![Q3](nginx-502/q3.png)


