---
title: 【译】Windows下的Docker Machine - 如何设置你的Docker主机
date: 2017-12-25 22:23:20
tags:
 - Other
---
>原文作者：Markus Eisele
原文地址：https://dzone.com/articles/docker-machine-windows-how

最近我一直在折腾Docker。原因有很多，可以肯定的是，我喜欢折腾最新的技术，而且最好能帮忙实现一到两个示例的`demo`出来。和我的其他同事们不一样的是，我在`Windows`上运行我的设，如同大多数中间件开发人员一样。所以，如果你按照Arun的博客关于“ [**Docker Machine to Setup Docker Host**](http://blog.arungupta.me/docker-machine-seutp-docker-host-techtip78/) ”，你可能已经试图在`Windows`上进行尝试了(译者注：Dcoker Machine是Docker的官方项目，负责在多平台上快速安装Docker环境，此处博客内容若无法显示，可以在云+社区查看其他的[docker相关教程](https://cloud.tencent.com/developer/search/article-docker))。这里给出使用`Docker Machine`管理和启动Docker主机的终极简便指南。

 **Docker Machine**

通过`Machine`，您可以在您的计算机，云提供商以及您自己的数据中心内部创建Docker主机。它能创建服务器，在其上安装`Docker，并配置Docker客户端与之通信。在此之前，基本上不必在机器上安装任何东西。这比 以前手动[**安装boot2docker**](http://blog.eisele.net/2014/12/docker-for-java-ee-developers-on-windows-with-maven.html)要容易得多  。所以，来尝试一下吧。

在开始使用Docker或Machine之前，还有一件事情必须要完成。那就是去获取  [**Windows的Git**](https://msysgit.github.io/)  （又名`msysgit`）。其中包含有各种有用的unix工具，无论如何你都需要它。

 **先决条件 - 打包安装方案**

第一个是安装Windows Boot2docker分布 ，可以参考[** 我在早些时候的博客**](http://blog.eisele.net/2014/12/docker-for-java-ee-developers-on-windows-with-maven.html)。它包含以下软件的配置，已经准备好为你服务：

- VirtualBox 
- Docker Windows客户端

 **先决条件 - 分拆单独安装**

出于由于各种原因，我不太喜欢boot2docker安装程序。主要是因为我想知道它实际在我的设备上实际上完成了什么操作。于是我尝试了一下，如果你决定不使用打包安装方案，那么这里就是分拆单独安装的方法。从虚拟化解决方案开始。我们在Windows上必需要安装类似的东西，因为它不能运行Linux，而这就是Docker的基础。至少现在如此。所以，获取  [**VirtualBox，**](https://virtualbox.org/wiki/Downloads)  并确保您的系统上正确安装了版本`4.3.18`（[**VirtualBox-4.3.18-96516-Win.exe**](http://download.virtualbox.org/virtualbox/4.3.18/VirtualBox-4.3.18-96516-Win.exe)，105 MB）。警告：在Virtualbox中运行Windows本身时会出现一个奇怪的问题。您可能会  [**遇到一个启动主机的问题**](https://github.com/docker/machine/issues/742)  。

完成上述步骤后，就要获取`Docker `Windows客户端。可以从测试服务器中直接下载（[**docker-1.6.0.exe**](http://test.docker.com.s3.amazonaws.com/builds/Windows/x86_64/docker-1.6.0.exe)，x86\_64,7.5MB）。重命名为“docker”，并将其放到您选择的文件夹中（这里推荐使用`c:\ docker \`。接下来还需要下载`Docker Machine`，这是另一个单独的可执行文件（[**docker-machine\_windows-amd64.exe**](https://github.com/docker/machine/releases/download/v0.2.0/docker-machine_windows-amd64.exe)，11.5 MB），重命名为“docker-machine”并放到同一个文件夹中，然后把这个文件夹添加到PATH中：

```
set PATH =％PATH％; C：\ docker
```

推荐你添加PATH环境变量，这样可以减少大量的输入。那么，你已经准备好创建第一台机器管理的Docker主机。


 **使用Machine创建Docker主机**

一切只需要一个简单的命令：

```
docker-machine create --driver virtualbox dev
```

输出结果应该是：

```
←[34mINFO←[0m[0000] Creating SSH key...
←[34mINFO←[0m[0001] Creating VirtualBox VM...
←[34mINFO←[0m[0016] Starting VirtualBox VM...
←[34mINFO←[0m[0022] Waiting for VM to start...
←[34mINFO←[0m[0076] "dev" has been created and is now the active machine.
←[34mINFO←[0m[0076] To point your Docker client at it, run this in your shell: eval "$(docker-machine.exe env dev)"
```

这意味着，您刚刚使用VirtualBox提供程序和名称“dev”创建了一个`Docker`主机。现在你需要找出主机正在运行在哪个IP地址。

```
docker-machine ip
192.168.99.102
```

如果你刚才配置了环境变量，客户端所需要的就更简单，只需使用下面的命令：

```
docker-machine env dev
export DOCKER_TLS_VERIFY=1
export DOCKER_CERT_PATH="C:\\Users\\markus\\.docker\\machine\\machines\\dev"
export DOCKER_HOST=tcp://192.168.99.102:2376
```

这里输出了Linux样式的环境变量定义。你需要做的仅仅是把“export”关键字改成“set”，删除“和双反斜线，就万事俱备了。

```
C:\Users\markus\Downloads>set DOCKER_TLS_VERIFY=1
C:\Users\markus\Downloads>set DOCKER_CERT_PATH=C:\Users\markus\.docker\machine\machines\dev
C:\Users\markus\Downloads>set DOCKER_HOST=tcp://192.168.99.102:2376
```

 **来测试下Docker客户端**

现在我们开始在新创建的主机上运行`WildFly`：

```
docker run -it -p 8080:8080 jboss/wildfly
```

观察下载的容器，并通过将浏览器重定向到[**http://前文提示ip:8080/**]来检查它是否正在运行  。

祝贺您成功在Windows上使用Maschine安装了第一台Docker主机。

