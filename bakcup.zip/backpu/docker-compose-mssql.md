---
title: SQL Server on Linux by Docker 
date: 2018-06-05 12:51:32
tags:
 - Docker
---

> SQL Server 2017 on Linux 发布很久了，我倒是最近才知道，用Docker 安装一个，试用一下。直接在github 上查看 - [raphaelli/Dockerfiles - on github](https://github.com/raphaelli/Dockerfiles)



# Docker-Compose File



```sh
version: "3"
services:
    mssql_server:
      image: microsoft/mssql-server-linux:2017-latest
      container_name: mssql_compose
      ports:
        - 1433:1433
      volumes:
        - '/docker/mssql/opt:/var/opt/mssql'
      environment:
        - ACCEPT_EULA=Y
        - SA_PASSWORD=P@ssw0rd
```



- image `microsoft/mssql-server-linux:2017-latest`
- ports 暴露端口：1433 
- volumes 指定卷 到地址 `/var/opt/mssql`
- environment 环境变量 同意EULA 许可 和设置密码



# 连接测试

最开是测试连接是使用了 Navicat 和 SQL Server Management Studio 均无法比较正常的连接和使用，最后在网上查到了，使用VS code 的 MSSQL Tool 来进行连接。

![mssql](docker-compose-mssql\mssql.png)



使用 `ctrl+p`打开控制台，输入`>mssql `并根据提示创建连接池语句连接，新建一个 `.sql` 文件进行测试。



```sql
-- 默认连接 master 数据库，查询测试
select * FROM dbo.sysdatabases;

-- 创建测试数据库 ， *注意路径*
USE master ;  
GO  
CREATE DATABASE Test  
ON   
( NAME = Test_dat,  
    FILENAME = '/opt/data/saledat.mdf',  
    SIZE = 10,  
    MAXSIZE = 50,  
    FILEGROWTH = 5 )  
LOG ON  
( NAME = Test_log,  
    FILENAME = '/opt/data/salelog.ldf',  
    SIZE = 5MB,  
    MAXSIZE = 25MB,  
    FILEGROWTH = 5MB ) ;  
GO  

-- 创建测试表
CREATE TABLE testTable
(
    testId INT,
    testName VARCHAR(32)
);


-- 添加测试数据
INSERT INTO testTable VALUES (1,'TEST1')
INSERT INTO testTable VALUES (2,'TEST2')

-- 查询测试数据
select * FROM testTable;
```



![sql](docker-compose-mssql\sql.png)