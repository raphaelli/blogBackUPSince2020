---
title: ASP.NET MVC 行为详解
date: 2017-08-20 12:07:36
tags:
 - dotNET
---
>前面分别介绍了MVC中的三个重要部分，而行为（Action），则是其中C-Controller中的重要内容，下面详解一二。

### 基类
 一般继承自Controller类，类Controller继承自ControllerBase，实现了IController接口。
### Action重载
 Action的本质就是类中的公有方法，可以进行重载，要求参数不同。
  如下图，ActionResult 和 public的方法同样可以被直接访问到。
   ![ActionResult][1]
### 处理请求
 可以接受客户端的Get或Post请求。如果希望某个方法只处理某一种请求，可以在方法钱加特性[HttpGet]或[HttpPost]，处理请求时会根据参数进行相应方法的调用。
### 通过路由规则传递数据
 Action 也可以通过路由规则传递数据。
### 接收参数  
#### 方式一：
使用Request根据Key接收Value  
   ![Request][2]
#### 方式二：
自动装配，在方法的参数位置，定义类型及参数名称，mvc会自动匹配相同名称的属性值，即匹配input的name与对象的属性相同名称的值。

**自动装配的要求：参数的名称或对象类型的属性必须与参数的键相同**

   ![自动装配][4]
   注意：虽然可以直接重载，但是方法会出现选择问题
   ![重载][3]

#### 自定义类型的参数的封装
  ![封装][5]

### 返回结果
>行为-也就是控制器一共有五种可供选择的返回类型

- 返回类型为ActionResult，是一个抽象类，需要返回具体类型的结果对象
  直接或间接继承自ActionResult的类型
- ViewResult：使用View()可以指定一个页面，也可以指定传递的模型对象，如果没有指定的参数则表示返回与Action同名的页面。
- ContentResult：使用Content(string content) 返回一个原始字符串
  ![返回字符串][6]
- RedirectResult：使用Redirect(string url)将结果转到其他的Action
- JsonResult：使用Json(object data) 将data序列化为json数据并返回，推荐加上JsonRequestBehavior.AllowGet 可以处理Get请求，一般结合客户端的ajax请求进行返回。
  ![返回Ajax][7]



### 总结：

- 控制器由行为组成
- 行为的本质就是方法
- 控制器的返回类型： ActionResult
- 行为（方法）的重载 要求： 1.参数不同 2.请求方式不同（POST/GET）
- 数据的传递与接受：`传递 支持Get/Post方法传递` / `接受 Request["键"] 自动装配 `



[1]: asp-mvc-act/1.png
[2]: asp-mvc-act/2.png
[3]: asp-mvc-act/3.png
[4]: asp-mvc-act/4.png
[5]: asp-mvc-act/5.png
[6]: asp-mvc-act/6.png
[7]: asp-mvc-act/7.png


