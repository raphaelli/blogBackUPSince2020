---
title: homebrew 常用指令列表
date: 2018-04-07 16:49:18
tags:
 - Other
---



> 让老赵帮我装了这套 E3-1245 v2 + GTX660 的黑苹果之后，到是一直拿来在玩游戏和娱乐，基本上没有用到开发，这几天算是体验完了，干回码农的老本行，开发环境装了一大堆，有些小工具还是需要 homebrew 来安装管理，记录下 homebrew 的常用命令列表。



# 指令

* 查看有哪些指令可以使用
```bash
% brew help
```

* 查找相关软件，以mongodb为例：
```bash
% brew search mongodb
```

* 安裝 MongoDB
```bash
% brew install mongodb
```

* 查看已安裝软件信息
```bash
% brew info mongodb
```

* 移除 MongoDB
```bash
% brew uninstall mongodb
```

* 列出目前已安裝的软件
```bash
% brew list
```

* 查询有哪些软件版本已经过期
```bash
% brew outdated
```

* 刪除旧版本软件
  默认的情況下，Homebrew 不会删除旧版本的软件，但是这样会导致电脑上存在过多的无用历史版本，建议使用cleanup定期清除： (-n 是显示删除过程)
```bash
% brew cleanup -n
```

* 更新 MongoDB
```bash
% brew upgrade mongodb
```

* 更新 Homebrew 和系统上的所有软件
```bash
% brew update && brew upgrade && brew doctor
```



# 常用软件列表

- tree  显示树形目录，Mac/Linux