---
title: .NET Core 实战笔记3 ASP.NET Core
date: 2017-12-31 00:20:51
tags:
 - dotNET
---
>期末告一段落，有一周的时间给我折腾折腾，那就继续dotNet Core吧，先列一下文章列表。

- [.NET Core 实战笔记1-介绍和安装](https://ns96.com/2017/11/21/dotNet-core-1/)
- [.NET Core 实战笔记2-从命令开始](https://ns96.com/2017/11/27/dotNet-core-2/)

# ASP.NET Core 介绍
`ASP.NET Core` 是一个跨平台的高性能开源框架，用于生成基于云且连接 Internet 的新式应用程序。 

使用 `ASP.NET Core`，可以：
- 生成 Web 应用和服务、IoT 应用和移动后端。
- 在 Windows、macOS 和 Linux 上使用喜爱的开发工具。
- 部署到云或本地
- 在 `.NET Core `或 `.NET Framework `上运行。

数百万开发人员在使用（并继续使用）`ASP.NET Core` 来创建 Web 应用。`ASP.NET Core`  是重新设计的`ASP.NET ` ，对体系结构进行了更改，提供更精简的模块化框架。

`ASP.NET Core` 具有如下优点：
- 生成 Web UI 和 Web API 的统一场景。
- 新式客户端框架与开发工作流的集成。
- 基于环境的云就绪配置系统。
- 内置依赖项注入。
- 轻型高性能模块化 HTTP 请求管道。
- 能够在 IIS 上进行托管或在自己的进程中进行自托管。
- 可以在` .NET Core `上运行，支持真正的并行应用版本控制。
- 简化新式 Web 开发的工具。
- 能够在 Windows、macOS 和 Linux 进行生成和运行。
- 开源和关注社区。

`ASP.NET Core`完全作为 NuGet 包的一部分提供。 这可优化应用，使其只包含需要的 NuGet 包。 较小的应用图面区域的优势包括：提升安全性、减少维护和提高性能。

# ASP.NET Core 应用
`ASP.NET Core`应用其实就是在Main中创建一个Web服务器的简单控制台应用程序。

![Main][1]

如上图，`Main方法`调用遵循`builder`模式的`WebHostBuilder`，用于创建一个Web应用程序的宿主。这个`builder`具有定义Web服务器（如`UseKestrel`）和startup类型（`UseStartup`）的方法。

`Build`和`Run`方法构建了用于宿主应用程序的`IWebHost`，然后启动它来监听传入的HTTP请求。

# Startup
上面的Main方法中有写到`WebHostBuilder`的`UseStartup`方法为应用制定了`Startup类`。

## Startup类
`Startup类` 可以用来定义请求和处理管道和配置应用需要的服务。`Starup`类必须是`public`的，内容实例如下：
![Startup][2]

在`ASP.NET Core`中，`Startup类` 提供了应用程序的入口并充当为应用程序的启动点。`ASP.NET`会在主程序集中搜索名为`Startup`的类，`Startup`类能够选择性地在构造函数中接受通过依赖注入提供的依赖项，将要被配置的应用程序的方法应定义于`Stratup`类的构造函数中，如`Configuration`。`Startup`类必须定义`Configure`方法，可以选择定义一个`ConfigureServices`方法，这些方法在应用程序启动时被调用。

## Configure方法
`Configure`方法用于定义请求管道中的中间件，即指定`ASP.NET`应用程序将如何响应每一个HTTP请求，简言之，可以配置每个请求都接收相同的响应。事实上，大多数应用程序都需要更复杂的管道配置并将其封装与中间件（middleware）中，并通过扩展方法添加到`IApplicationBuilder`上。



## ConfigureServices方法
`ConfigureServices`方法用于定义应用所使用的服务（如`ASP.NET MVC Core Framework`,`Entity Framework Core`,`Identity`等）。



# 服务
服务是应用中用于通用调用的组件。服务通过依赖注入获取并使用。ASP.NET Core内置了一个简单的控制反转（IoC）容器，它默认支持构造器注入，并且可以方便的替换成自己的选用的IoC容器。由于他的松耦合性，依赖注入（DI）使服务在整个应用中都可以使用。例如，Logging在整个应用中都可用。

# 中间件
在`ASP.NET Core`中个可以使用中间件构建请求处理管道。`ASP.NET Core`中间件为一个`HttpContext`执行异步逻辑，然后按顺序调用下一个中间件或者直接终止请求。一般来说，要使用一个中间件，只需要在`Configure`方法中调用`IApplicationBuilder`上一个对应的`UseXYZ`扩展方法即可。

`ASP.NET Core`带来了丰富的内置中间件：
- 静态文件（Static files）
- 路由（Routing）
- 身份验证（Authentication）

可以创建自定义中间件，或者在`ASP.NET Core`中使用任何基于`OWIN`的中间件。

# 服务器
`ASP.NET Core`托管模式并不会直接监听请求，而是依赖一个`HTTP Server`实现来转发请求到应用程序。这个转发的请求会以`feature`接口的形式被包装，然后被应用程序组合到一个`HttpContext`中去。`ASP.NET Core`包含了一个托管的跨平台Web服务器：`Kestrel`，通常运行在一个IIS或者Nginx的生产Web服务器之后。


[1]: dotNet-core-3/po.png
[2]: dotNet-core-3/su.png