---
title: Docker 渐入佳境
date: 2018-01-06 14:26:34
tags:
 - Docker
---
>前两篇算是对`Docker`做了大致的介绍，然后现在开始，就是`Docker`的实际运用了，先从一个简单的静态网站的部署开始。

- [Docker初次见面](https://ns96.com/2018/01/01/docker-start/) - `Docker`基础概念
- [Docker循序渐进](https://ns96.com/2018/01/05/docker-keepgoing/) - `Docker`容器的基本操作

# 容器端口映射
以网站服务为例，一般需要`80`端口，那么如何使容器的端口能被外界访问得到呢？这就要用到容器的端口映射。

 `run [-P] [-p]`

`-p` --publish = [] 

- containerPort - `docker run -p 80 -i -t /bin/bash` - 宿主机端口随机映射
- hostPort:containerPort - `docker run -p 8080:80 -i -t /bin/bash` - 宿主机端口:容器端口 指定映射
- IP:containerPort - `docker run -p 0.0.0.0:80 -i -t /bin/bash` - 指定IP的端口映射
- ip:hostPort:containerPort  `docker run -p 0.0.0.0:8080:80 -i -t /bin/bash` - 指定IP和端口的映射


# Nginx部署静态网站
部署Nginx需要以下步骤：
### 创建映射80端口的交互式容器
```
$ docker run -p 80 --name Nginx_Web -i -t ubuntu /bin/bash
```

### 安装Nginx
```
$ apt-get install -y nginx
```
若提示未发现软件，使用`apt-get update`更新源

### 安装文本编辑器vim
```
$ apt-get install -y vim
```

### 创建静态页面
先创建网站目录，然后使用vim编辑网页
```
$ mkdir -p /var/www/html
$ cd /var/www/html
$ vim index.html
```
输入一个基本的`html`内容,`:wq`指令保存并退出！

### 修改Nginx配置文件
```
$ cd /etc/nginx/
$ ls
$ vim /sites-enabled/default
```

检查root的默认路径，确认其为刚刚创建的`/var/www/html`

同样`:wq`指令保存并退出！

关于Nginx的配置可以参考之前的博客
- [Ubuntu下安装Nginx+PHP+MySql环境](https://ns96.com/2017/01/31/ubuntu-php/) 中配置nginx的部分内容
- [Nginx配置文件nginx.conf详解 ](https://ns96.com/2017/01/25/nginx-conf/)

### 运行Nginx
```
$ nginx
$ ps -ef
```
运行`nginx`,可以使用`ps`指令来查看

`Ctrl+P` + `Ctrl+Q` 切出容器，使用`docker ps`查看容器状态

![容器](docker-justtry/ps.png)


### 验证网站访问
若无公网IP，则直接使用`curl`命令才访问

```
$ curl http://127.0.0.1:32769
```

**注意**:这里的端口号使用刚才ps中显示的端口号，也可以使用`docker port Nginx_Web`来查看端口

![curl](docker-justtry/curl.png)

如果有外网或者域名解析，则可以直接访问验证。

![web](docker-justtry/web.png)

或者使用容器的ip地址访问（宿主机内部）

使用`docker inspect Nginx_Web`查看IP地址，并直接访问，此处略过。

### 退出容器后操作
退出容器后，nginx服务停止，使用`start`指令启动会，nginx并不会自动启动。

此时可以使用`docker exec Nginx_Web nginx`来附加指令使nginx启动，并正常运行。

**注意**:若不指定,退出并重新启动后的容器的端口和IP都会改变.