---
title: ASP.NET MVC 中全局获取项目根目录
date: 2019-01-15 11:29:32
tags: 
 - dotNET
---

>在处理请求的适合经常会出现url异常的状况，导致页面的加载出错。主要原因的是在判断url路径的时候，本地的测试环境的路径和实际的IIS的发布路径并不相同，因此通过在Shared/Layout 中配置获取，并直接在页面中使用。


```js
//配合 Shared/layout 获取根路径，用于请求链接
window.ROOT = "@HttpContext.Current.Request.ApplicationPath";
if (window.ROOT != "/") {
    window.ROOT += "/";
}  //Shared/layout中获取页面的 路径
```

```js
utils.getRoot = function() {
    if (window.ROOT)
        return window.ROOT;
    if (layui.ROOT)
        return layui.ROOT;
}
```

在非js脚本中使用，则可以使用原本的 Razor 方法。
```cs
@HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority)@Url.Content("~/")
```

