---
title: ASP.NET MVC项目开发笔记
date: 2017-12-13 10:29:09
tags:
 - dotNET
---
>暂时确立了Oracle的课程设计的技术栈使用`ASP.NET MVC + Oracle`，视时间情况选择是否使用`Dapper`或者`EF`，先搭建Web的基础框架，在搭建ASPdotNet MVC项目中遇到了不少问题，专门开一篇用于备份和以后的快速查询。

## 超链接跳转

- 直接写链接——变更路由后需要重写
```
<a href="/Home/About">关于我们</a>
```


- Html Helper ——自动匹配路由
```
@Html.ActionLink("About this application", "About")

```

- 跳转外部Controller
```
@Html.ActionLink("About this application", "About", "MyController") 
```

- 带参数
```
@Html.ActionLink("About this application", "About", new { id = "MyID" }) 
```

- 带html参数
```
@Html.ActionLink("About this application", "Index", "Home", null, 
    new {id = "myAnchorID", @class = "myCSSClass",target="_blank"}) 
```

- 生成全路径Url
```
@Html.ActionLink("About this application", "Index", "Home",  
    "https", "myserver.mydomain.com", " myFragmentName",  
    new { id = "MyId"}, 
    new { id = "myAnchorID", @class = "myCSSClass"}) 
```


还有其他的诸如通过路由，方法生成等，不在此赘述

## Scripts.Render、Styles.Render
配置BundleConfig.cs文件

1. 首先要在App_Start 里面BundleConfig.cs 文件里面 添加要包含的css文件
2. BundleConfig就是一个微软新加的 一个打包的配置类
3. BundleConfig用来Add 各种Bundle
4. BundleConfig配置信息如下：
```
public class BundleConfig
{
    // 有关捆绑的详细信息，请访问 https://go.microsoft.com/fwlink/?LinkId=301862
    public static void RegisterBundles(BundleCollection bundles)
    {
        bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                    "~/Scripts/main.js"));

        bundles.Add(new StyleBundle("~/Content/css").Include(
                    "~/Content/bootstrap.css",
                    "~/Content/main.css"));
    }
}
```
`~/Content/css`为别名，用于页面中读取 include包含静态内容

## @Html.Partial
属于HtmlHelper类的一个方法，用法如下
- `HtmlHelper(ViewContext, IViewDataContainer)`	使用指定的视图上下文和视图数据容器来初始化 HtmlHelper 类的新实例。
- `HtmlHelper(ViewContext, IViewDataContainer, RouteCollection)` 使用指定的视图上下文、视图数据容器和路由集合来初始化 HtmlHelper 类的新实例。

即文本内容由制定的内容进行渲染，例如：

```
<ul>
    <li><a href="/Home/index">Home</a></li>
    <li><a href="#">WhiteList</a></li>
    <li><a href="#">Shop</a></li>
    @Html.Partial("_LoginPartial")
</ul>
```
其中的`Partial`指向了`_LoginPartial`，其中根据用户登录状态进行判别，动态显示`用户名/注销`或者`登录/注册`

