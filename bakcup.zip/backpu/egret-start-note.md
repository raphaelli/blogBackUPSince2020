---
title: 白鹭引擎—— 学习笔记
date: 2019-08-25 03:24:43
tags:
 - egret
---



> 最近打算重新尝试下独立游戏的开发，多说无益，先从egret开始。



# Egret 项目结构

游戏开发，最主要两个部分内容，一个是资源，一个是脚本。

先说资源。

![skin](egret-start-note\skin.jpg)



`resource`目录下，`assets`与`eui_skins`中的`exml`文件一一对应，并通过`default.res.json`文件来进行管理和申明。



**自己添加的资源，同样也是添加到这个目录中，并申明**



再看脚本，脚本都存放在`src`目录下，`main.ts`则是脚本的入口文件，也是整个游戏的主要控制入口。



![main](egret-start-note\main.jpg)



主要看两个方法

- `loadResource()`加载资源
- `createGameScene()`加载场景

具体代码实现，则是使用TS脚本，调用Egret引擎的能力，来绘制场景和界面，并加载脚本代码。这里可以直接将简单的逻辑脚本写入`main.ts`亦可编写单独的TS脚本在main中调用。



# Egret常用API

## 文本

```js
let label:egret.TextField = new egret.TextField(); 
label.text = "hello world!"; 
```

## 图片

```js
let img:egret.Bitmap = new egret.Bitmap();
img.texture = RES.getRes("imgName");
```

## 形状

```js
// 画个红色矩形框
let shp:egret.Shape = new egret.Shape();
shp.graphics.beginFill( 0xff0000, 1);
shp.graphics.drawRect( 0, 0, 100, 200 );
shp.graphics.endFill();
```

## 声音

```js
let sound:egret.Sound = RES.getRes("mp3Name");
sound.play();
sound.stop();
```

## 事件

```ts
// 触摸事件（相当于点击）
this.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchTap,this);
this.removeEventListener(egret.TouchEvent.TOUCH_TAP,this.onTouchTap,this);
```

## 计时器

```js
// 参数为时间间隔（ms）和执行次数
let timer:egret.Timer = new egret.Timer(500, 5); 
// 边计时边触发
timer.addEventListener(egret.TimerEvent.TIMER, this.timerFunc, this);
// 计时结束触发
timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE,this.timerComFun,this);
// 开始计时
timer.start();
// 暂停计时
timer.stop();
// 重新计时
timer.reset();
```

## 数据存储

```js
// 存储数据
let key:string = "score";
let value:string = "100";
egret.localStorage.setItem(key, value);
// 读取数据
let score:string = egret.localStorage.getItem(key);
// 移除数据
egret.localStorage.removeItem(key);
// 清除所有数据
egret.localStorage.clear();
```
